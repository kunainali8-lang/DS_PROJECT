"""Persistent JSON log of which views were materialised and whether they succeeded."""

import json
import logging
import os
import threading
from datetime import datetime

import config

logger = logging.getLogger(__name__)

_lock = threading.Lock()


def _load():
    if not os.path.exists(config.EXECUTION_LOG_JSON):
        return []
    try:
        with open(config.EXECUTION_LOG_JSON, 'r', encoding='utf-8') as f:
            return json.load(f).get('executions', [])
    except (OSError, ValueError) as exc:
        logger.warning("Execution log unreadable, starting fresh: %s", exc)
        return []


def record_view_execution(view_name, parent_exception, status, error_message=None):
    """Append one entry. ``status`` is 'success' or 'failed'."""
    entry = {
        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'view_name': view_name,
        'parent_exception': parent_exception,
        'status': status,
        'error_message': error_message,
    }
    with _lock:
        executions = _load()
        executions.append(entry)
        os.makedirs(os.path.dirname(config.EXECUTION_LOG_JSON), exist_ok=True)
        with open(config.EXECUTION_LOG_JSON, 'w', encoding='utf-8') as f:
            json.dump({'executions': executions}, f, indent=2)


def get_summary():
    with _lock:
        executions = _load()
    return {
        'total_executions': len(executions),
        'successful': sum(1 for e in executions if e.get('status') == 'success'),
        'failed': sum(1 for e in executions if e.get('status') == 'failed'),
        'executions': executions,
    }


def clear():
    with _lock:
        if os.path.exists(config.EXECUTION_LOG_JSON):
            os.remove(config.EXECUTION_LOG_JSON)
    logger.info("Execution log cleared")

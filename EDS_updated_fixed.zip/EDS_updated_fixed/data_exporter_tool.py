import re
import os
import time
import shutil
import zipfile
import secrets
import datetime
import warnings
import numpy as np
import pandas as pd
import pyodbc as db
import concurrent.futures
from datetime import datetime
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor
from tqdm import tqdm
import openpyxl
from sklearn.preprocessing import LabelEncoder
import joblib
import threading
start_time = time.time()

warnings.filterwarnings("ignore", message="DataFrame.applymap has been deprecated. Use DataFrame.map instead.")
warnings.filterwarnings("ignore", message="Workbook contains no default style, apply openpyxl's default")
warnings.filterwarnings("ignore", message="Could not infer format, so each element will be parsed individually, falling back to `dateutil`.")
warnings.filterwarnings("ignore", message="""pandas only supports SQLAlchemy connectable (engine/connection) or database string URI or 
                                             sqlite3 DBAPI2 connection. Other DBAPI2 objects are not tested. Please consider using SQLAlchemy.""")
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

ILLEGAL_CHARACTERS_RE = re.compile(r'[\000-\010]|[\013-\014]|[\016-\037]') 
conn_name = "impala"

##-------------------------------------------------------------------------------------------------------------------------------------------------
def read_env_file(file_path):
    env_vars = {} 
    with open(file_path, 'r') as file:
        for line in file:
            line = line.strip()
            if line and not line.startswith('#'):
                key, value = line.split('=', 1)
                env_vars[key.strip()] = value.strip()
    return env_vars

##-------------------------------------------------------------------------------------------------------------------------------------------------
def datalake_credentials(file_path):
    credential_variables = {}
    env_variables = read_env_file(file_path)
    for key, value in env_variables.items():
        os.environ[key] = value
    for key, value in env_variables.items():
        credential_variables[key]=value
        
    return credential_variables

##-------------------------------------------------------------------------------------------------------------------------------------------------
def connect_to_dl(credential_variables):
    success = False
    while not success:
        try:
            conn_name = "impala"
            connection = db.connect('DSN=%s;' % conn_name, autocommit=True)
            compiler = connection.cursor()
            success = True
            return connection, compiler
        except Exception as e:
            print("An error occurred:", str(e))
            time.sleep(60)


#function to create encoder for any column that requires to be encrypted for security purposes.
##-------------------------------------------------------------------------------------------------------------------------------------------------
def create_encoder(database_name, table_name, column_name, column_description, start_date, end_date):
    # Variables
    encoder = LabelEncoder()
    encoder_file_path = f"{column_name}_encoder.pkl"
    file_path = r'data_lake_credentials.txt'
    credential_variables = datalake_credentials(file_path)
    connection = connect_to_dl(credential_variables)[0]
    fetched_data = ''
    data_empty = 0

    # Check if encoder file already exists
    try:
        encoder = joblib.load(encoder_file_path)
    except Exception as E:
        encoder = LabelEncoder()
        data_empty = 1

    # Fetch data from Datalake
    if connection:
        query = f"SELECT DISTINCT {column_name},{column_description} FROM {database_name}.{table_name} where TO_DATE(EOD_DATE) between '{start_date}' and '{end_date}';"
        fetched_data = pd.read_sql(query, connection)
        print(fetched_data)

    # Fixing data type
    fetched_data[column_name] = fetched_data[column_name].astype(str)
    fetched_data[column_description] = fetched_data[column_description].astype(str)

    # Strip leading/trailing spaces and convert to lowercase
    fetched_data[column_name] = fetched_data[column_name].str.strip().str.lower()
    fetched_data[column_description] = fetched_data[column_description].str.strip().str.lower()

    if data_empty == 1:
        encoder.fit(fetched_data[column_name])
        # Save the encoder
        joblib.dump((encoder), encoder_file_path)
        # Write data to CSV file
        open(f"{column_name}_data.csv", 'w').close()
        fetched_data.to_csv(f"{column_name}_data.csv", index=False)
    else:
        # Check for unseen labels in transaction_code
        unseen_column_value = set(fetched_data[column_name]) - set(encoder.classes_)
        print("Unseen column values:", unseen_column_value)
        if unseen_column_value:
            encoder.classes_ = np.append(encoder.classes_, list(unseen_column_value))

        # Save the encoder before transforming the column to avoid changing the original values
        joblib.dump((encoder), encoder_file_path)

        # If the file exists, read the existing data
        existing_data = pd.read_csv(f"{column_name}_data.csv")

        # Find new data that is not already in the existing data
        new_data = fetched_data[~fetched_data[[column_name, column_description]].apply(tuple, 1).isin(existing_data[[column_name, column_description]].apply(tuple, 1))]
    
        # Append only the new data to the existing data and drop duplicates
        updated_data = pd.concat([existing_data, new_data]).drop_duplicates()

        # Write the updated data to CSV file without transforming the column to keep original values
        updated_data.to_csv(f"{column_name}_data.csv", index=False)


##-------------------------------------------------------------------------------------------------------------------------------------------------
def get_connection_and_credentials():
    """
    Reads the credentials from the environment file and establishes a connection to the database.

    Returns:
    tuple: A tuple containing the connection and credential variables.
    """
    file_path = r'./creds/data_lake_credentials.txt'
    credential_variables = datalake_credentials(file_path)
    
    # Testing connection
    connection = connect_to_dl(credential_variables)[0]
    
    return connection, credential_variables

##-------------------------------------------------------------------------------------------------------------------------------------------------
def table_dropper(database_name, table_name):
    """
    Drops a table in the specified database.

    Parameters:
    database_name (str): Name of the database.
    table_name (str): Name of the table to drop.

    Returns:
    bool: True if the table was dropped successfully, False otherwise.
    """
    connection, _ = get_connection_and_credentials()
    
    if connection:
        try:
            cursor = connection.cursor()
            drop_query = f"DROP TABLE {database_name}.{table_name};"
            cursor.execute(drop_query)
            connection.commit()
            print(f"Table {database_name}.{table_name} dropped successfully.")
            return True
        except Exception as e:
            print(f"An error occurred while dropping the table: {str(e)}")
            return False
        finally:
            cursor.close()
            connection.close()
    else:
        print("Connection failed.")
        return False

##------------------------------------------------------------------------------------------------------------------------------------------------- 
def table_creator(query, database_name, table_name):
    """
    Creates a table in the specified database using a SELECT statement with Hive/Impala syntax.

    Parameters:
    query (str): The SELECT statement to create the table.
    database_name (str): Name of the database.
    table_name (str): Name of the table to create.

    Returns:
    bool: True if the table was created successfully, False otherwise.
    """
    connection, _ = get_connection_and_credentials()
    
    if connection:
        try:
            cursor = connection.cursor()
            create_query = f"CREATE TABLE {database_name}.{table_name} AS {query}"
            cursor.execute(create_query)
            connection.commit()
            print(f"Table {database_name}.{table_name} created successfully.")
            return True
        except Exception as e:
            print(f"An error occurred while creating the table: {str(e)}")
            return False
        finally:
            cursor.close()
            connection.close()
    else:
        print("Connection failed.")
        return False

##-------------------------------------------------------------------------------------------------------------------------------------------------
def extract_with_checkpoints(table_name, database_name, output_file, directory_name):
    """
    Extracts data from a table using checkpoints. If there is an issue during extraction,
    it writes a checkpoint and resumes from the last saved checkpoint when called again.

    Parameters:
    table_name (str): Name of the table to extract data from.
    database_name (str): Name of the database.
    output_file (str): Name of the output file to save the extracted data.
    directory_name (str): Name of the directory to save the output file and checkpoint file.

    Returns:
    bool: True if extraction is successful, False otherwise.
    """
    # Create directory if it does not exist
    os.makedirs(directory_name, exist_ok=True)
    
    connection, _ = get_connection_and_credentials()
    
    if connection:
        try:
            cursor = connection.cursor()
            checkpoint_file = os.path.join(directory_name, f"{table_name}_checkpoint.txt")
            output_file_path = os.path.join(directory_name, output_file)
            
            # Read the last checkpoint if it exists
            if os.path.exists(checkpoint_file):
                with open(checkpoint_file, 'r') as file:
                    last_checkpoint = int(file.read().strip())
            else:
                last_checkpoint = 0

            chunk_size = 10000  # Adjust this based on available memory
            rows_fetched = 0

            # Open a CSV file in write mode
            with open(output_file_path, 'a', newline='', encoding='utf-8') as csvfile:
                # Create a CSV writer
                csv_writer = None

                while True:
                    query = f"""
                    SELECT * FROM (
                        SELECT *, ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS row_id
                        FROM {database_name}.{table_name}
                    ) subquery
                    WHERE row_id > {last_checkpoint}
                    LIMIT {chunk_size};
                    """
                    chunk = pd.read_sql(query, connection)

                    if chunk.empty:
                        break

                    if csv_writer is None:
                        # Write header only for the first chunk
                        chunk.to_csv(csvfile, index=False, mode='a', header=True)
                        csv_writer = True
                    else:
                        # Append data for subsequent chunks
                        chunk.to_csv(csvfile, index=False, mode='a', header=False)

                    rows_fetched += len(chunk)
                    last_checkpoint = chunk['row_id'].iloc[-1]

                    # Write the checkpoint to the file
                    with open(checkpoint_file, 'w') as file:
                        file.write(str(last_checkpoint))

            # Delete the checkpoint file after successful extraction
            if os.path.exists(checkpoint_file):
                os.remove(checkpoint_file)

            print(f"Data extraction complete. File saved as '{output_file_path}'.")
            return True
        except Exception as e:
            print(f"An error occurred during data extraction: {str(e)}")
        finally:
            cursor.close()
            connection.close()
    else:
        print("Connection failed.")
    return False

##-------------------------------------------------------------------------------------------------------------------------------------------------
def create_table(data, database_name, table_name):
    """
    Creates a table in Hive/Impala using the provided DataFrame.

    Parameters:
    data (pd.DataFrame): The DataFrame containing the data to be inserted.
    database_name (str): The name of the database.
    table_name (str): The name of the table to be created.

    Returns:
    None
    """
    print('---running create_table---')
    file_path = r'data_lake_credentials.txt'
    credential_variables = datalake_credentials(file_path)
    
    # Testing connection
    connection = connect_to_dl(credential_variables)[0]
    
    if connection:
        cursor = connection.cursor()
        
        # Create database if it doesn't exist
        cursor.execute(f"CREATE DATABASE IF NOT EXISTS {database_name}")
        
        # Drop table if it already exists
        cursor.execute(f"DROP TABLE IF EXISTS {database_name}.{table_name}")
        
        # Create table with columns based on DataFrame
        columns = ", ".join([f"{col} STRING" for col in data.columns])
        create_table_query = f"CREATE TABLE {database_name}.{table_name} ({columns})"
        cursor.execute(create_table_query)
        
        # Insert data into table
        for index, row in data.iterrows():
            values = ", ".join([f"'{str(value)}'" for value in row])
            insert_query = f"INSERT INTO {database_name}.{table_name} VALUES ({values})"
            cursor.execute(insert_query)
        
        print(f"Table '{table_name}' created in database '{database_name}' with data.")
        
        cursor.close()
        connection.close()
        return True
    else:
        print("Connection failed.")
        return False

##-------------------------------------------------------------------------------------------------------------------------------------------------
def direct_execute(query, output_file):
    """
    Executes a SQL query and exports the results to a CSV file.

    Parameters:
    query (str): The SQL query to execute.
    output_file (str): The path to the output CSV file.

    Returns:
    None
    """
    print('---running direct execute---')
    file_path = r'data_lake_credentials.txt'
    credential_variables = datalake_credentials(file_path)
    
    # Testing connection
    connection = connect_to_dl(credential_variables)[0]
    
    if connection:
        # Execute the query and fetch the results
        data = pd.read_sql(query, connection)
        
        # Write the results to a CSV file
        data.to_csv(output_file, index=False, encoding='utf-8')
        
        print(f"Data export complete. File saved as '{output_file}'.")
    else:
        print("Connection failed.")


#function that takes complete query as input, and other columns for getting count for progress show
##-------------------------------------------------------------------------------------------------------------------------------------------------
def data_export_2(query, database_name, table_name, start_date, end_date, output_file):
    file_path = r'data_lake_credentials.txt'
    credential_variables = datalake_credentials(file_path)
    
    # Testing connection
    connection = connect_to_dl(credential_variables)[0]
    
    if connection:
        # Fetch total rows count for progress bar
        query_count = f"SELECT count(*) FROM {database_name}.{table_name} WHERE TO_DATE(eod_date) BETWEEN '{start_date}' AND '{end_date}';"
        data_rows = pd.read_sql(query_count, connection)
        total_estimated_rows = data_rows.iloc[0, 0]
        
        print('Total expected rows:', total_estimated_rows)

        chunk_size = 10000  # Adjust this based on available memory
        rows_fetched = 0

        # Open a CSV file in write mode
        with open(output_file, 'w', newline='', encoding='utf-8') as csvfile:
            # Create a CSV writer
            csv_writer = None

            # Read data in chunks and write to CSV
            with tqdm(total=total_estimated_rows) as pbar:
                for chunk in pd.read_sql(query, connection, chunksize=chunk_size):
                    if csv_writer is None:
                        # Write header only for the first chunk
                        chunk.to_csv(csvfile, index=False, mode='a', header=True)
                        csv_writer = True
                    else:
                        # Append data for subsequent chunks
                        chunk.to_csv(csvfile, index=False, mode='a', header=False)

                    rows_fetched += len(chunk)
                    pbar.update(len(chunk))
                    pbar.set_postfix(rows_fetched=rows_fetched)

        print(f"Data export complete. File saved as '{output_file}'.")
    else:
        print("Connection failed.")


#function for data exporting purposes using dates and specified columns
##-------------------------------------------------------------------------------------------------------------------------------------------------
def data_export(database_name, table_name, columns, start_date, end_date, output_file):
    file_path = r'data_lake_credentials.txt'
    credential_variables = datalake_credentials(file_path)
    
    # Testing connection
    connection = connect_to_dl(credential_variables)[0]
    
    if connection:
        # Fetch total rows count for progress bar
        query_count = f"SELECT count(*) FROM {database_name}.{table_name} WHERE TO_DATE(eod_date) BETWEEN '{start_date}' AND '{end_date}';"
        data_rows = pd.read_sql(query_count, connection)
        total_estimated_rows = data_rows.iloc[0, 0]
        
        print('Total expected rows:', total_estimated_rows)

        # Fetch data in chunks
        query_select = f"SELECT {', '.join(columns)} FROM {database_name}.{table_name} WHERE TO_DATE(eod_date) BETWEEN '{start_date}' AND '{end_date}';"
        chunk_size = 10000  # Adjust this based on available memory
        
        rows_fetched = 0

        # Open a CSV file in write mode
        with open(output_file, 'w', newline='', encoding='utf-8') as csvfile:
            # Create a CSV writer
            csv_writer = None

            # Read data in chunks and write to CSV
            with tqdm(total=total_estimated_rows) as pbar:
                for chunk in pd.read_sql(query_select, connection, chunksize=chunk_size):
                    if csv_writer is None:
                        # Write header only for the first chunk
                        chunk.to_csv(csvfile, index=False, mode='a', header=True)
                        csv_writer = True
                    else:
                        # Append data for subsequent chunks
                        chunk.to_csv(csvfile, index=False, mode='a', header=False)

                    rows_fetched += len(chunk)
                    pbar.update(len(chunk))
                    pbar.set_postfix(rows_fetched=rows_fetched)

        print(f"Data export complete. File saved as '{output_file}'.")
    else:
        print("Connection failed.")


##-------------------------------------------------------------------------------------------------------------------------------------------------
def decode(value, column_name):
    # Load the encoder
    encoder_file_path = f"{column_name}_encoder.pkl"
    try:
        encoder = joblib.load(encoder_file_path)
    except FileNotFoundError:
        print(f"No such file or directory: '{encoder_file_path}'")
        return
    
    # Decode the value
    try:
        decoded_value = encoder.inverse_transform([value])[0]
    except ValueError:
        print(f"Value '{value}' is not a valid encoded value for column '{column_name}'")
        return
    
    # Load the CSV file containing the original data
    csv_file_path = f"{column_name}_data.csv"   
    try:
        data = pd.read_csv(csv_file_path)
    except FileNotFoundError:
        print(f"No such file or directory: '{csv_file_path}'")
        return
    
    # Find the row where the column_name matches the decoded value
    original_info = data[data[column_name] == decoded_value]
    
    if not original_info.empty:
        print(f"Original information for {decoded_value} in column {column_name}:")
        print(original_info)
        return original_info
    else:
        print(f"No original information found for {decoded_value} in column {column_name}.")
        return


##-------------------------------------------------------------------------------------------------------------------------------------------------
def construct_and_execute_query(columns, table_name, database_name, conditions, dsn, user, password):
    """
    Constructs and executes a dynamic SQL query.

    Parameters:
    columns (list): List of columns to select.
    table_name (str): Name of the table.
    database_name (str): Name of the database.
    conditions (list): List of conditions for the WHERE clause.
    dsn (str): Data Source Name for ODBC connection.
    user (str): Username for database connection.
    password (str): Password for database connection.

    Returns:
    DataFrame: Resulting data from the executed query.
    """
    # Construct the SELECT clause
    select_clause = f"SELECT {', '.join(columns)}"
    
    # Construct the FROM clause
    from_clause = f"FROM {database_name}.{table_name}"
    
    # Construct the WHERE clause
    where_clause = ""
    if conditions:
        where_clause = "WHERE " + " AND ".join(conditions)
    
    # Combine all clauses to form the final query
    query = f"{select_clause} {from_clause} {where_clause};"
    
    # Establish a connection
    connection = db.connect(f'DSN={dsn};UID={user};PWD={password}')
    
    # Execute the query and fetch the results
    data = pd.read_sql(query, connection)
    
    # Close the connection
    connection.close()
    
    return data



##-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
def direct_execute_to_df(query):
    """
    Executes a SQL query and returns the results as a DataFrame.

    Parameters:
    query (str): The SQL query to execute.

    Returns:
    pd.DataFrame: The query results as a DataFrame.
    """
    print('---running direct execute to DataFrame---')
    file_path = r'./creds/data_lake_credentials.txt'
    credential_variables = datalake_credentials(file_path)
    
    # Testing connection
    connection = connect_to_dl(credential_variables)[0]
    
    if connection:
        # Execute the query and fetch the results
        data = pd.read_sql(query, connection)
        
        print("Data retrieval complete.")
        return data
    else:
        print("Connection failed.")
        return None











##multi threaded execution to download data faster
###############################################################################################################################################################################################




def extract_with_threads(table_name, database_name, output_file, directory_name, num_threads):
    """
    Extracts data using multiple threads for faster retrieval, handling cases where threads exceed row count.
    
    Parameters:
    - table_name (str): Name of the table to extract data from.
    - database_name (str): Name of the database.
    - output_file (str): Name of the output file to save the extracted data (filename only, e.g. 'data.csv').
    - directory_name (str): Directory to store extracted files.
    - num_threads (int): Number of threads to use for extraction.
    
    Returns:
    - bool: True if extraction is successful, False otherwise.
    """
    print(f"Starting parallel extraction with up to {num_threads} threads...")

    # Convert relative path to absolute path to ensure consistency across threads
    directory_name = os.path.abspath(directory_name)
    
    # Ensure directory exists (create it once before spawning threads)
    os.makedirs(directory_name, exist_ok=True)

    connection, _ = get_connection_and_credentials()
    
    if not connection:
        print("Connection failed.")
        return False

    cursor = None
    try:
        cursor = connection.cursor()
        
        # Get total row count
        count_query = f"SELECT COUNT(*) FROM {database_name}.{table_name};"
        cursor.execute(count_query)
        total_rows = cursor.fetchone()[0]

        if total_rows == 0:
            print("No rows found in the table. Skipping extraction.")
            # Write an empty CSV with headers
            final_output_path = os.path.join(directory_name, output_file)
            pd.DataFrame().to_csv(final_output_path, index=False)
            return True

        # Adjust thread count if necessary
        num_threads = min(num_threads, total_rows)  # Ensure threads do not exceed row count
        chunk_size = max(1, total_rows // num_threads)  # Ensure valid chunk size

        # Thread-safe results list and lock
        results = []
        results_lock = threading.Lock()
        thread_errors = []
        errors_lock = threading.Lock()

        # Derive a safe base name for chunk files (strip .csv extension to avoid duplication)
        output_file_basename = output_file
        if output_file_basename.lower().endswith('.csv'):
            output_file_basename = output_file_basename[:-4]

        def extract_chunk(start_row, end_row, thread_index):
            """ Extracts a specific chunk of data using row_id range. """
            local_conn = None
            local_cursor = None
            try:
                local_conn, _ = get_connection_and_credentials()
                local_cursor = local_conn.cursor()

                query = f"""
                SELECT * FROM (
                    SELECT *, ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS row_id
                    FROM {database_name}.{table_name}
                ) subquery
                WHERE row_id >= {start_row} AND row_id <= {end_row}
                ORDER BY row_id;
                """
                chunk = pd.read_sql(query, local_conn)

                # Build chunk filename using the base name (without .csv) so result is
                # e.g. "data_part_0.csv" instead of "data.csv_part_0.csv"
                chunk_filename = f"{output_file_basename}_part_{thread_index}.csv"
                output_chunk_file = os.path.join(directory_name, chunk_filename)

                # Ensure directory still exists (defensive, handles any edge case)
                os.makedirs(directory_name, exist_ok=True)

                chunk.to_csv(output_chunk_file, index=False)

                with results_lock:
                    results.append((thread_index, output_chunk_file))

            except Exception as e:
                with errors_lock:
                    thread_errors.append(f"Thread {thread_index} (rows {start_row}-{end_row}): {str(e)}")
            finally:
                try:
                    if local_cursor:
                        local_cursor.close()
                    if local_conn:
                        local_conn.close()
                except Exception:
                    pass

        # Create and start threads
        threads = []
        for i in range(num_threads):
            start_row = i * chunk_size + 1
            end_row = start_row + chunk_size - 1 if i < num_threads - 1 else total_rows
            thread = threading.Thread(target=extract_chunk, args=(start_row, end_row, i))
            threads.append(thread)
            thread.start()

        # Wait for all threads to complete
        for thread in threads:
            thread.join()

        # Check for thread errors
        if thread_errors:
            for err in thread_errors:
                print(f"[ERROR] {err}")
            raise RuntimeError(f"One or more threads failed during extraction. See errors above.")

        # Sort part files by thread index to preserve row order
        results.sort(key=lambda x: x[0])
        sorted_part_files = [r[1] for r in results]

        # Combine results into the final output file
        final_output_path = os.path.join(directory_name, output_file)
        with open(final_output_path, 'w', newline='', encoding='utf-8') as final_csv:
            first_chunk = True
            for part_file in sorted_part_files:
                df = pd.read_csv(part_file)
                df.to_csv(final_csv, index=False, header=first_chunk, mode='a')
                first_chunk = False
                os.remove(part_file)  # Clean up temporary files

        # Validate row count consistency
        df_final = pd.read_csv(final_output_path)
        print(f"Final row count: {len(df_final)} (Expected: {total_rows})")

        print(f"Data extraction complete. File saved as '{final_output_path}'.")
        return True

    except Exception as e:
        print(f"An error occurred: {str(e)}")
        return False
    finally:
        try:
            if cursor:
                cursor.close()
            if connection:
                connection.close()
        except Exception:
            pass
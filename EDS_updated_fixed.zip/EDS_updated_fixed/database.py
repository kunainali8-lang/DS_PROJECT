"""Data-lake access over ODBC.

Connections are made purely through the ODBC data source name configured in
``config.ODBC_DSN``; host, port and credentials are managed by the DSN itself.
"""

import logging
import re
import time
from contextlib import contextmanager

import pandas as pd
import pyodbc

import config

logger = logging.getLogger(__name__)

_IDENTIFIER_RE = re.compile(r'[A-Za-z_][A-Za-z0-9_]*')


def validate_identifier(name):
    """Return ``name`` if it is a safe SQL identifier, otherwise raise ValueError."""
    if not _IDENTIFIER_RE.fullmatch(name or ''):
        raise ValueError(f"Unsafe SQL identifier: {name!r}")
    return name


def _connect():
    """Open a connection, retrying a few times before giving up."""
    last_error = None
    for attempt in range(1, config.DB_CONNECT_ATTEMPTS + 1):
        try:
            return pyodbc.connect(f'DSN={config.ODBC_DSN}', autocommit=True)
        except pyodbc.Error as exc:
            last_error = exc
            logger.warning(
                "Connection to DSN '%s' failed (attempt %d/%d): %s",
                config.ODBC_DSN, attempt, config.DB_CONNECT_ATTEMPTS, exc,
            )
            if attempt < config.DB_CONNECT_ATTEMPTS:
                time.sleep(config.DB_CONNECT_RETRY_SECONDS)
    raise ConnectionError(f"Could not connect to DSN '{config.ODBC_DSN}': {last_error}")


@contextmanager
def cursor():
    """Yield a cursor on a fresh connection and close both afterwards."""
    connection = _connect()
    try:
        cur = connection.cursor()
        try:
            yield cur
        finally:
            cur.close()
    finally:
        connection.close()


def execute(sql):
    """Run a statement that returns no rows (DDL, etc.)."""
    with cursor() as cur:
        cur.execute(sql)


def query_to_dataframe(sql):
    """Run a query and return the result set as a DataFrame."""
    with cursor() as cur:
        cur.execute(sql)
        columns = [col[0] for col in cur.description]
        rows = [tuple(row) for row in cur.fetchall()]
    return pd.DataFrame.from_records(rows, columns=columns)


def drop_table(database_name, table_name):
    execute(f"DROP TABLE IF EXISTS {database_name}.{table_name}")
    logger.info("Dropped table %s.%s (if it existed)", database_name, table_name)


def create_table_as(select_sql, database_name, table_name):
    execute(f"CREATE TABLE {database_name}.{table_name} AS {select_sql}")
    logger.info("Created table %s.%s", database_name, table_name)

"""Execution steps of the exception-detection workflow.

Every step receives a context dict built by ``app.py``:

    exception_ids  - ids of the exceptions selected in the UI
    parameters     - {'startDate', 'endDate', 'branches', ...} from the UI
    downloads_dir  - output folder for generated reports
    exceptions_csv - path of the exceptions definition CSV
    should_stop    - callable returning True once the user pressed "Stop"
    on_progress    - callable(task, done, total) showing the current task in the UI
    on_issue       - callable(level, message) listing a problem in the UI

Steps:
    1. Materialise each selected exception view as a DS_* table in the data lake
    2. (No-op, kept for UI compatibility) branch segregation
    3. Build per-branch exception reports from database-side aggregates (+ AI summaries)
    4. Convert the per-branch reports to Excel
    5. Create a Word audit report per branch and zip everything
"""

import logging
import os
import re
import shutil
import zipfile
from datetime import datetime

import pandas as pd
import requests

import config
import database
import execution_log
import llm_client
from logging_setup import SUCCESS

try:
    from docx import Document
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.shared import Inches, Pt, RGBColor
except ImportError:  # Word reports are skipped if python-docx is missing
    Document = None

logger = logging.getLogger(__name__)

BRANCH_DATA_FOLDER = 'branch_data'
REPORT_CSV = 'exceptions_report.csv'
REPORT_XLSX = 'exceptions_report.xlsx'

# The UI collects a date range, but filtering on it is disabled, exactly as in
# the previously deployed version. Set to True to filter views on eod_date.
APPLY_DATE_FILTER = False

_DATE_RE = re.compile(r'\d{4}-\d{2}-\d{2}')


class ExecutionStopped(Exception):
    """Raised inside a step when the user asks to stop the execution."""


# ----------------------------------------------------------------------------
# Shared helpers
# ----------------------------------------------------------------------------

def _check_stop(ctx):
    should_stop = ctx.get('should_stop')
    if should_stop and should_stop():
        raise ExecutionStopped()


def _progress(ctx, task, done=None, total=None):
    """Log the current task and show it (with a done/total counter) in the UI."""
    logger.info(task)
    callback = ctx.get('on_progress')
    if callback:
        callback(task, done, total)


def _issue(ctx, level, message):
    """Log a problem that doesn't stop the step and list it in the UI."""
    logger.log(level, message)
    callback = ctx.get('on_issue')
    if callback:
        callback(logging.getLevelName(level), message)


def _load_selected_exceptions(ctx):
    """Exceptions chosen in the UI that have a view name, as a DataFrame of strings."""
    csv_path = ctx['exceptions_csv']
    if not os.path.exists(csv_path):
        raise FileNotFoundError(f"Exceptions CSV not found: {csv_path}")

    df = pd.read_csv(csv_path, dtype=str).fillna('')
    df['viewName'] = df['viewName'].str.strip()

    selected_ids = {int(i) for i in ctx.get('exception_ids') or []}
    if selected_ids:
        df = df[pd.to_numeric(df['id'], errors='coerce').isin(selected_ids)]

    return df[df['viewName'] != '']


def _view_suffix(view_name):
    """'FCCM_UAT.DS_001_x_vw' -> 'DS_001_x_vw'"""
    return view_name.split('.', 1)[-1]


def _table_name(view_name):
    """Name of the DS_* table materialised from a view."""
    return f"DS_{database.validate_identifier(_view_suffix(view_name))}"


def _validate_view_name(view_name):
    for part in view_name.split('.'):
        database.validate_identifier(part)
    return view_name


def _sql_string(value):
    return "'" + str(value).replace("'", "''") + "'"


def parse_branches(raw):
    """Split the branch text box (comma- or newline-separated) into clean codes."""
    return [b.strip() for b in re.split(r'[,\n\r]+', str(raw or '')) if b.strip()]


def build_query(view_name, params):
    """SELECT statement for a view, filtered by the execution parameters."""
    conditions = []

    start, end = params.get('startDate'), params.get('endDate')
    if APPLY_DATE_FILTER and start and end:
        if not (_DATE_RE.fullmatch(start) and _DATE_RE.fullmatch(end)):
            raise ValueError(f"Invalid date range: {start} - {end}")
        conditions.append(f"TO_DATE(eod_date) BETWEEN '{start}' AND '{end}'")

    branches = parse_branches(params.get('branches'))
    if branches:
        conditions.append(f"source_branch IN ({','.join(_sql_string(b) for b in branches)})")

    query = f"SELECT * FROM {_validate_view_name(view_name)}"
    if conditions:
        query += " WHERE " + " AND ".join(conditions)
    return query


def _branch_dirs(downloads_dir):
    """Yield (branch_code, folder) for each branch folder under branch_data/."""
    root = os.path.join(downloads_dir, BRANCH_DATA_FOLDER)
    if not os.path.isdir(root):
        return
    for name in sorted(os.listdir(root)):
        path = os.path.join(root, name)
        if os.path.isdir(path):
            yield name, path


def _read_branch_report(branch_path):
    """Read a branch's exceptions_report.csv, or None if missing/empty."""
    path = os.path.join(branch_path, REPORT_CSV)
    if not os.path.exists(path) or os.path.getsize(path) == 0:
        return None
    df = pd.read_csv(path)
    return None if df.empty else df


# ----------------------------------------------------------------------------
# Step 1: Rule-based exception identification
# ----------------------------------------------------------------------------

def execute_step_1(ctx):
    """Create one DS_* table per selected view (drop & recreate)."""
    downloads_dir = ctx['downloads_dir']
    shutil.rmtree(downloads_dir, ignore_errors=True)
    os.makedirs(downloads_dir, exist_ok=True)

    exceptions = _load_selected_exceptions(ctx)
    if exceptions.empty:
        _issue(ctx, logging.WARNING, "No selected exception has a view name; nothing to process")
        return

    views = list(exceptions.groupby('viewName', sort=False))
    failed = []
    for index, (view_name, group) in enumerate(views, start=1):
        _check_stop(ctx)
        parent_exception = group['parentException'].iloc[0] or 'unknown'
        _progress(ctx, f"Creating table for view {index}/{len(views)}: {view_name}", index - 1, len(views))
        try:
            table = _table_name(view_name)
            query = build_query(view_name, ctx['parameters'])
            logger.info("Query: %s", query)
            database.drop_table(config.DB_NAME, table)
            database.create_table_as(query, config.DB_NAME, table)
        except Exception as exc:
            _issue(ctx, logging.ERROR, f"View {view_name} failed: {exc}")
            execution_log.record_view_execution(view_name, parent_exception, 'failed', str(exc))
            failed.append(view_name)
            continue
        execution_log.record_view_execution(view_name, parent_exception, 'success')
        logger.log(SUCCESS, "Created %s.%s", config.DB_NAME, table)

    _progress(ctx, f"Processed {len(views)} view(s)", len(views), len(views))
    if failed:
        raise RuntimeError(f"{len(failed)} of {len(views)} view(s) failed to create their table "
                           f"(see Issues for details)")
    logger.log(SUCCESS, "Created %d table(s)", len(views))


# ----------------------------------------------------------------------------
# Step 2: Branch segregation (no longer needed)
# ----------------------------------------------------------------------------

def execute_step_2(ctx):
    logger.info("Step 2 skipped; detailed data remains in data-lake tables")


# ----------------------------------------------------------------------------
# Step 3: Final exceptions report
# ----------------------------------------------------------------------------

def _to_branch_code(value):
    number = pd.to_numeric(value, errors='coerce')
    return None if pd.isna(number) else str(int(number))


def _load_branch_info(ctx):
    """{branch_code: {'name', 'audit_region', 'business_region'}} from branch_information.csv."""
    if not os.path.exists(config.BRANCH_INFO_CSV):
        _issue(ctx, logging.WARNING, f"Branch information file not found ({config.BRANCH_INFO_CSV}); "
                                     "reports use Branch_<code> names and empty regions")
        return {}

    df = pd.read_csv(config.BRANCH_INFO_CSV, dtype=str).fillna('')
    if 'source_branch' not in df.columns:
        return {}

    info = {}
    for _, row in df.iterrows():
        code = _to_branch_code(row['source_branch'])
        if code is not None and code not in info:
            info[code] = {
                'name': row.get('branch_name', '').strip(),
                'audit_region': row.get('hub', '').strip(),
                'business_region': row.get('region', '').strip(),
            }
    return info


def _fetch_branch_counts(table, default_exception_name):
    """Instances per (branch, exception) from a DS_* table.

    Tables with an ``error`` column hold several exceptions and are grouped by it;
    otherwise every row counts towards ``default_exception_name``.
    """
    try:
        counts = database.query_to_dataframe(
            f"SELECT source_branch, error AS exception_name, COUNT(*) AS instances "
            f"FROM {table} GROUP BY source_branch, error")
        counts.columns = [str(c).lower() for c in counts.columns]
        if not {'source_branch', 'exception_name', 'instances'}.issubset(counts.columns):
            raise ValueError('Unexpected grouped-count columns')
    except Exception as exc:
        logger.info("%s: error grouping unavailable; counting by branch (%s)", table, exc)
        counts = database.query_to_dataframe(
            f"SELECT source_branch, COUNT(*) AS instances FROM {table} GROUP BY source_branch")
        counts.columns = [str(c).lower() for c in counts.columns]
        counts['exception_name'] = default_exception_name
    return counts


def _match_exception(group, exception_name):
    """Exception definition matching ``exception_name``, else the view's first one."""
    if exception_name:
        wanted = exception_name.casefold()
        for column in ('exceptionName', 'parentException'):
            matched = group[group[column].str.strip().str.casefold() == wanted]
            if not matched.empty:
                return matched.iloc[0]
    return group.iloc[0]


def _report_row(meta, branch_code, branch, instances, exception_name, table):
    return {
        'Theme': meta['theme'].strip(),
        'Sub-Theme': meta['subTheme'].strip(),
        'Branch Code': branch_code,
        'Branch Name': branch.get('name') or f"Branch_{branch_code}",
        'Audit Region': branch.get('audit_region', ''),
        'Business Region': branch.get('business_region', ''),
        'Audit Year': str(datetime.now().year),
        'Issue Risk Rating': meta['issueRiskRating'].strip(),
        'Sub - Theme Risk Rating': meta['subThemeRiskRating'].strip(),
        'Risk Type': meta['riskType'].strip(),
        'Issue Type (Design / Operational Error)': meta['issueType'].strip(),
        'Issue Owner': meta['issueOwner'].strip(),
        'Issue Description': meta['issueDescription'].strip(),
        'Instances': instances,
        'Selected Sample': instances,
        'exception_name': exception_name,
        'source_table': table,
    }


def execute_step_3(ctx):
    """Create one aggregate exceptions_report.csv per branch."""
    use_llm = bool(ctx['parameters'].get('use_llm_summary', True))
    exceptions = _load_selected_exceptions(ctx)
    branch_info = _load_branch_info(ctx)

    rows = []
    views = list(exceptions.groupby('viewName', sort=False))
    for index, (view_name, group) in enumerate(views, start=1):
        _check_stop(ctx)
        _progress(ctx, f"Counting instances for view {index}/{len(views)}: {view_name}", index - 1, len(views))
        suffix = _view_suffix(view_name)
        table = f"{config.DB_NAME}.{_table_name(view_name)}"
        try:
            counts = _fetch_branch_counts(table, group['parentException'].iloc[0].strip() or suffix)
        except Exception as exc:
            raise RuntimeError(f"Could not read table {table} (was step 1 run for it?): {exc}") from exc

        for _, count in counts.iterrows():
            branch_code = _to_branch_code(count.get('source_branch'))
            if branch_code is None:
                _issue(ctx, logging.WARNING, f"{table}: skipped a row without a valid source_branch")
                continue

            exception_name = str(count.get('exception_name', '')).strip()
            meta = _match_exception(group, exception_name)
            instances = pd.to_numeric(count.get('instances', 0), errors='coerce')
            row = _report_row(
                meta, branch_code, branch_info.get(branch_code, {}),
                instances=0 if pd.isna(instances) else int(instances),
                exception_name=exception_name or meta['parentException'].strip() or suffix,
                table=table,
            )
            if use_llm:
                use_llm = _add_ai_summary(ctx, row)
            rows.append(row)

    if not rows:
        _issue(ctx, logging.WARNING, "No exception instances found; no branch reports created")
        return

    report = pd.DataFrame(rows)
    branch_root = os.path.join(ctx['downloads_dir'], BRANCH_DATA_FOLDER)
    _progress(ctx, f"Writing {report['Branch Code'].nunique()} branch report(s)", len(views), len(views))
    for branch_code, branch_report in report.groupby('Branch Code', sort=False):
        branch_dir = os.path.join(branch_root, str(branch_code))
        os.makedirs(branch_dir, exist_ok=True)
        output_path = os.path.join(branch_dir, REPORT_CSV)
        branch_report.to_csv(output_path, index=False, encoding='utf-8')
        logger.log(SUCCESS, "Aggregate branch report created: %s", output_path)

    logger.log(SUCCESS, "Created %d branch report(s)", report['Branch Code'].nunique())


def _add_ai_summary(ctx, row):
    """Replace the row's Issue Description with an AI summary.

    Returns False when the gateway is unreachable, so the remaining rows skip
    AI summaries instead of each waiting for the same connection failure.
    """
    try:
        summary = llm_client.summarize_exception(pd.Series(row), max_tokens=200)
    except requests.ConnectionError as exc:
        _issue(ctx, logging.WARNING, "AI gateway unreachable; the remaining rows keep their "
                                     f"original issue descriptions ({exc})")
        return False
    except Exception as exc:
        _issue(ctx, logging.WARNING, f"AI summary skipped for {row['exception_name']} "
                                     f"(branch {row['Branch Code']}): {exc}")
        return True
    if summary:
        row['Issue Description'] = summary
    return True


# ----------------------------------------------------------------------------
# Step 4: Excel formatting
# ----------------------------------------------------------------------------

def execute_step_4(ctx):
    """Save every branch report as an Excel workbook."""
    branches = list(_branch_dirs(ctx['downloads_dir']))
    if not branches:
        _issue(ctx, logging.WARNING, "No branch reports found to convert; run step 3 first")
        return

    converted = 0
    for index, (branch_code, branch_path) in enumerate(branches, start=1):
        _check_stop(ctx)
        _progress(ctx, f"Creating Excel report for branch {branch_code} ({index}/{len(branches)})",
                  index - 1, len(branches))
        try:
            df = _read_branch_report(branch_path)
            if df is None:
                _issue(ctx, logging.WARNING, f"Branch {branch_code}: report is empty, skipped")
                continue
            df.to_excel(os.path.join(branch_path, REPORT_XLSX), sheet_name='Exceptions Report',
                        index=False, engine='openpyxl')
            converted += 1
        except Exception as exc:
            _issue(ctx, logging.ERROR, f"Branch {branch_code}: Excel report failed: {exc}")

    _progress(ctx, f"Created {converted} Excel report(s)", len(branches), len(branches))
    logger.log(SUCCESS, "Formatted %d branch report(s) to Excel", converted)


# ----------------------------------------------------------------------------
# Step 5: Word audit reports & ZIP package
# ----------------------------------------------------------------------------

def execute_step_5(ctx):
    downloads_dir = ctx['downloads_dir']
    branches = list(_branch_dirs(downloads_dir))
    if not branches:
        _issue(ctx, logging.ERROR, "No branch reports found to package; run step 3 first")
        return

    if Document is None:
        _issue(ctx, logging.ERROR, "python-docx is not installed (pip install python-docx); "
                                   "Word reports skipped")
    else:
        for index, (branch_code, branch_path) in enumerate(branches, start=1):
            _check_stop(ctx)
            _progress(ctx, f"Creating Word report for branch {branch_code} ({index}/{len(branches)})",
                      index - 1, len(branches))
            try:
                df = _read_branch_report(branch_path)
                if df is None:
                    _issue(ctx, logging.WARNING, f"Branch {branch_code}: report is empty, skipped")
                    continue
                filename = f"Audit_Report_Branch_{branch_code}.docx"
                create_branch_word_report(df, branch_code).save(os.path.join(branch_path, filename))
            except Exception as exc:
                logger.exception("Word report failed for branch %s", branch_code)
                _issue(ctx, logging.ERROR, f"Branch {branch_code}: Word report failed: {exc}")

    _progress(ctx, "Packaging all reports into a ZIP file", len(branches), len(branches))
    create_zip_archive(downloads_dir)


def _non_blank(series):
    return series.notna() & (series.astype(str).str.strip() != '') & (series.astype(str).str.lower() != 'nan')


def create_branch_word_report(df, branch_code):
    """Word report: cover page, table of contents, then issues grouped by theme/sub-theme."""
    doc = Document()
    normal = doc.styles['Normal'].font
    normal.name = 'Calibri'
    normal.size = Pt(11)

    # Cover page
    _add_centered_text(doc, 'AUDIT REPORT', size=28, bold=True, color=RGBColor(0, 51, 102))
    doc.add_paragraph()
    doc.add_paragraph()
    _add_centered_text(doc, f'Branch Code: {branch_code}', size=18, bold=True)
    doc.add_paragraph()
    _add_centered_text(doc, f'Report Generated: {datetime.now().strftime("%B %d, %Y")}', size=12)
    doc.add_page_break()

    df = df[_non_blank(df['Theme'])]
    df = df[_non_blank(df['Sub-Theme'])]

    # Table of contents
    doc.add_heading('Table of Contents', level=1).alignment = WD_ALIGN_PARAGRAPH.LEFT
    sections = df.groupby(['Theme', 'Sub-Theme'], sort=False).size().reset_index()
    for page, (_, section) in enumerate(sections.iterrows(), start=3):
        entry = doc.add_paragraph(style='List Number')
        entry.add_run(f"{str(section['Theme']).strip()} - {str(section['Sub-Theme']).strip()}")
        entry.add_run(f"\t\t\t\tPage {page}")
    doc.add_page_break()

    # Issues by theme / sub-theme
    for theme in df['Theme'].unique():
        heading = doc.add_heading(str(theme).strip(), level=1)
        heading.runs[0].font.color.rgb = RGBColor(0, 51, 102)
        theme_df = df[df['Theme'] == theme]

        for sub_theme in theme_df['Sub-Theme'].unique():
            heading = doc.add_heading(str(sub_theme).strip(), level=2)
            heading.runs[0].font.color.rgb = RGBColor(51, 102, 153)

            descriptions = theme_df.loc[theme_df['Sub-Theme'] == sub_theme, 'Issue Description']
            descriptions = [str(d).strip() for d in descriptions[_non_blank(descriptions)]]
            for description in descriptions:
                bullet = doc.add_paragraph(style='List Bullet')
                bullet.add_run(description)
                bullet.paragraph_format.left_indent = Inches(0.5)
                bullet.paragraph_format.space_after = Pt(6)
            if not descriptions:
                doc.add_paragraph().add_run("No detailed issue descriptions available.").italic = True

            doc.add_paragraph()
        doc.add_paragraph()

    return doc


def _add_centered_text(doc, text, size, bold=False, color=None):
    paragraph = doc.add_paragraph()
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = paragraph.add_run(text)
    run.font.size = Pt(size)
    if bold:
        run.font.bold = True
    if color is not None:
        run.font.color.rgb = color


def create_zip_archive(downloads_dir):
    """Zip the whole branch_data tree into downloads/execution_<timestamp>.zip."""
    branch_root = os.path.join(downloads_dir, BRANCH_DATA_FOLDER)
    zip_name = f"execution_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
    zip_path = os.path.join(downloads_dir, zip_name)

    logger.info("Creating archive: %s", zip_name)
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for folder, _, files in os.walk(branch_root):
            for filename in files:
                path = os.path.join(folder, filename)
                zf.write(path, os.path.join(BRANCH_DATA_FOLDER, os.path.relpath(path, branch_root)))

    size_mb = os.path.getsize(zip_path) / (1024 * 1024)
    branch_count = sum(1 for _ in _branch_dirs(downloads_dir))
    logger.log(SUCCESS, "ZIP archive created: %s (%.2f MB, %d branch folder(s))",
               zip_name, size_mb, branch_count)


# ----------------------------------------------------------------------------
# Dispatcher
# ----------------------------------------------------------------------------

STEP_FUNCTIONS = {
    1: execute_step_1,
    2: execute_step_2,
    3: execute_step_3,
    4: execute_step_4,
    5: execute_step_5,
}

STEP_NAMES = {
    1: 'Rule-based exception identification',
    2: 'Segregate data branch-wise',
    3: 'Prepare final exceptions report (Generative AI)',
    4: 'Format reports in Excel',
    5: 'Prepare Word audit reports & ZIP',
}


def execute_step(step, ctx):
    step_func = STEP_FUNCTIONS.get(int(step))
    if step_func is None:
        raise ValueError(f"Unknown step: {step}")
    step_func(ctx)

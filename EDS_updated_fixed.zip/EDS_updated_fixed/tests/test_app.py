"""End-to-end tests with the database and LLM gateway replaced by fakes.

Run from the project folder:  python -m unittest discover tests -v
All files are written to a temporary folder; the real data/ folder is only read.
"""

import io
import os
import shutil
import sys
import tempfile
import time
import unittest
import zipfile
from unittest import mock

import pandas as pd

PROJECT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TEMP_DIR = tempfile.mkdtemp(prefix='eds_test_')
for env_var, folder in (('EDS_DATA_DIR', 'data'), ('EDS_LOG_DIR', 'logs'), ('EDS_DOWNLOADS_DIR', 'downloads')):
    os.environ[env_var] = os.path.join(TEMP_DIR, folder)
os.makedirs(os.path.join(TEMP_DIR, 'data'))
for name in ('exceptions_v2.csv', 'meta_data.xlsx'):
    source = os.path.join(PROJECT_DIR, 'data', name)
    if os.path.exists(source):
        shutil.copy(source, os.path.join(TEMP_DIR, 'data', name))
pd.DataFrame({
    'source_branch': [101, 202],
    'branch_name': ['Main Branch', 'City Branch'],
    'hub': ['North Hub', 'South Hub'],
    'region': ['North', 'South'],
}).to_csv(os.path.join(TEMP_DIR, 'data', 'branch_information.csv'), index=False)

sys.path.insert(0, PROJECT_DIR)
import app as app_module  # noqa: E402
import config  # noqa: E402
import steps_handler  # noqa: E402

from flask.testing import FlaskClient  # noqa: E402

VIEW_WITH_ERRORS = 'FCCM_UAT.DS_001_fast_cash_invalid_cnic_V3_vw'


class CsrfClient(FlaskClient):
    """Test client that sends the session's CSRF token like the real frontend does."""

    def open(self, *args, **kwargs):
        method = kwargs.get('method', 'GET')
        headers = dict(kwargs.pop('headers', None) or {})
        if method != 'GET' and 'X-CSRF-Token' not in headers:
            headers['X-CSRF-Token'] = super().open('/api/csrf').get_json()['token']
        return super().open(*args, headers=headers, **kwargs)


app_module.app.test_client_class = CsrfClient


class FakeDatabase:
    """Records statements and answers the aggregate queries of step 3."""

    def __init__(self):
        self.statements = []
        self.fail_on = None

    def execute(self, sql):
        if self.fail_on and self.fail_on in sql:
            raise RuntimeError('simulated database error')
        self.statements.append(sql)

    def query_to_dataframe(self, sql):
        self.statements.append(sql)
        if 'DS_DS_001_' in sql:  # Table with an `error` column holding two exceptions
            if 'error' not in sql:
                raise AssertionError('grouped query expected first')
            return pd.DataFrame({'SOURCE_BRANCH': ['101', '101', '202'],
                                 'EXCEPTION_NAME': ['DS_001_fast_cash_invalid_cnic_V3_vw', 'Other issue', 'DS_001_fast_cash_invalid_cnic_V3_vw'],
                                 'INSTANCES': [5, 2, 7]})
        if 'error' in sql:
            raise RuntimeError("Could not resolve column 'error'")
        return pd.DataFrame({'source_branch': [202, None], 'instances': [3, 1]})


def wait_for_execution(client, exec_id, timeout=30):
    deadline = time.time() + timeout
    while time.time() < deadline:
        status = client.get(f'/api/execution/{exec_id}/status').get_json()
        if status['status'] != 'in_progress':
            return status
        time.sleep(0.1)
    raise AssertionError('execution did not finish')


class BaseTest(unittest.TestCase):

    def setUp(self):
        self.client = app_module.app.test_client()
        self.db = FakeDatabase()
        patches = [
            mock.patch('database.execute', self.db.execute),
            mock.patch('database.query_to_dataframe', self.db.query_to_dataframe),
            mock.patch('llm_client.generate_text', side_effect=lambda prompt, max_tokens: 'AI SUMMARY'),
        ]
        for p in patches:
            p.start()
            self.addCleanup(p.stop)
        with app_module.executions_lock:
            app_module.executions.clear()
        app_module.login_throttle.reset('127.0.0.1')

    def login(self):
        res = self.client.post('/api/login', json={'username': 'admin', 'password': 'Admin@123'})
        self.assertEqual(res.status_code, 200)


class AuthTests(BaseTest):

    def test_pages_and_api_require_login(self):
        res = self.client.get('/')
        self.assertEqual(res.status_code, 302)
        self.assertTrue(res.headers['Location'].endswith('/login'))
        self.assertEqual(self.client.get('/api/exceptions').status_code, 401)
        self.assertEqual(self.client.get('/api/download/anything.zip').status_code, 401)

    def test_test_run_is_isolated_from_project_folders(self):
        for path in (config.DATA_DIR, config.LOG_DIR, config.DOWNLOADS_DIR, config.CONSOLE_LOG):
            self.assertTrue(path.startswith(TEMP_DIR), path)

    def test_login_page_and_assets_are_public(self):
        self.assertEqual(self.client.get('/login').status_code, 200)
        self.assertEqual(self.client.get('/static/styles.css').status_code, 200)
        self.assertEqual(self.client.get('/api/health').status_code, 200)

    def test_wrong_credentials_rejected(self):
        for username, password in [('admin', 'admin'), ('Admin', 'Admin@123'), ('', ''), ('admin', '')]:
            res = self.client.post('/api/login', json={'username': username, 'password': password})
            self.assertEqual(res.status_code, 401, (username, password))

    def test_login_and_logout(self):
        self.login()
        self.assertEqual(self.client.get('/').status_code, 200)
        self.assertEqual(self.client.get('/api/session').get_json(), {'user': 'admin'})
        self.assertEqual(self.client.get('/login').status_code, 302)
        self.client.post('/api/logout')
        self.assertEqual(self.client.get('/api/exceptions').status_code, 401)

    def test_login_requires_json_body(self):
        res = self.client.post('/api/login', data='username=admin&password=Admin@123',
                               content_type='application/x-www-form-urlencoded')
        self.assertEqual(res.status_code, 401)


class ExceptionAndMetadataTests(BaseTest):

    def setUp(self):
        super().setUp()
        self.login()

    def test_list_exceptions(self):
        data = self.client.get('/api/exceptions').get_json()
        self.assertGreater(len(data['exceptions']), 0)
        self.assertTrue(set(data['themes_exceptions']) <= set(data['themes_union']))
        meta = self.client.get('/api/meta').get_json()
        self.assertTrue(all(isinstance(t['theme'], str) for t in meta['themes']))
        self.assertTrue(all(isinstance(v, str) for v in meta['risk_types']))

    def test_exception_crud_and_theme_management(self):
        new = {'theme': "Test's Theme", 'subTheme': 'Sub <A>', 'issueRiskRating': 'High',
               'subThemeRiskRating': 'Low', 'issueDescription': 'desc', 'riskType': 'Operational',
               'issueType': 'Design', 'issueOwner': 'Risk Team', 'exceptionName': 'Test exception',
               'parentException': '', 'viewName': 'FCCM_UAT.DS_999_test_vw'}
        res = self.client.post('/api/exceptions', json=new)
        self.assertEqual(res.status_code, 201)
        ex_id = res.get_json()['id']

        meta = self.client.get('/api/meta').get_json()
        self.assertIn({'theme': "Test's Theme"}, meta['themes'])
        self.assertIn({'subTheme': 'Sub <A>', 'parentTheme': "Test's Theme"}, meta['sub_themes'])

        res = self.client.put(f'/api/exceptions/{ex_id}', json={'issueRiskRating': 'Medium'})
        self.assertEqual(res.status_code, 200)
        items = {x['id']: x for x in self.client.get('/api/exceptions').get_json()['exceptions']}
        self.assertEqual(items[ex_id]['issueRiskRating'], 'Medium')
        self.assertEqual(items[ex_id]['exceptionName'], 'Test exception')

        # Renaming a theme updates metadata, its sub-themes and the exceptions using it
        self.client.put('/api/meta/theme', json={'oldName': "Test's Theme", 'newName': 'Renamed'})
        self.client.put('/api/meta/subtheme', json={'oldName': 'Sub <A>', 'oldParent': 'Renamed',
                                                    'newName': 'Sub B', 'newParent': 'Renamed'})
        items = {x['id']: x for x in self.client.get('/api/exceptions').get_json()['exceptions']}
        self.assertEqual((items[ex_id]['theme'], items[ex_id]['subTheme']), ('Renamed', 'Sub B'))
        meta = self.client.get('/api/meta').get_json()
        self.assertIn({'subTheme': 'Sub B', 'parentTheme': 'Renamed'}, meta['sub_themes'])

        self.assertEqual(self.client.delete(f'/api/exceptions/{ex_id}').status_code, 200)
        self.assertEqual(self.client.delete(f'/api/exceptions/{ex_id}').status_code, 404)
        self.client.delete('/api/meta/theme', json={'name': 'Renamed'})
        meta = self.client.get('/api/meta').get_json()
        self.assertNotIn({'theme': 'Renamed'}, meta['themes'])
        self.assertFalse(any(st['parentTheme'] == 'Renamed' for st in meta['sub_themes']))

    def test_rename_unknown_theme_is_404(self):
        res = self.client.put('/api/meta/theme', json={'oldName': 'nope', 'newName': 'x'})
        self.assertEqual(res.status_code, 404)

    def test_console_tail_returns_only_new_lines(self):
        first = self.client.get('/api/console/tail').get_json()
        app_module.logger.info('console tail marker')
        for handler in app_module.logging.getLogger().handlers:
            handler.flush()
        second = self.client.get(f"/api/console/tail?offset={first['offset']}").get_json()
        self.assertTrue(any('console tail marker' in line and '[INFO]' in line for line in second['lines']))
        third = self.client.get(f"/api/console/tail?offset={second['offset']}").get_json()
        self.assertEqual(third['lines'], [])


class SecurityTests(BaseTest):
    """Controls added for the SAST / security-assessment findings."""

    def test_security_headers_on_every_response(self):
        for path in ('/login', '/api/health', '/static/app.js'):
            headers = self.client.get(path).headers
            self.assertIn("frame-ancestors 'none'", headers['Content-Security-Policy'], path)
            self.assertIn("script-src 'self'", headers['Content-Security-Policy'], path)
            self.assertEqual(headers['X-Frame-Options'], 'DENY')
            self.assertEqual(headers['X-Content-Type-Options'], 'nosniff')
            self.assertIn('max-age=31536000', headers['Strict-Transport-Security'])
        self.assertEqual(self.client.get('/api/health').headers['Cache-Control'], 'no-store')

    def test_csrf_token_required_for_state_changes(self):
        self.login()
        for method, path in [('post', '/api/meta/theme'), ('put', '/api/exceptions/1'),
                             ('delete', '/api/exceptions/1'), ('post', '/api/logout')]:
            for token in ('', 'forged-token'):
                res = getattr(self.client, method)(path, json={'name': 'x'}, headers={'X-CSRF-Token': token})
                self.assertEqual(res.status_code, 403, (method, path, token))
        self.assertEqual(self.client.get('/api/session').status_code, 200)  # Still logged in

    def test_login_rotates_session_and_csrf_token(self):
        before = self.client.get('/api/csrf').get_json()['token']
        self.login()
        after = self.client.get('/api/csrf').get_json()['token']
        self.assertNotEqual(before, after)

    def test_login_lockout_after_repeated_failures(self):
        for _ in range(config.LOGIN_MAX_FAILURES):
            res = self.client.post('/api/login', json={'username': 'admin', 'password': 'bad'})
            self.assertEqual(res.status_code, 401)
        res = self.client.post('/api/login', json={'username': 'admin', 'password': 'Admin@123'})
        self.assertEqual(res.status_code, 429)  # Even the right password is refused while locked

    def test_session_cookie_flags(self):
        res = self.client.post('/api/login', json={'username': 'admin', 'password': 'Admin@123'})
        cookie = res.headers['Set-Cookie']
        self.assertIn('HttpOnly', cookie)
        self.assertIn('SameSite=Lax', cookie)

    def test_download_path_traversal_blocked(self):
        self.login()
        for name in ('..%2Fdata%2Fexceptions_v2.csv', '..%5Capp.py', 'not_generated.zip'):
            self.assertEqual(self.client.get(f'/api/download/{name}').status_code, 404, name)
        self.assertEqual(self.client.get('/api/download/../app.py').status_code, 404)

    def test_input_validation(self):
        self.login()
        base = {'theme': 'T', 'subTheme': 'S', 'exceptionName': 'E'}
        for view in ("FCCM_UAT.x; DROP TABLE y", 'a.b.c', '../etc', 'x y'):
            res = self.client.post('/api/exceptions', json={**base, 'viewName': view})
            self.assertEqual(res.status_code, 400, view)
        res = self.client.post('/api/exceptions', json={**base, 'viewName': 'S.V', 'exceptionName': 'x' * 301})
        self.assertEqual(res.status_code, 400)
        res = self.client.post('/api/meta/theme', json={'name': 'Bad\x00Name\x1b'})
        self.assertEqual(res.status_code, 200)
        self.assertIn({'theme': 'BadName'}, self.client.get('/api/meta').get_json()['themes'])
        self.client.delete('/api/meta/theme', json={'name': 'BadName'})

    def test_execution_parameters_validated(self):
        self.login()
        bad = [{'startDate': "2025-01-01' OR '1'='1"}, {'branches': "101'); DROP TABLE x;--"}]
        for params in bad:
            res = self.client.post('/api/execute', json={'exception_ids': [1], 'steps': [2], 'parameters': params})
            self.assertEqual(res.status_code, 400, params)

    def test_responses_do_not_echo_user_input(self):
        self.login()
        res = self.client.post('/api/meta/theme', json={'name': '<script>alert(1)</script>'})
        self.assertNotIn(b'<script>', res.data)
        self.client.delete('/api/meta/theme', json={'name': '<script>alert(1)</script>'})

    def test_unexpected_errors_are_not_exposed(self):
        self.login()
        with mock.patch.object(app_module.metadata_store, 'read',
                               side_effect=RuntimeError('secret DSN details')):
            res = self.client.get('/api/meta')
        self.assertEqual(res.status_code, 500)
        self.assertEqual(res.get_json(), {'error': 'Internal server error'})

    def test_llm_output_sanitized(self):
        import llm_client
        reply = '  Summary\x00 text\x1b[31m ' + 'x' * 5000
        cleaned = llm_client._clean_reply(reply)
        self.assertNotIn('\x00', cleaned)
        self.assertNotIn('\x1b', cleaned)
        self.assertEqual(len(cleaned), config.LLM_MAX_SUMMARY_CHARS)

    def test_audit_log_records_actions(self):
        self.login()
        self.client.post('/api/meta/theme', json={'name': 'Audited Theme'})
        self.client.delete('/api/meta/theme', json={'name': 'Audited Theme'})
        for handler in app_module.logging.getLogger('audit').handlers:
            handler.flush()
        with open(os.path.join(config.LOG_DIR, 'audit.log'), encoding='utf-8') as f:
            audit = f.read()
        self.assertIn("user=admin ip=127.0.0.1 action=login", audit)
        self.assertIn("action=theme_add name='Audited Theme'", audit)
        self.assertIn("action=theme_delete name='Audited Theme'", audit)


class QueryBuildingTests(unittest.TestCase):

    def test_branches_split_on_commas_and_newlines(self):
        self.assertEqual(steps_handler.parse_branches(' 101, 202\n303\r\n,'), ['101', '202', '303'])

    def test_build_query(self):
        query = steps_handler.build_query('FCCM_UAT.DS_001_vw', {'branches': "101,20'2",
                                                                'startDate': '2025-01-01', 'endDate': '2025-02-01'})
        self.assertEqual(query, "SELECT * FROM FCCM_UAT.DS_001_vw WHERE source_branch IN ('101','20''2')")

    def test_unsafe_view_names_rejected(self):
        for view in ('FCCM_UAT.x; DROP TABLE y', 'a.b-c', ''):
            with self.assertRaises(ValueError):
                steps_handler.build_query(view, {})


class ExecutionTests(BaseTest):

    def setUp(self):
        super().setUp()
        self.login()
        exceptions = self.client.get('/api/exceptions').get_json()['exceptions']
        self.ids = [x['id'] for x in exceptions[:3]]
        self.views = {x['viewName'].strip() for x in exceptions[:3]}

    def run_steps(self, steps, branches='101, 202'):
        res = self.client.post('/api/execute', json={
            'exception_ids': self.ids, 'steps': steps,
            'parameters': {'startDate': '2025-01-01', 'endDate': '2025-12-31', 'branches': branches}})
        self.assertEqual(res.status_code, 200, res.get_json())
        return wait_for_execution(self.client, res.get_json()['execution_id'])

    def test_full_pipeline(self):
        status = self.run_steps([1, 2, 3, 4, 5])
        self.assertEqual(status['status'], 'completed', status['message'])

        creates = [s for s in self.db.statements if s.startswith('CREATE TABLE')]
        self.assertEqual(len(creates), len(self.views))
        self.assertIn(f"CREATE TABLE FCCM_UAT.DS_DS_001_fast_cash_invalid_cnic_V3_vw AS "
                      f"SELECT * FROM {VIEW_WITH_ERRORS} WHERE source_branch IN ('101','202')", creates)
        self.assertTrue(any(s.startswith('DROP TABLE IF EXISTS FCCM_UAT.DS_') for s in self.db.statements))

        branch_root = os.path.join(config.DOWNLOADS_DIR, 'branch_data')
        self.assertEqual(sorted(os.listdir(branch_root)), ['101', '202'])
        report = pd.read_csv(os.path.join(branch_root, '101', 'exceptions_report.csv'))
        self.assertEqual(list(report.columns), [
            'Theme', 'Sub-Theme', 'Branch Code', 'Branch Name', 'Audit Region', 'Business Region',
            'Audit Year', 'Issue Risk Rating', 'Sub - Theme Risk Rating', 'Risk Type',
            'Issue Type (Design / Operational Error)', 'Issue Owner', 'Issue Description',
            'Instances', 'Selected Sample', 'exception_name', 'source_table'])
        self.assertEqual(report['Instances'].tolist(), [5, 2])
        self.assertEqual(report['Branch Name'].iloc[0], 'Main Branch')
        self.assertTrue((report['Issue Description'] == 'AI SUMMARY').all())

        for branch in ('101', '202'):
            files = os.listdir(os.path.join(branch_root, branch))
            self.assertIn('exceptions_report.xlsx', files)
            self.assertIn(f'Audit_Report_Branch_{branch}.docx', files)

        downloads = self.client.get('/api/downloads').get_json()['downloads']
        self.assertEqual(len(downloads), 1)
        zip_name = downloads[0]['file']
        self.assertRegex(zip_name, r'^execution_\d{8}_\d{6}\.zip$')
        res = self.client.get(f'/api/download/{zip_name}')
        self.assertEqual(res.status_code, 200)
        with zipfile.ZipFile(io.BytesIO(res.data)) as zf:
            names = zf.namelist()
        self.assertIn('branch_data/101/Audit_Report_Branch_101.docx', names)
        self.assertFalse(any('Combined' in n for n in names))

        log = self.client.get('/api/execution/log').get_json()
        self.assertGreaterEqual(log['successful'], len(self.views))

        # Structured progress for the UI
        self.assertEqual([s['status'] for s in status['steps']], ['completed'] * 5)
        self.assertEqual(status['steps'][0]['name'], 'Rule-based exception identification')
        self.assertTrue(all(s['duration_seconds'] is not None for s in status['steps']))
        self.assertTrue(any('without a valid source_branch' in i['message'] and i['step'] == 3
                            for i in status['issues']))
        self.assertIn('issue(s)', status['message'])
        current = self.client.get('/api/execution/current').get_json()['execution']
        self.assertEqual((current['id'], current['status']), (status['id'], 'completed'))

    def test_combined_analytics_step_is_gone(self):
        res = self.client.post('/api/execute', json={'exception_ids': self.ids, 'steps': [6]})
        self.assertEqual(res.status_code, 400)

    def test_step_1_failure_fails_execution(self):
        self.db.fail_on = 'CREATE TABLE'
        status = self.run_steps([1, 3])
        self.assertEqual(status['status'], 'failed')
        self.assertIn('Step 1', status['message'])
        self.assertIn('view(s) failed', status['message'])
        self.assertFalse(any('GROUP BY' in s for s in self.db.statements))

        # The UI sees which step failed, why, and which views caused it
        self.assertEqual([s['status'] for s in status['steps']], ['failed', 'skipped'])
        self.assertIn('view(s) failed', status['steps'][0]['error'])
        view_errors = [i for i in status['issues'] if i['level'] == 'ERROR']
        self.assertEqual(len(view_errors), len(self.views))
        self.assertTrue(all('simulated database error' in i['message'] for i in view_errors))

        # Console log: one line per message, tagged with the step; tracebacks go to errors.log
        for handler in app_module.logging.getLogger().handlers:
            handler.flush()
        with open(config.CONSOLE_LOG, encoding='utf-8') as f:
            console_lines = f.read().splitlines()
        self.assertTrue(all(line.startswith('[') for line in console_lines))
        self.assertTrue(any('[ERROR] [Step 1] View FCCM_UAT.' in line for line in console_lines))
        self.assertFalse(any('Traceback' in line for line in console_lines))
        with open(os.path.join(config.LOG_DIR, 'errors.log'), encoding='utf-8') as f:
            self.assertIn('Traceback', f.read())

    def test_llm_unreachable_falls_back_to_description(self):
        import requests
        with mock.patch('llm_client.generate_text', side_effect=requests.ConnectionError('down')) as gen:
            status = self.run_steps([3])
        self.assertEqual(status['status'], 'completed')
        self.assertEqual(gen.call_count, 1)  # Gave up after the first connection failure
        self.assertTrue(any('AI gateway unreachable' in i['message'] for i in status['issues']))
        report = pd.read_csv(os.path.join(config.DOWNLOADS_DIR, 'branch_data', '101', 'exceptions_report.csv'))
        self.assertNotIn('AI SUMMARY', report['Issue Description'].tolist())

    def test_stop_execution(self):
        started = []

        def slow_step(ctx):
            started.append(1)
            time.sleep(0.5)

        with mock.patch.dict(steps_handler.STEP_FUNCTIONS, {2: slow_step, 3: slow_step, 4: slow_step}):
            res = self.client.post('/api/execute', json={'exception_ids': self.ids, 'steps': [2, 3, 4]})
            exec_id = res.get_json()['execution_id']
            time.sleep(0.1)
            second = self.client.post('/api/execute', json={'exception_ids': self.ids, 'steps': [2]})
            self.assertEqual(second.status_code, 409)
            self.client.post(f'/api/execution/{exec_id}/stop')
            status = wait_for_execution(self.client, exec_id)
        self.assertEqual(status['status'], 'stopped')
        self.assertEqual(len(started), 1)
        self.assertEqual([s['status'] for s in status['steps']], ['completed', 'skipped', 'skipped'])


def tearDownModule():
    import logging
    for handler in logging.getLogger().handlers:
        handler.close()
    shutil.rmtree(TEMP_DIR, ignore_errors=True)


if __name__ == '__main__':
    unittest.main()

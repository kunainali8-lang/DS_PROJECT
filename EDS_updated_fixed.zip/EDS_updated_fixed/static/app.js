// Exception Detection System - frontend logic. Relies on `api` from api.js.

const RISK_RATINGS = ['High', 'Medium', 'Low'];
const CONSOLE_MAX_LINES = 2000;
const CONSOLE_POLL_IDLE_MS = 3000;
const CONSOLE_POLL_BUSY_MS = 500;
const STATUS_POLL_MS = 2000;

const state = {
  section: 'dashboard',
  exceptions: [],
  meta: { themes: [], sub_themes: [], risk_types: [], issue_types: [], issue_owners: [] },
  themes: [],          // Every known theme (metadata + used by exceptions)
  subThemes: [],       // [{subTheme, parentTheme}] from metadata
  downloads: [],
  expanded: new Set(), // Expanded nodes in the View Exceptions tree
  consoleOffset: null,
  lastExecution: null,
  execution: { id: null, inProgress: false, exceptionIds: [], steps: [] },
};

// ============================================================================
// Utilities
// ============================================================================

const $ = (id) => document.getElementById(id);

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));
}

function plural(count, word) {
  return `${count} ${word}${count === 1 ? '' : 's'}`;
}

function unique(values) {
  return [...new Set(values.filter(Boolean))];
}

function treeKey(theme, subTheme) {
  return JSON.stringify(subTheme === undefined ? [theme] : [theme, subTheme]);
}

/** Fill a <select>, keeping its current value (even if no longer in the list). */
function setOptions(id, values, placeholder = 'Select') {
  const select = $(id);
  if (!select) return;
  const current = select.value;
  const options = unique(values);
  if (current && !options.includes(current)) options.push(current);
  select.replaceChildren(new Option(placeholder, ''), ...options.map((v) => new Option(v, v)));
  select.value = current;
}

function setValue(id, value) {
  const el = $(id);
  if (el) el.value = value ?? '';
}

function getValue(id) {
  return ($(id)?.value || '').trim();
}

function showError(action, error) {
  console.error(error);
  logToConsole(`Error ${action}: ${error.message}`, 'error');
  alert(`Failed ${action}: ${error.message}`);
}

// ============================================================================
// Console
// ============================================================================

const CONSOLE_FILTERS = {
  all: () => true,
  problems: (type) => type === 'warning' || type === 'error',
  errors: (type) => type === 'error',
};

function consoleFilter() {
  return CONSOLE_FILTERS[$('console-filter').value] || CONSOLE_FILTERS.all;
}

function appendConsoleLine(text, type) {
  const consoleEl = $('console');
  const entry = document.createElement('div');
  entry.className = `log-entry log-${type}`;
  if (text.includes('=====')) entry.classList.add('log-step');
  entry.dataset.type = type;
  entry.textContent = text;
  entry.hidden = !consoleFilter()(type);
  consoleEl.appendChild(entry);
  while (consoleEl.childElementCount > CONSOLE_MAX_LINES) consoleEl.firstElementChild.remove();
  if ($('console-autoscroll').checked) consoleEl.scrollTop = consoleEl.scrollHeight;
}

function applyConsoleFilter() {
  const show = consoleFilter();
  $('console').querySelectorAll('.log-entry').forEach((el) => { el.hidden = !show(el.dataset.type); });
  $('console').scrollTop = $('console').scrollHeight;
}

function logToConsole(message, type = 'info') {
  appendConsoleLine(`[${new Date().toLocaleTimeString()}] ${message}`, type);
}

function lineType(line) {
  const level = (line.match(/\] \[(INFO|WARN|ERROR|SUCCESS)\]/) || [])[1];
  return { WARN: 'warning', ERROR: 'error', SUCCESS: 'success' }[level] || 'info';
}

async function pollConsole() {
  try {
    const res = await api.consoleTail(state.consoleOffset);
    res.lines.forEach((line) => appendConsoleLine(line, lineType(line)));
    state.consoleOffset = res.offset;
  } catch (e) {
    console.error('Console fetch error:', e);
  }
  const delay = state.execution.inProgress ? CONSOLE_POLL_BUSY_MS : CONSOLE_POLL_IDLE_MS;
  setTimeout(pollConsole, delay);
}

// ============================================================================
// Data loading
// ============================================================================

async function refreshData() {
  try {
    const [exceptionsRes, meta] = await Promise.all([api.getExceptions(), api.getMeta()]);
    state.exceptions = exceptionsRes.exceptions;
    state.themes = exceptionsRes.themes_union;
    state.subThemes = exceptionsRes.subthemes_meta;
    state.meta = meta;
  } catch (e) {
    console.error(e);
    logToConsole(`Error loading data: ${e.message}`, 'error');
    return;
  }
  updateDashboard();
  populateDropdowns();
  renderSection(state.section);
}

async function refreshDownloads() {
  try {
    state.downloads = (await api.getDownloads()).downloads;
  } catch (e) {
    logToConsole(`Error fetching downloads: ${e.message}`, 'error');
  }
  renderDownloads();
}

// ============================================================================
// Navigation
// ============================================================================

function showSection(section) {
  state.section = section;
  document.querySelectorAll('.section').forEach((el) => {
    el.classList.toggle('hidden', el.id !== `${section}-section`);
  });
  document.querySelectorAll('.menu-item').forEach((el) => {
    el.classList.toggle('active', el.dataset.section === section);
  });

  if (section === 'add-exception') $('exception-form').reset();
  if (section === 'execute') {
    if (state.execution.id) showWizardStep('wizard-progress');  // Keep showing the current/last run
    else resetWizard();
  }
  if (section === 'downloads') refreshDownloads();
  renderSection(section);
}

function renderSection(section) {
  switch (section) {
    case 'dashboard': updateDashboard(); break;
    case 'add-exception': populateDropdowns(); break;
    case 'view-exceptions': renderHierarchy(); break;
    case 'execute': if (!state.execution.inProgress) renderExceptionSelection(); break;
    case 'manage-themes': renderThemeLists(); break;
    case 'downloads': renderDownloads(); break;
  }
}

function updateDashboard() {
  $('total-exceptions').textContent = state.exceptions.length;
  const run = state.lastExecution;  // Latest execution snapshot from the server
  $('last-execution').textContent = run ? `${run.started_at} by ${run.user}` : 'Never';
  const result = $('last-execution-result');
  result.textContent = run ? `${RUN_STATUS[run.status].title}: ${run.message}` : '';
  result.className = run ? `run-result run-${run.status}` : '';
}

// ============================================================================
// Dropdowns
// ============================================================================

function subThemesFor(theme) {
  const fromMeta = state.subThemes
    .filter((st) => !theme || !st.parentTheme || st.parentTheme === theme)
    .map((st) => st.subTheme);
  const fromExceptions = state.exceptions
    .filter((ex) => !theme || ex.theme === theme)
    .map((ex) => ex.subTheme);
  return unique([...fromMeta, ...fromExceptions]);
}

function populateDropdowns() {
  setOptions('theme', state.themes);
  setOptions('sub-theme', subThemesFor(getValue('theme')));
  ['issue-risk-rating', 'sub-theme-risk-rating', 'modal-issue-risk-rating', 'modal-sub-theme-risk-rating']
    .forEach((id) => setOptions(id, RISK_RATINGS));
  ['', 'modal-'].forEach((prefix) => {
    setOptions(`${prefix}risk-type`, state.meta.risk_types);
    setOptions(`${prefix}issue-type`, state.meta.issue_types);
    setOptions(`${prefix}issue-owner`, state.meta.issue_owners);
  });
}

// ============================================================================
// Add Exception page
// ============================================================================

function readExceptionForm(prefix) {
  return {
    issueRiskRating: getValue(`${prefix}issue-risk-rating`),
    subThemeRiskRating: getValue(`${prefix}sub-theme-risk-rating`),
    issueDescription: getValue(`${prefix}issue-description`),
    riskType: getValue(`${prefix}risk-type`),
    issueType: getValue(`${prefix}issue-type`),
    issueOwner: getValue(`${prefix}issue-owner`),
    exceptionName: getValue(`${prefix}exception-name`),
    parentException: getValue(`${prefix}parent-exception`),
    viewName: getValue(`${prefix}view-name`),
  };
}

async function submitExceptionForm(event) {
  event.preventDefault();
  const data = { theme: getValue('theme'), subTheme: getValue('sub-theme'), ...readExceptionForm('') };
  try {
    await api.addException(data);
  } catch (e) {
    showError('adding exception', e);
    return;
  }
  logToConsole(`Exception "${data.exceptionName}" added successfully`, 'success');
  $('exception-form').reset();
  await refreshData();
  alert('Exception added successfully!');
}

// ============================================================================
// View Exceptions page (theme > sub-theme > exception tree)
// ============================================================================

/** Map(theme -> Map(subTheme -> exceptions[])) */
function buildTree(exceptions, includeEmpty) {
  const tree = new Map();
  const node = (theme, subTheme) => {
    if (!tree.has(theme)) tree.set(theme, new Map());
    const subs = tree.get(theme);
    if (subTheme !== undefined && !subs.has(subTheme)) subs.set(subTheme, []);
    return subs.get(subTheme);
  };

  exceptions.forEach((ex) => node(ex.theme, ex.subTheme).push(ex));
  if (includeEmpty) {
    state.themes.forEach((theme) => node(theme));
    state.subThemes
      .filter((st) => st.parentTheme && st.subTheme)
      .forEach((st) => node(st.parentTheme, st.subTheme));
  }
  return tree;
}

function renderHierarchy() {
  const container = $('hierarchy-view');
  const filter = getValue('search-exceptions').toLowerCase();
  const matches = (ex) => [ex.exceptionName, ex.theme, ex.subTheme, ex.issueDescription, ex.viewName]
    .some((field) => (field || '').toLowerCase().includes(filter));

  const tree = buildTree(filter ? state.exceptions.filter(matches) : state.exceptions, !filter);
  if (tree.size === 0) {
    container.innerHTML = filter
      ? '<p class="empty-message">No exceptions match your search.</p>'
      : '<p class="empty-message">No themes found. Add a theme or an exception to get started.</p>';
    return;
  }

  container.innerHTML = [...tree].map(([theme, subThemes]) => {
    const total = [...subThemes.values()].reduce((sum, list) => sum + list.length, 0);
    const open = filter || state.expanded.has(treeKey(theme));
    const t = escapeHtml(theme);
    return `
      <div class="theme-item">
        <div class="theme-header" data-action="toggle-node" data-key="${escapeHtml(treeKey(theme))}">
          <div class="theme-header-left">
            <span class="theme-toggle">${open ? '▼' : '▶'}</span>
            <div class="theme-info">
              <div class="theme-name">${t}</div>
              <div class="theme-count">${plural(subThemes.size, 'Sub-Theme')} · ${plural(total, 'Exception')}</div>
            </div>
          </div>
          <div class="theme-header-right">
            <button type="button" class="icon-btn" data-action="add-subtheme" data-theme="${t}">➕ Add Sub-Theme</button>
          </div>
        </div>
        <div class="theme-content ${open ? 'expanded' : ''}">
          ${[...subThemes].map(([sub, list]) => renderSubThemeNode(theme, sub, list, filter)).join('')}
        </div>
      </div>`;
  }).join('');
}

function renderSubThemeNode(theme, subTheme, exceptions, filter) {
  const open = filter || state.expanded.has(treeKey(theme, subTheme));
  const t = escapeHtml(theme);
  const s = escapeHtml(subTheme);
  return `
    <div class="subtheme-item">
      <div class="subtheme-header" data-action="toggle-node" data-key="${escapeHtml(treeKey(theme, subTheme))}">
        <div class="subtheme-header-left">
          <span class="theme-toggle">${open ? '▼' : '▶'}</span>
          <div class="subtheme-info">
            <div class="subtheme-name">${s}</div>
            <div class="subtheme-count">${plural(exceptions.length, 'Exception')}</div>
          </div>
        </div>
        <div class="theme-header-right">
          <button type="button" class="icon-btn" data-action="add-exception" data-theme="${t}" data-subtheme="${s}" title="Add exception">➕</button>
        </div>
      </div>
      <div class="subtheme-content ${open ? 'expanded' : ''}">
        ${exceptions.length ? exceptions.map(renderExceptionCard).join('')
                            : '<div class="no-exceptions">No exceptions in this sub-theme yet.</div>'}
      </div>
    </div>`;
}

function renderExceptionCard(ex) {
  const risk = (ex.issueRiskRating || '').toLowerCase();
  const riskClass = ['high', 'medium', 'low'].includes(risk) ? risk : '';
  return `
    <div class="exception-card">
      <div class="exception-card-header">
        <div class="exception-card-title">${escapeHtml(ex.exceptionName)}</div>
        <div class="exception-card-actions">
          <button type="button" class="icon-btn" data-action="edit-exception" data-id="${ex.id}" title="Edit">✏️</button>
          <button type="button" class="icon-btn" data-action="delete-exception" data-id="${ex.id}" title="Delete">🗑️</button>
        </div>
      </div>
      <div class="exception-card-body">
        <p><strong>View:</strong> ${escapeHtml(ex.viewName)}</p>
        <p><strong>Risk:</strong> <span class="risk-badge ${riskClass}">${escapeHtml(ex.issueRiskRating)}</span>
           <strong>Type:</strong> ${escapeHtml(ex.issueType)}</p>
        <p><strong>Owner:</strong> ${escapeHtml(ex.issueOwner)}</p>
        <p><strong>Description:</strong> ${escapeHtml(ex.issueDescription)}</p>
      </div>
    </div>`;
}

function toggleNode(header) {
  const key = header.dataset.key;
  const content = header.nextElementSibling;
  const open = !content.classList.contains('expanded');
  content.classList.toggle('expanded', open);
  header.querySelector('.theme-toggle').textContent = open ? '▼' : '▶';
  if (open) state.expanded.add(key); else state.expanded.delete(key);
}

async function deleteException(id) {
  const ex = state.exceptions.find((x) => x.id === id);
  if (!ex || !confirm(`Delete exception "${ex.exceptionName}"?`)) return;
  try {
    await api.deleteException(id);
  } catch (e) {
    showError('deleting exception', e);
    return;
  }
  logToConsole(`Exception "${ex.exceptionName}" deleted`, 'warning');
  await refreshData();
}

// ============================================================================
// Modals
// ============================================================================

function openModal(id) { $(id).classList.add('show'); }
function closeModal(id) { $(id).classList.remove('show'); }

function openExceptionModal(exception, theme, subTheme) {
  const form = $('exception-modal-form');
  form.reset();
  populateDropdowns();
  $('exception-modal-title').textContent = exception ? 'Edit Exception' : 'Add Exception';
  setValue('modal-exception-id', exception?.id);
  setValue('modal-exception-theme', exception ? exception.theme : theme);
  setValue('modal-exception-subtheme', exception ? exception.subTheme : subTheme);

  if (exception) {
    const fields = {
      'issue-risk-rating': exception.issueRiskRating,
      'sub-theme-risk-rating': exception.subThemeRiskRating,
      'issue-description': exception.issueDescription,
      'risk-type': exception.riskType,
      'issue-type': exception.issueType,
      'issue-owner': exception.issueOwner,
      'exception-name': exception.exceptionName,
      'parent-exception': exception.parentException,
      'view-name': exception.viewName,
    };
    Object.entries(fields).forEach(([field, value]) => {
      const el = $(`modal-${field}`);
      // Keep values that are not (or no longer) in the dropdown lists
      if (el.tagName === 'SELECT' && value && ![...el.options].some((o) => o.value === value)) {
        el.add(new Option(value, value));
      }
      el.value = value ?? '';
    });
  }
  openModal('exception-modal');
}

async function submitExceptionModal(event) {
  event.preventDefault();
  const id = getValue('modal-exception-id');
  const data = {
    theme: getValue('modal-exception-theme'),
    subTheme: getValue('modal-exception-subtheme'),
    ...readExceptionForm('modal-'),
  };
  try {
    if (id) await api.updateException(Number(id), data);
    else await api.addException(data);
  } catch (e) {
    showError(id ? 'updating exception' : 'adding exception', e);
    return;
  }
  logToConsole(`Exception "${data.exceptionName}" ${id ? 'updated' : 'added'}`, 'success');
  closeModal('exception-modal');
  await refreshData();
}

function openThemeModal(oldName = '') {
  const form = $('theme-form');
  form.dataset.oldName = oldName;
  $('theme-modal-title').textContent = oldName ? 'Edit Theme' : 'Add New Theme';
  setValue('modal-theme-name', oldName);
  openModal('theme-modal');
}

async function submitThemeModal(event) {
  event.preventDefault();
  const oldName = event.target.dataset.oldName;
  const name = getValue('modal-theme-name');
  if (!name) return;
  try {
    if (oldName) await api.renameTheme(oldName, name);
    else await api.addTheme(name);
  } catch (e) {
    showError(oldName ? 'updating theme' : 'adding theme', e);
    return;
  }
  logToConsole(oldName ? `Theme updated: ${oldName} → ${name}` : `Theme added: ${name}`, 'success');
  closeModal('theme-modal');
  await refreshData();
}

function openSubThemeModal(parentTheme = '', oldName = '') {
  const form = $('subtheme-form');
  form.dataset.oldName = oldName;
  form.dataset.oldParent = oldName ? parentTheme : '';
  $('subtheme-modal-title').textContent = oldName
    ? 'Edit Sub-Theme'
    : (parentTheme ? `Add Sub-Theme to ${parentTheme}` : 'Add New Sub-Theme');
  setValue('modal-parent-theme', '');
  setOptions('modal-parent-theme', parentTheme ? [...state.themes, parentTheme] : state.themes,
    'Select Parent Theme');
  setValue('modal-parent-theme', parentTheme);
  setValue('modal-subtheme-name', oldName);
  openModal('subtheme-modal');
}

async function submitSubThemeModal(event) {
  event.preventDefault();
  const { oldName, oldParent } = event.target.dataset;
  const name = getValue('modal-subtheme-name');
  const parent = getValue('modal-parent-theme');
  if (!name || !parent) return;
  try {
    if (oldName) await api.renameSubTheme(oldName, oldParent, name, parent);
    else await api.addSubTheme(name, parent);
  } catch (e) {
    showError(oldName ? 'updating sub-theme' : 'adding sub-theme', e);
    return;
  }
  logToConsole(oldName ? `Sub-theme updated: ${oldName} → ${name}` : `Sub-Theme added: ${name} (parent: ${parent})`,
    'success');
  closeModal('subtheme-modal');
  await refreshData();
}

// ============================================================================
// Manage Themes page
// ============================================================================

function renderThemeLists() {
  const themeCounts = {};
  const subThemeCounts = {};
  state.exceptions.forEach((ex) => {
    themeCounts[ex.theme] = (themeCounts[ex.theme] || 0) + 1;
    const key = treeKey(ex.theme, ex.subTheme);
    subThemeCounts[key] = (subThemeCounts[key] || 0) + 1;
  });

  $('theme-list').innerHTML = state.themes.length
    ? state.themes.map((theme) => `
        <div class="theme-mgmt-item">
          <div class="theme-mgmt-info">
            <div class="theme-mgmt-name">${escapeHtml(theme)}</div>
            <div class="theme-mgmt-count">${plural(themeCounts[theme] || 0, 'exception')}</div>
          </div>
          <div class="theme-mgmt-actions">
            <button type="button" class="btn btn-sm btn-primary" data-action="edit-theme" data-theme="${escapeHtml(theme)}">✏️ Edit</button>
            <button type="button" class="btn btn-sm btn-danger" data-action="delete-theme" data-theme="${escapeHtml(theme)}">🗑️ Delete</button>
          </div>
        </div>`).join('')
    : '<div class="no-items-message">No themes found. Add a theme to get started.</div>';

  const subThemes = state.subThemes.filter((st) => st.subTheme);
  $('subtheme-list').innerHTML = subThemes.length
    ? subThemes.map((st) => {
        const t = escapeHtml(st.parentTheme);
        const s = escapeHtml(st.subTheme);
        const count = subThemeCounts[treeKey(st.parentTheme, st.subTheme)] || 0;
        return `
          <div class="subtheme-mgmt-item">
            <div class="subtheme-mgmt-info">
              <div class="subtheme-mgmt-name">${s}</div>
              <div class="subtheme-mgmt-parent">Parent: ${t || 'No Parent'}</div>
              <div class="theme-mgmt-count">${plural(count, 'exception')}</div>
            </div>
            <div class="subtheme-mgmt-actions">
              <button type="button" class="btn btn-sm btn-primary" data-action="edit-subtheme" data-theme="${t}" data-subtheme="${s}">✏️ Edit</button>
              <button type="button" class="btn btn-sm btn-danger" data-action="delete-subtheme" data-theme="${t}" data-subtheme="${s}">🗑️ Delete</button>
            </div>
          </div>`;
      }).join('')
    : '<div class="no-items-message">No sub-themes found. Add a sub-theme to get started.</div>';
}

async function deleteTheme(theme) {
  if (!confirm(`Are you sure you want to delete the theme "${theme}"?\n\n`
    + 'Its sub-themes are removed as well. Exceptions using it are not deleted.')) return;
  try {
    await api.deleteTheme(theme);
  } catch (e) {
    showError('deleting theme', e);
    return;
  }
  logToConsole(`Theme deleted: ${theme}`, 'warning');
  await refreshData();
}

async function deleteSubTheme(parentTheme, subTheme) {
  if (!confirm(`Are you sure you want to delete the sub-theme "${subTheme}"?\n\n`
    + 'Exceptions using it are not deleted.')) return;
  try {
    await api.deleteSubTheme(subTheme, parentTheme);
  } catch (e) {
    showError('deleting sub-theme', e);
    return;
  }
  logToConsole(`Sub-theme deleted: ${subTheme}`, 'warning');
  await refreshData();
}

// ============================================================================
// Execute page (wizard)
// ============================================================================

const WIZARD_STEPS = ['wizard-select-exceptions', 'wizard-select-steps', 'wizard-parameters', 'wizard-progress'];

function showWizardStep(id) {
  WIZARD_STEPS.forEach((step) => $(step).classList.toggle('hidden', step !== id));
}

function resetWizard() {
  state.execution = { id: null, inProgress: false, exceptionIds: [], steps: [] };
  showWizardStep('wizard-select-exceptions');
  renderExceptionSelection();
}

function renderExceptionSelection() {
  const tree = buildTree(state.exceptions, false);
  if (tree.size === 0) {
    $('theme-selection').innerHTML = '<p>No exceptions available. Please add exceptions first.</p>';
    return;
  }
  $('theme-selection').innerHTML = [...tree].map(([theme, subThemes]) => {
    const t = escapeHtml(theme);
    return `
      <label class="checkbox-item">
        <input type="checkbox" data-select="theme" data-theme="${t}"><strong>${t}</strong>
      </label>
      ${[...subThemes].map(([sub, list]) => {
        const s = escapeHtml(sub);
        return `
          <label class="checkbox-item nested-checkbox">
            <input type="checkbox" data-select="subtheme" data-theme="${t}" data-subtheme="${s}">${s}
          </label>
          ${list.map((ex) => `
            <label class="checkbox-item nested-checkbox nested-2">
              <input type="checkbox" class="exception-cb" data-theme="${t}" data-subtheme="${s}" value="${ex.id}">
              ${escapeHtml(ex.exceptionName)}
            </label>`).join('')}`;
      }).join('')}`;
  }).join('');
}

function onSelectionChange(checkbox) {
  const { theme, subtheme } = checkbox.dataset;
  $('theme-selection').querySelectorAll('input[type="checkbox"]').forEach((cb) => {
    const sameTheme = cb.dataset.theme === theme;
    const inScope = checkbox.dataset.select === 'theme' ? sameTheme : sameTheme && cb.dataset.subtheme === subtheme;
    if (inScope && cb.dataset.select !== 'theme') cb.checked = checkbox.checked;
  });
}

function wizardToSteps() {
  const ids = [...document.querySelectorAll('.exception-cb:checked')].map((cb) => Number(cb.value));
  if (ids.length === 0) {
    alert('Please select at least one exception');
    return;
  }
  state.execution.exceptionIds = ids;
  logToConsole(`${plural(ids.length, 'exception')} selected for execution`);
  showWizardStep('wizard-select-steps');
}

function wizardToParameters() {
  const steps = [...document.querySelectorAll('#step-selection input:checked')].map((cb) => Number(cb.value));
  if (steps.length === 0) {
    alert('Please select at least one step to execute');
    return;
  }
  state.execution.steps = steps;
  logToConsole(`${plural(steps.length, 'step')} selected for execution`);
  showWizardStep('wizard-parameters');
}

async function startExecution() {
  const startDate = getValue('start-date');
  const endDate = getValue('end-date');
  const branches = getValue('branches');
  if (!startDate) return alert('Please select a start date');
  if (!endDate) return alert('Please select an end date');
  if (!branches) return alert('Please enter branch names or codes');
  if (startDate > endDate) return alert('Start date cannot be after end date');

  const { exceptionIds, steps } = state.execution;
  let res;
  try {
    res = await api.startExecution(exceptionIds, steps, { startDate, endDate, branches });
  } catch (e) {
    showError('starting execution', e);
    return;
  }

  logToConsole(`Execution started: ${plural(steps.length, 'step')} on ${plural(exceptionIds.length, 'exception')}, `
    + `dates ${startDate} to ${endDate}, branches ${branches.replace(/\s*\n\s*/g, ', ')}`, 'success');
  trackExecution(res.execution_id);
}

// ----------------------------------------------------------------------------
// Run tracking (progress panel)
// ----------------------------------------------------------------------------

const RUN_STATUS = {
  in_progress: { title: 'Execution in progress…', icon: '⏳' },
  completed: { title: 'Execution completed', icon: '✅' },
  failed: { title: 'Execution failed', icon: '❌' },
  stopped: { title: 'Execution stopped', icon: '⏹️' },
};

const STEP_ICONS = {
  pending: '○', running: '⏳', completed: '✅', failed: '❌', stopped: '⏹️', skipped: '⤼',
};

function formatDuration(seconds) {
  if (seconds == null) return '';
  const s = Math.round(seconds);
  return s < 60 ? `${s}s` : `${Math.floor(s / 60)}m ${String(s % 60).padStart(2, '0')}s`;
}

/** Show a run in the progress panel and poll it until it finishes. */
function trackExecution(id) {
  state.execution.id = id;
  state.execution.inProgress = true;
  $('task-text').textContent = 'Starting…';
  showWizardStep('wizard-progress');
  pollExecutionStatus(id);
}

function pollExecutionStatus(id) {
  const timer = setInterval(async () => {
    if (state.execution.id !== id) {  // User started over
      clearInterval(timer);
      return;
    }
    let run;
    try {
      run = await api.executionStatus(id);
    } catch (e) {
      clearInterval(timer);
      state.execution.inProgress = false;
      logToConsole(`Lost track of the execution: ${e.message}`, 'error');
      return;
    }
    renderRun(run);
    if (run.status !== 'in_progress') {
      clearInterval(timer);
      onExecutionFinished(run);
    }
  }, STATUS_POLL_MS);
}

function renderRun(run) {
  const status = RUN_STATUS[run.status];
  const counts = run.issue_counts || {};
  const errors = counts.ERROR || 0;
  const warnings = counts.WARN || 0;

  $('run-banner').className = `run-banner run-${run.status}`;
  $('run-title').textContent = `${status.icon} ${status.title}`;
  $('run-message').textContent = run.message;
  $('run-meta').textContent = `Started ${run.started_at} by ${run.user} · Elapsed ${formatDuration(run.elapsed_seconds)}`
    + (errors || warnings ? ` · ${plural(errors, 'error')}, ${plural(warnings, 'warning')}` : '');

  $('step-tracker').innerHTML = run.steps.map((step) => `
    <li class="step-row step-${step.status}">
      <span class="step-icon">${STEP_ICONS[step.status] || '○'}</span>
      <div class="step-body">
        <div class="step-name">Step ${step.number}: ${escapeHtml(step.name)}</div>
        ${step.error ? `<div class="step-error">${escapeHtml(step.error)}</div>` : ''}
      </div>
      <span class="step-duration">${step.status === 'skipped' ? 'not run' : formatDuration(step.duration_seconds)}</span>
    </li>`).join('');

  const running = run.status === 'in_progress';
  const { done, total } = run.progress;
  $('task-box').classList.toggle('hidden', !running);
  $('task-text').textContent = run.task || run.message;
  $('progress-fill').style.width = total ? `${Math.round((done / total) * 100)}%` : '0%';
  $('progress-count').textContent = total ? `${done} of ${total} done` : '';

  $('issues-box').classList.toggle('hidden', run.issues.length === 0);
  const totalIssues = errors + warnings;
  $('issues-header').textContent = `Issues (${totalIssues})`
    + (totalIssues > run.issues.length ? ` – showing first ${run.issues.length}; see the console for all` : '');
  $('issues-list').innerHTML = run.issues.map((issue) => `
    <li class="issue issue-${issue.level === 'ERROR' ? 'error' : 'warning'}">
      <span class="issue-meta">${escapeHtml(issue.time)} · Step ${issue.step ?? '-'}</span>
      ${escapeHtml(issue.message)}
    </li>`).join('');

  $('stop-button').classList.toggle('hidden', !running);
  $('downloads-button').classList.toggle('hidden', running || !run.generated_files.length);
}

function onExecutionFinished(run) {
  state.execution.inProgress = false;
  state.lastExecution = run;
  updateDashboard();
  if (run.status === 'completed') {
    state.downloads = run.generated_files;
    renderDownloads();
    logToConsole(`${plural(run.generated_files.length, 'file')} ready on the Downloads page`, 'success');
  }
}

/** After a page reload, pick up the latest run (still running, or the last result). */
async function restoreLastExecution() {
  let run;
  try {
    run = (await api.currentExecution()).execution;
  } catch (e) {
    return;
  }
  if (!run) return;
  state.lastExecution = run;
  updateDashboard();
  if (run.status === 'in_progress') {
    logToConsole(`Reconnected to running execution (${run.message})`);
    renderRun(run);
    trackExecution(run.id);
  }
}

async function stopExecution() {
  if (!state.execution.inProgress) return;
  if (!confirm('Are you sure you want to stop the execution?')) return;
  try {
    await api.stopExecution(state.execution.id);
    logToConsole('Stop requested; the execution stops after the current task', 'warning');
    $('task-text').textContent = 'Stopping after the current task…';
  } catch (e) {
    showError('stopping execution', e);
  }
}

function resetExecution() {
  if (state.execution.inProgress
    && !confirm('The execution is still running in the background. Start a new selection anyway?')) return;
  resetWizard();
}

// ============================================================================
// Downloads page
// ============================================================================

function renderDownloads() {
  const area = $('download-area');
  if (state.downloads.length === 0) {
    area.innerHTML = '<p class="empty-message">No downloads available yet. Execute steps to generate reports.</p>';
    return;
  }
  area.innerHTML = state.downloads.map((dl) => `
    <div class="download-item">
      <div><strong>${escapeHtml(dl.name)}</strong><br><small>Generated: ${escapeHtml(dl.date)}</small></div>
      <a class="btn btn-primary" href="${escapeHtml(api.downloadUrl(dl.file))}" download
         data-action="download" data-file="${escapeHtml(dl.file)}">Download</a>
    </div>`).join('');
}

// ============================================================================
// Event wiring
// ============================================================================

const ACTIONS = {
  'logout': async () => {
    try { await api.logout(); } finally { window.location.href = '/login'; }
  },
  'toggle-node': (el) => toggleNode(el),
  'add-theme': () => openThemeModal(),
  'edit-theme': (el) => openThemeModal(el.dataset.theme),
  'delete-theme': (el) => deleteTheme(el.dataset.theme),
  'add-subtheme': (el) => openSubThemeModal(el.dataset.theme || ''),
  'edit-subtheme': (el) => openSubThemeModal(el.dataset.theme, el.dataset.subtheme),
  'delete-subtheme': (el) => deleteSubTheme(el.dataset.theme, el.dataset.subtheme),
  'add-exception': (el) => openExceptionModal(null, el.dataset.theme, el.dataset.subtheme),
  'edit-exception': (el) => openExceptionModal(state.exceptions.find((x) => x.id === Number(el.dataset.id))),
  'delete-exception': (el) => deleteException(Number(el.dataset.id)),
  'wizard-to-exceptions': () => showWizardStep('wizard-select-exceptions'),
  'wizard-to-steps': () => wizardToSteps(),
  'wizard-back-to-steps': () => showWizardStep('wizard-select-steps'),
  'wizard-to-parameters': () => wizardToParameters(),
  'start-execution': () => startExecution(),
  'stop-execution': () => stopExecution(),
  'reset-execution': () => resetExecution(),
  'clear-console': () => $('console').replaceChildren(),
  'download': (el) => logToConsole(`Download initiated: ${el.dataset.file}`),
};

document.addEventListener('click', (event) => {
  const el = event.target.closest('[data-action], [data-section], [data-close-modal]');
  if (!el) return;
  if (el.dataset.closeModal) closeModal(el.dataset.closeModal);
  else if (el.dataset.section) showSection(el.dataset.section);
  else ACTIONS[el.dataset.action]?.(el);
});

document.addEventListener('change', (event) => {
  if (event.target.dataset.select) onSelectionChange(event.target);
});

document.addEventListener('DOMContentLoaded', async () => {
  $('exception-form').addEventListener('submit', submitExceptionForm);
  $('exception-modal-form').addEventListener('submit', submitExceptionModal);
  $('theme-form').addEventListener('submit', submitThemeModal);
  $('subtheme-form').addEventListener('submit', submitSubThemeModal);
  $('theme').addEventListener('change', () => setOptions('sub-theme', subThemesFor(getValue('theme'))));
  $('search-exceptions').addEventListener('input', renderHierarchy);
  $('console-filter').addEventListener('change', applyConsoleFilter);

  showSection('dashboard');
  try {
    const { user } = await api.session();
    $('current-user').textContent = `Signed in as ${user}`;
    logToConsole('Backend connection established', 'success');
  } catch (e) {
    logToConsole(`Backend not reachable: ${e.message}`, 'error');
    return;
  }
  pollConsole();
  await refreshData();
  logToConsole(`Loaded ${plural(state.exceptions.length, 'exception')} and `
    + `${plural(state.themes.length, 'theme')}`, 'success');
  await restoreLastExecution();
});

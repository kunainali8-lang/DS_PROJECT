// Clickjacking protection for legacy browsers that ignore the CSP frame-ancestors /
// X-Frame-Options headers. The page stays hidden (see styles.css) unless it is the
// top-level window; when framed, it tries to break out of the frame.
if (window.self === window.top) {
  document.documentElement.classList.add('not-framed');
} else {
  window.top.location = window.self.location;
}

// Thin client for the Flask backend. Every function returns parsed JSON or throws.
const API_BASE_URL = `${window.location.origin}/api`;
let csrfToken = null;

async function getCsrfToken(refresh = false) {
  if (!csrfToken || refresh) {
    const response = await fetch(`${API_BASE_URL}/csrf`, { credentials: 'same-origin' });
    csrfToken = (await response.json()).token;
  }
  return csrfToken;
}

async function apiRequest(path, { method = 'GET', body } = {}, isRetry = false) {
  const options = { method, headers: {}, credentials: 'same-origin' };
  if (body !== undefined) {
    options.headers['Content-Type'] = 'application/json';
    options.body = JSON.stringify(body);
  }
  if (method !== 'GET') options.headers['X-CSRF-Token'] = await getCsrfToken();

  const response = await fetch(`${API_BASE_URL}${path}`, options);
  if (response.status === 403 && method !== 'GET' && !isRetry) {
    await getCsrfToken(true);  // Token rotated (new session); fetch it and retry once
    return apiRequest(path, { method, body }, true);
  }
  if (path === '/login' || path === '/logout') csrfToken = null;  // Session is replaced
  if (response.status === 401 && path !== '/login') {
    window.location.href = '/login';  // Session expired
    throw new Error('Not logged in');
  }

  let data = {};
  try { data = await response.json(); } catch (_) { /* empty or non-JSON body */ }
  if (!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
  return data;
}

const api = {
  // Session
  login: (username, password) => apiRequest('/login', { method: 'POST', body: { username, password } }),
  logout: () => apiRequest('/logout', { method: 'POST' }),
  session: () => apiRequest('/session'),

  // Exceptions & metadata
  getExceptions: () => apiRequest('/exceptions'),
  addException: (data) => apiRequest('/exceptions', { method: 'POST', body: data }),
  updateException: (id, data) => apiRequest(`/exceptions/${id}`, { method: 'PUT', body: data }),
  deleteException: (id) => apiRequest(`/exceptions/${id}`, { method: 'DELETE' }),
  getMeta: () => apiRequest('/meta'),

  addTheme: (name) => apiRequest('/meta/theme', { method: 'POST', body: { name } }),
  renameTheme: (oldName, newName) => apiRequest('/meta/theme', { method: 'PUT', body: { oldName, newName } }),
  deleteTheme: (name) => apiRequest('/meta/theme', { method: 'DELETE', body: { name } }),

  addSubTheme: (name, parentTheme) =>
    apiRequest('/meta/subtheme', { method: 'POST', body: { name, parentTheme } }),
  renameSubTheme: (oldName, oldParent, newName, newParent) =>
    apiRequest('/meta/subtheme', { method: 'PUT', body: { oldName, oldParent, newName, newParent } }),
  deleteSubTheme: (name, parentTheme) =>
    apiRequest('/meta/subtheme', { method: 'DELETE', body: { name, parentTheme } }),

  // Execution
  startExecution: (exceptionIds, steps, parameters) =>
    apiRequest('/execute', { method: 'POST', body: { exception_ids: exceptionIds, steps, parameters } }),
  executionStatus: (id) => apiRequest(`/execution/${encodeURIComponent(id)}/status`),
  currentExecution: () => apiRequest('/execution/current'),
  stopExecution: (id) => apiRequest(`/execution/${encodeURIComponent(id)}/stop`, { method: 'POST' }),

  // Downloads & console
  getDownloads: () => apiRequest('/downloads'),
  downloadUrl: (filename) => `${API_BASE_URL}/download/${encodeURIComponent(filename)}`,
  consoleTail: (offset) => apiRequest(offset == null ? '/console/tail' : `/console/tail?offset=${offset}`),
};

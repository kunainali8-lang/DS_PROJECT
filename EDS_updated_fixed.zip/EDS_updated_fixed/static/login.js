// Login page. Relies on `api` from api.js.
document.getElementById('login-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const errorEl = document.getElementById('login-error');
  const button = event.target.querySelector('button[type="submit"]');
  errorEl.textContent = '';
  button.disabled = true;

  try {
    await api.login(document.getElementById('username').value.trim(),
                    document.getElementById('password').value);
    window.location.href = '/';
  } catch (e) {
    errorEl.textContent = e.message;
    document.getElementById('password').select();
  } finally {
    button.disabled = false;
  }
});

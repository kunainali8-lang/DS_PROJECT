// API LISTENER - FIXED VERSION
const API_BASE_URL = `${window.location.origin}/api`;
let consolePollTimer = null, lastConsoleCount = 0;

// Exceptions CRUD
async function addException(data){ try{ const r = await fetch(`${API_BASE_URL}/exceptions`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}); if(!r.ok) throw new Error(`HTTP ${r.status}`); const res = await r.json(); onExceptionAdded(res.exception); }catch(e){ console.error(e); logToConsole(`Error adding exception: ${e.message}`,'error'); alert('Failed to add exception.'); } }

async function fetchExceptions(){
    try{
      const r = await fetch(`${API_BASE_URL}/exceptions`);
      if(!r.ok) throw new Error(`HTTP ${r.status}`);
      const res = await r.json();
  
      // Keep the extras available globally for the View Exceptions page
      window.exceptionsMeta = {
        themes_exceptions: res.themes_exceptions || [],
        themes_metadata:   res.themes_metadata   || [],
        themes_union:      res.themes_union      || [],
        subthemes_meta:    res.subthemes_meta    || []
      };
  
      onExceptionsFetched(res.exceptions);
    }catch(e){
      console.error(e);
      logToConsole(`Error fetching exceptions: ${e.message}`,'error');
    }
}

async function updateException(id,data){ try{ const r = await fetch(`${API_BASE_URL}/exceptions/${id}`,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}); if(!r.ok) throw new Error(`HTTP ${r.status}`); await r.json(); logToConsole('Exception updated successfully','success'); fetchExceptions(); }catch(e){ console.error(e); logToConsole(`Error updating exception: ${e.message}`,'error'); } }
async function removeException(id){ try{ const r = await fetch(`${API_BASE_URL}/exceptions/${id}`,{method:'DELETE'}); if(!r.ok) throw new Error(`HTTP ${r.status}`); await r.json(); onExceptionDeleted(id); }catch(e){ console.error(e); logToConsole(`Error deleting exception: ${e.message}`,'error'); } }

// Execution - FIXED with proper status handling
async function startExecution(ids,steps,params={}){ 
    try{ 
        const r = await fetch(`${API_BASE_URL}/execute`,{
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body:JSON.stringify({exception_ids:ids,steps,parameters:params})
        }); 
        
        if(!r.ok) throw new Error(`HTTP ${r.status}`); 
        
        const res = await r.json(); 
        
        if(res.execution_id){ 
            currentExecutionId = res.execution_id; 
            // Start aggressive console polling during execution
            startAggressiveConsolePolling();
            pollExecutionStatus(res.execution_id); 
        } 
    }catch(e){ 
        console.error(e); 
        logToConsole(`Error starting execution: ${e.message}`,'error'); 
    } 
}

async function stopExecutionAPI(id){ 
    try{ 
        const r = await fetch(`${API_BASE_URL}/execution/${id}/stop`,{method:'POST'}); 
        if(!r.ok) throw new Error(`HTTP ${r.status}`); 
        await r.json(); 
        logToConsole('Execution stopped successfully on backend','warning'); 
    }catch(e){ 
        console.error(e); 
        logToConsole(`Error stopping execution: ${e.message}`,'error'); 
    } 
}

// FIXED: Proper execution status polling with UI updates
async function pollExecutionStatus(id){ 
    const timer = setInterval(async()=>{ 
        try{ 
            const r = await fetch(`${API_BASE_URL}/execution/${id}/status`); 
            if(!r.ok) throw new Error(`HTTP ${r.status}`); 
            
            const res = await r.json(); 
            
            if(res.status==='in_progress'){ 
                onExecutionProgress(res.current_step, res.message, 'info'); 
            } else { 
                // Clear timer when execution ends
                clearInterval(timer); 
                
                // Stop aggressive console polling
                stopAggressiveConsolePolling();
                
                if(res.status==='completed'){ 
                    onExecutionComplete(res.generated_files); 
                } else if(res.status==='stopped'){ 
                    // FIXED: Properly handle stopped state
                    logToConsole('========================================','warning');
                    logToConsole('EXECUTION STOPPED BY USER','warning'); 
                    logToConsole('========================================','warning');
                    onExecutionStopped();
                } else { 
                    logToConsole('========================================','error');
                    logToConsole('EXECUTION FAILED','error'); 
                    logToConsole('========================================','error');
                    onExecutionFailed(res.message);
                } 
            } 
        }catch(e){ 
            console.error(e); 
            clearInterval(timer); 
            stopAggressiveConsolePolling();
        } 
    }, 2000); 
}

// Downloads
async function fetchDownloads(){ try{ const r=await fetch(`${API_BASE_URL}/downloads`); if(!r.ok) throw new Error(`HTTP ${r.status}`); const res=await r.json(); onDownloadsFetched(res.downloads); }catch(e){ console.error(e); logToConsole(`Error fetching downloads: ${e.message}`,'error'); } }
async function requestDownload(filename){ try{ const r=await fetch(`${API_BASE_URL}/download/${filename}`); if(!r.ok) throw new Error(`HTTP ${r.status}`); const b=await r.blob(); const url=URL.createObjectURL(b); const a=document.createElement('a'); a.href=url; a.download=filename; document.body.appendChild(a); a.click(); URL.revokeObjectURL(url); document.body.removeChild(a); logToConsole(`File downloaded: ${filename}`,'success'); }catch(e){ console.error(e); logToConsole(`Error downloading file: ${e.message}`,'error'); } }

// Console tail - FIXED for real-time updates
let aggressiveConsoleTimer = null;

async function fetchConsoleTail(limit=500){ 
    try{ 
        const r = await fetch(`${API_BASE_URL}/console/tail?limit=${limit}`); 
        if(!r.ok) throw new Error(`HTTP ${r.status}`); 
        
        const res = await r.json(); 
        
        if(typeof res.count === 'number' && Array.isArray(res.lines)){ 
            if(res.count > lastConsoleCount){ 
                // Get only new lines since last fetch
                const newLines = res.lines.slice(lastConsoleCount);
                
                newLines.forEach(line => {
                    // Parse log level from line
                    let type = 'info';
                    if(line.includes('[ERROR]')) type = 'error';
                    else if(line.includes('[WARN]')) type = 'warning';
                    else if(line.includes('[SUCCESS]')) type = 'success';
                    else if(line.includes('[INFO]')) type = 'info';
                    
                    logToConsole(line, type);
                });
                
                lastConsoleCount = res.count; 
            } 
        } 
    }catch(e){ 
        console.error('Console fetch error:', e); 
    } 
}

function startConsolePolling(){ 
    if(consolePollTimer) return; 
    fetchConsoleTail(); 
    consolePollTimer = setInterval(() => fetchConsoleTail(), 3000); 
}

function stopConsolePolling(){
    if(consolePollTimer){
        clearInterval(consolePollTimer);
        consolePollTimer = null;
    }
}

// FIXED: Aggressive console polling during execution (every 500ms for real-time feel)
function startAggressiveConsolePolling(){
    if(aggressiveConsoleTimer) return;
    
    // Stop normal polling
    stopConsolePolling();
    
    // Start aggressive polling
    aggressiveConsoleTimer = setInterval(() => fetchConsoleTail(), 500);
}

function stopAggressiveConsolePolling(){
    if(aggressiveConsoleTimer){
        clearInterval(aggressiveConsoleTimer);
        aggressiveConsoleTimer = null;
    }
    
    // Resume normal polling
    startConsolePolling();
}

// Meta
async function fetchMeta(){ try{ const r=await fetch(`${API_BASE_URL}/meta`); if(!r.ok) throw new Error(`HTTP ${r.status}`); const meta=await r.json(); onMetaFetched(meta); }catch(e){ console.error(e); logToConsole(`Error fetching meta: ${e.message}`,'error'); } }
async function addThemeAPI(name){ try{ const r=await fetch(`${API_BASE_URL}/meta/theme`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name})}); if(!r.ok) throw new Error(`HTTP ${r.status}`); await r.json(); logToConsole(`Theme added: ${name}`,'success'); fetchMeta(); }catch(e){ console.error(e); logToConsole(`Error adding theme: ${e.message}`,'error'); } }
async function addSubThemeAPI(name,parentTheme){ try{ const r=await fetch(`${API_BASE_URL}/meta/subtheme`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,parentTheme})}); if(!r.ok) throw new Error(`HTTP ${r.status}`); await r.json(); logToConsole(`Sub-Theme added: ${name} (parent: ${parentTheme||'n/a'})`,'success'); fetchMeta(); }catch(e){ console.error(e); logToConsole(`Error adding sub-theme: ${e.message}`,'error'); } }

// Bootstrap
async function checkBackendConnection(){ try{ const r=await fetch(`${API_BASE_URL}/health`); if(r.ok){ logToConsole('Backend connection established','success'); startConsolePolling(); return true; } else { logToConsole('Backend connection failed','warning'); return false; } }catch(e){ console.error(e); logToConsole('Backend not reachable. Using dummy data.','warning'); return false; } }

document.addEventListener('DOMContentLoaded', async function(){ const ok = await checkBackendConnection(); if(ok){ fetchMeta(); fetchExceptions(); fetchDownloads(); } else { logToConsole('Running in offline mode','warning'); } });
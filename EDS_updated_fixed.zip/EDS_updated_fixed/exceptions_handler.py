"""CSV-backed storage for exception definitions.

The UI only works with the *dynamic* fields. The CSV on disk additionally holds
*static* report columns, which are always written with fixed placeholder values.
"""

import csv
import logging
import os
import threading

logger = logging.getLogger(__name__)

# Fields exposed to and editable from the frontend
DYNAMIC_FIELDS = [
    'id', 'theme', 'subTheme', 'issueRiskRating', 'subThemeRiskRating',
    'issueDescription', 'riskType', 'issueType', 'issueOwner',
    'exceptionName', 'parentException', 'viewName',
]

# Report columns stored alongside each exception with fixed placeholder values
STATIC_DEFAULTS = {
    'Issue Reference Number': '{row_id}-{theme}-{sub-theme}-{branch code}-{year}',
    'Issue Number': '{row_id}',
    'Count Reference': '{branch_name}-{theme}-{sub-theme}',
    'Count': '0',
    'Branch Code': '{branch_code}',
    'Branch Name': '{branch_name}',
    'Audit Region': '{audit_region}',
    'Business Region': '{business_region}',
    'Audit Year': '{year}',
    'Management Response': '_',
    'Amount': '0',
    'Resolution Target Date (RTD)': '01/01/2025',
    'Current Status': 'NA',
    'Settled Date': '_',
    'Audit Report Release Date': '01/01/2025',
    'Audit Report Rating': '_',
    'Spot Rectification (Y/N)': 'N',
    'Population': 'CAATs',
    'Selected Sample': '0',
    'Instances': '0',
    'Error Rate': '0',
}

ALL_FIELDS = DYNAMIC_FIELDS + list(STATIC_DEFAULTS)


def _to_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _to_dynamic(row):
    """Keep only the dynamic fields of a CSV row, with ``id`` as an int."""
    item = {field: row.get(field) or '' for field in DYNAMIC_FIELDS}
    item['id'] = _to_int(item['id'])
    return item


class ExceptionsHandler:
    """Read/write exceptions in the backend CSV. All writes are serialised."""

    def __init__(self, csv_path):
        self.csv_path = csv_path
        self._lock = threading.RLock()
        if not os.path.exists(csv_path):
            self.write_exceptions([])

    def read_exceptions(self):
        with self._lock:
            if not os.path.exists(self.csv_path):
                return []
            with open(self.csv_path, 'r', newline='', encoding='utf-8') as f:
                return [_to_dynamic(row) for row in csv.DictReader(f)]

    def write_exceptions(self, items):
        with self._lock:
            with open(self.csv_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=ALL_FIELDS)
                writer.writeheader()
                for item in items:
                    row = {field: item.get(field, '') for field in DYNAMIC_FIELDS}
                    row.update(STATIC_DEFAULTS)
                    writer.writerow(row)

    def add_exception(self, record):
        """Append a new exception and return it with its assigned id."""
        with self._lock:
            items = self.read_exceptions()
            new_item = {field: record.get(field, '') for field in DYNAMIC_FIELDS}
            new_item['id'] = max((item['id'] for item in items), default=0) + 1
            items.append(new_item)
            self.write_exceptions(items)
            return new_item

    def update_exception(self, exception_id, updates):
        """Apply ``updates`` to one exception. Returns the updated item or None."""
        with self._lock:
            items = self.read_exceptions()
            item = next((x for x in items if x['id'] == exception_id), None)
            if item is None:
                return None
            for field in DYNAMIC_FIELDS:
                if field != 'id' and field in updates:
                    item[field] = updates[field]
            self.write_exceptions(items)
            return item

    def delete_exception(self, exception_id):
        """Remove one exception. Returns the removed item or None."""
        with self._lock:
            items = self.read_exceptions()
            item = next((x for x in items if x['id'] == exception_id), None)
            if item is None:
                return None
            items.remove(item)
            self.write_exceptions(items)
            return item

    def update_theme_name(self, old_name, new_name):
        """Rename a theme on every exception that uses it."""
        with self._lock:
            items = self.read_exceptions()
            matches = [item for item in items if item['theme'] == old_name]
            for item in matches:
                item['theme'] = new_name
            if matches:
                self.write_exceptions(items)
                logger.info("Updated theme name in %d exception(s)", len(matches))
            return len(matches)

    def update_subtheme_name(self, old_parent, old_name, new_parent, new_name):
        """Rename/move a sub-theme on every exception that uses it."""
        with self._lock:
            items = self.read_exceptions()
            matches = [
                item for item in items
                if item['theme'] == old_parent and item['subTheme'] == old_name
            ]
            for item in matches:
                item['theme'] = new_parent
                item['subTheme'] = new_name
            if matches:
                self.write_exceptions(items)
                logger.info("Updated sub-theme name in %d exception(s)", len(matches))
            return len(matches)


def migrate_from_simple_csv(source_csv, target_csv):
    """One-off migration from the legacy exceptions.csv (dynamic fields only)."""
    with open(source_csv, 'r', newline='', encoding='utf-8') as f:
        items = [_to_dynamic(row) for row in csv.DictReader(f)]
    ExceptionsHandler(target_csv).write_exceptions(items)
    logger.info("Migrated %d exceptions from %s to %s", len(items), source_csv, target_csv)

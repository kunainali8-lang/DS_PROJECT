import os
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill
from openpyxl.utils.dataframe import dataframe_to_rows


#format each exceptions_report in excel file.
##-------------------------------------------------------------------------------------------------------------------------------------------------
def format_excel(file_path, exception_column_name):
    # Guard against 0-byte or unreadable CSV
    if os.path.getsize(file_path) == 0:
        print(f"[WARN] Skipping empty (0-byte) file: {file_path}")
        return

    # Read the CSV file into a DataFrame
    try:
        df = pd.read_csv(file_path)
    except Exception as e:
        print(f"[WARN] Could not read {file_path}: {e} — skipping")
        return

    if df.empty:
        print(f"[WARN] No data in {file_path}, skipping Excel export")
        return
    
    # Create a new Excel workbook and select the active worksheet
    wb = Workbook()
    ws = wb.active
    
    # Write the DataFrame to the worksheet
    for r in dataframe_to_rows(df, index=False, header=True):
        ws.append(r)
    
    # Apply formatting to the header row
    header_font = Font(bold=True, color="000000")
    header_fill = PatternFill(start_color="FCB929", end_color="FCB929", fill_type="solid")
    
    for cell in ws[1]:
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(wrap_text=True, vertical="center", horizontal="center")
    
    # Increase the height of the header row
    ws.row_dimensions[1].height = 25
    
    # Set a fixed width for the specified exception column
    exception_col = None
    for col in ws.iter_cols(min_row=1, max_row=1):
        for cell in col:
            if cell.value == exception_column_name:
                exception_col = cell.column_letter
                ws.column_dimensions[exception_col].width = 30  # Set fixed width
                break
    
    # Adjust column widths and apply text wrapping and middle alignment
    for col in ws.columns:
        max_length = 0
        column = col[0].column_letter  # Get the column name
        
        for cell in col:
            try:
                if len(str(cell.value)) > max_length:
                    max_length = len(cell.value)
            except:
                pass
        
        if column != exception_col:
            adjusted_width = (max_length + 2)
            ws.column_dimensions[column].width = adjusted_width
        
        for cell in col:
            cell.alignment = Alignment(wrap_text=True, vertical="center", horizontal="center")
    
    # Save the formatted Excel file
    excel_file_path = file_path.replace(".csv", ".xlsx")
    wb.save(excel_file_path)


#pick exceptions report in each branch file and call the format function
##-------------------------------------------------------------------------------------------------------------------------------------------------
def formattize_branch_data(directory, exception_column_name):
    for branch_code in os.listdir(directory):
        branch_path = os.path.join(directory, branch_code)
        
        if os.path.isdir(branch_path):
            csv_file_path = os.path.join(branch_path, "exceptions_report.csv")
            
            if os.path.exists(csv_file_path):
                format_excel(csv_file_path, exception_column_name)
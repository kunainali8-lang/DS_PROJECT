# cohere_r7b.py  — HBL AI GATEWAY VERSION (replaces Ollama direct usage)
# ----------------------------------------------------------------
# This module now uses the HBL AI Gateway (OpenAI-compatible API) in two ways:
#   1) Preferred: via LLMManager.generate_text(prompt, max_tokens)
#      (audit_gui.py constructs and passes an LLMManager instance)
#   2) Fallback: if llm_manager is None, it calls the HBL AI Gateway directly
#      using the /v1/chat/completions endpoint.
#
# Functions kept (signatures adapted to accept llm_manager):
#   - generate_paragraph(input_text, llm_manager, model_name='local-ollama', max_tokens=10000)
#   - generate_summary(csv_file_path, llm_manager, model_name='local-ollama', max_tokens=10000)
#   - prepare_input_and_generate_summary_for_exceptions(row_like, llm_manager, model_name='local-ollama', max_tokens=1000)
#
# Notes:
# - Uses HBL AI Gateway at http://10.16.70.55:8082 (OpenAI-compatible).
# - Model: llama3.2:latest
# - API Key required (Bearer token).

from typing import Union
import os
import json
import pandas as pd

# Only used in fallback HTTP path (when llm_manager is None)
try:
    import requests  # noqa: F401
    _HAS_REQUESTS = True
except Exception:
    _HAS_REQUESTS = False


# ----------------------
# Helpers & Fallback I/O
# ----------------------
def _ensure_text(value) -> str:
    """Safe string conversion for Series/DataFrame/other."""
    if isinstance(value, pd.DataFrame):
        return value.to_string(index=False)
    if isinstance(value, pd.Series):
        return value.to_string()
    return str(value)


def _load_local_llm_config():
    """
    Load llm_config.json used by audit_gui.py Settings.
    Provides sane defaults if file is missing.
    """
    default_cfg = {
        "provider": "ollama",
        "ollama": {
            "base_url": "http://10.16.70.55:11434",
            "model": "llama3.2:latest",
            "max_tokens": 4096,
            "model_locked": True
        }
    }
    try:
        cfg_path = "llm_config.json"
        if os.path.exists(cfg_path):
            with open(cfg_path, "r", encoding="utf-8") as f:
                loaded = json.load(f)
                # merge defaults shallowly
                for k, v in default_cfg.items():
                    if k not in loaded:
                        loaded[k] = v
                if "ollama" in loaded and "ollama" in default_cfg:
                    for k, v in default_cfg["ollama"].items():
                        loaded["ollama"].setdefault(k, v)
                return loaded
        return default_cfg
    except Exception:
        return default_cfg


GATEWAY_URL = "http://10.16.70.55:8082"
GATEWAY_API_KEY = os.getenv("HBL_AI_GATEWAY_API_KEY", "")


def _generate_via_gateway(prompt: str, max_tokens: int = 4096) -> str:
    """
    Calls the HBL AI Gateway (OpenAI-compatible /v1/chat/completions).
    Drop-in replacement for _generate_via_ollama.
    """
    if not _HAS_REQUESTS:
        raise RuntimeError(
            "requests package not available. Install with: pip install requests "
            "or pass llm_manager to use the in-process adapter."
        )

    url = f"{GATEWAY_URL}/v1/chat/completions"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {GATEWAY_API_KEY}",
    }
    payload = {
        "model": "llama3.2:latest",
        "messages": [
            {"role": "user", "content": prompt}
        ],
        "max_tokens": max_tokens,
        "stream": False,
    }

    try:
        resp = requests.post(url, headers=headers, json=payload, timeout=300)
        print('Response status:', resp.status_code)
        print('Response headers:', resp.headers)

        resp.raise_for_status()

        # Debug: print raw response text
        raw_text = resp.text
        print('Raw response (first 500 chars):', raw_text[:500])

        data = resp.json()
        print('Parsed JSON data:', data)

        return data["choices"][0]["message"]["content"]

    except json.JSONDecodeError as e:
        print(f"JSON decode error: {e}")
        print(f"Raw response that failed to parse: {resp.text}")
        raise RuntimeError(f"Failed to parse gateway response as JSON: {e}")
    except requests.RequestException as e:
        print(f"Request error: {e}")
        raise RuntimeError(f"Gateway request failed: {e}")

def _generate_with_llm(llm_manager, prompt: str, max_tokens: int) -> str:
    """
    Preferred adapter: use LLMManager if provided; otherwise fallback to HBL AI Gateway.
    """
    # Fallback to HBL AI Gateway
    return _generate_via_gateway(prompt, max_tokens)


# ---------------
# Public Functions
# ---------------
def generate_paragraph(
    input_text: str,
    llm_manager,
    model_name: str = "local-ollama",
    max_tokens: int = 10000
) -> str:
    """
    Generates a paragraphic summary of the input text using the LOCAL LLM.
    Parameters:
      input_text (str): The text to summarize.
      llm_manager: Instance of LLMManager (preferred). If None, fallback HTTP client is used.
      model_name (str): Placeholder for compatibility; not used directly.
      max_tokens (int): Maximum tokens for the response.
    Returns:
      str: Generated paragraphic summary.
    """
    prompt = _ensure_text(input_text)
    return _generate_with_llm(llm_manager, prompt, max_tokens)


def generate_summary(
    csv_file_path: Union[str, pd.DataFrame],
    llm_manager,
    model_name: str = "local-ollama",
    max_tokens: int = 10000
) -> str:
    """
    Generates a summary of issues from a CSV file using the LOCAL LLM.
    Parameters:
      csv_file_path (str): Path to the CSV file.
      llm_manager: Instance of LLMManager (preferred). If None, fallback HTTP is used.
      model_name (str): Placeholder.
      max_tokens (int): Maximum number of tokens for the response.
    Returns:
      str: Generated summary.
    """
    # Preserve your original behavior (sep='\n') but fall back to default if it fails.
    if isinstance(csv_file_path, pd.DataFrame):
        data = csv_file_path.copy()
    else:
        try:
            data = pd.read_csv(csv_file_path, sep='\n')
        except Exception:
            data = pd.read_csv(csv_file_path)

    input_prompt = f"""
For below table:
{data.to_string(index=False)}
For theme and sub-theme, prepare a paragraphic summary of issues with their error rates and instances mentioned as well:
"""
    return _generate_with_llm(llm_manager, input_prompt, max_tokens)


def prepare_input_and_generate_summary_for_exceptions(
    row_like: Union[pd.DataFrame, pd.Series],
    llm_manager,
    model_name: str = "local-ollama",
    max_tokens: int = 1000
) -> str:
    """
    Prepares input string from a row and generates a concise summary using the LOCAL LLM.
    Parameters:
      row_like: A 1-row DataFrame or a Series containing:
                ['Theme', 'Issue Description', 'Instances', 'Issue Risk Rating', 'exception_name']
      llm_manager: Instance of LLMManager (preferred). If None, fallback HTTP is used.
      model_name (str): Placeholder.
      max_tokens (int): Maximum tokens for the response.
    Returns:
      str: Generated paragraphic summary.
    """
    # Normalize to Series for consistent extraction
    if isinstance(row_like, pd.DataFrame):
        if len(row_like) == 0:
            raise ValueError("Empty DataFrame provided to summary generator")
        series = row_like.iloc[0]
    else:
        series = row_like

    # Extract fields safely
    theme = _ensure_text(series.get('Theme', ''))
    issue_desc = _ensure_text(series.get('Issue Description', ''))
    total_count = _ensure_text(series.get('Instances', ''))
    risk_rating = _ensure_text(series.get('Issue Risk Rating', ''))
    exception_name = _ensure_text(series.get('exception_name', ''))

    # Create a clear, compact prompt
    table_values = series.to_string()
    input_prompt = f"""
For the following exception data (single record, not a table):
{table_values}

Prepare a descrption of ~50 to 70 words using the exception description and total count provided. Use below provided data:

Exception: {exception_name}
Exception Description: {issue_desc}
Total Count: {total_count}
Theme Risk Rating: {risk_rating}

Please do not write "here's the paragraph"; output ONLY the paragraph (no extra headers or preambles).
Total count of occurances of the exception must be included in final wording and embeded between the exception descrption properly and professionally.
Please make sure to write the exception in a very humanistic way. it should not use words like I, Me or We. 
The Exception description contains 1 or more than 1 ways of writing the exception details. use it please but it should make very realistic sense.


"""

    print('here is the input prompt: ',input_prompt)
    return _generate_with_llm(llm_manager, input_prompt, max_tokens)    
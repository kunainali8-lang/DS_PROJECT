"""Central configuration for the Exception Detection System.

Every value can be overridden with an environment variable so deployments
don't need code changes.
"""

import os
import secrets
from datetime import timedelta

# ----------------------------------------------------------------------------
# Paths
# ----------------------------------------------------------------------------

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, 'static')
DATA_DIR = os.getenv('EDS_DATA_DIR', os.path.join(BASE_DIR, 'data'))
LOG_DIR = os.getenv('EDS_LOG_DIR', os.path.join(BASE_DIR, 'logs'))
DOWNLOADS_DIR = os.getenv('EDS_DOWNLOADS_DIR', os.path.join(BASE_DIR, 'downloads'))

EXCEPTIONS_CSV = os.path.join(DATA_DIR, 'exceptions_v2.csv')
LEGACY_EXCEPTIONS_CSV = os.path.join(DATA_DIR, 'exceptions.csv')
META_XLSX = os.path.join(DATA_DIR, 'meta_data.xlsx')
BRANCH_INFO_CSV = os.path.join(DATA_DIR, 'branch_information.csv')

CONSOLE_LOG = os.path.join(LOG_DIR, 'console_output.log')
EXECUTION_LOG_JSON = os.path.join(LOG_DIR, 'view_execution_log.json')

# ----------------------------------------------------------------------------
# Database (ODBC)
# ----------------------------------------------------------------------------

# Name of the ODBC data source configured on the host machine. Host, port,
# user and password all live in the DSN definition, not in this project.
ODBC_DSN = os.getenv('EDS_ODBC_DSN', 'impala')

# Schema in which the DS_* exception tables are created.
DB_NAME = os.getenv('EDS_DB_NAME', 'FCCM_UAT')

DB_CONNECT_ATTEMPTS = int(os.getenv('EDS_DB_CONNECT_ATTEMPTS', '3'))
DB_CONNECT_RETRY_SECONDS = int(os.getenv('EDS_DB_CONNECT_RETRY_SECONDS', '30'))

# ----------------------------------------------------------------------------
# LLM gateway (OpenAI-compatible)
# ----------------------------------------------------------------------------

LLM_GATEWAY_URL = os.getenv('HBL_AI_GATEWAY_URL', 'http://10.16.70.55:8082')
LLM_GATEWAY_API_KEY = os.getenv('HBL_AI_GATEWAY_API_KEY', '')
LLM_MODEL = os.getenv('HBL_AI_GATEWAY_MODEL', 'llama3.2:latest')
LLM_TIMEOUT_SECONDS = int(os.getenv('HBL_AI_GATEWAY_TIMEOUT', '300'))
# TLS certificate verification for an https:// gateway URL: path to the
# organisation's CA bundle, or empty to use the system/certifi CA store.
LLM_CA_BUNDLE = os.getenv('HBL_AI_GATEWAY_CA_BUNDLE', '')
LLM_MAX_SUMMARY_CHARS = 2000

# ----------------------------------------------------------------------------
# Web server & authentication
# ----------------------------------------------------------------------------

HOST = os.getenv('EDS_HOST', '0.0.0.0')
PORT = int(os.getenv('EDS_PORT', '5001'))

# HTTPS: set both to serve the app over TLS directly. When TLS is terminated by
# a reverse proxy instead, set EDS_HTTPS=1 so session cookies are marked Secure.
SSL_CERT_FILE = os.getenv('EDS_SSL_CERT', '')
SSL_KEY_FILE = os.getenv('EDS_SSL_KEY', '')
HTTPS_ENABLED = bool(SSL_CERT_FILE and SSL_KEY_FILE) or os.getenv('EDS_HTTPS', '') == '1'

# Failed logins allowed per client address before it is locked out
LOGIN_MAX_FAILURES = int(os.getenv('EDS_LOGIN_MAX_FAILURES', '5'))
LOGIN_LOCKOUT_SECONDS = int(os.getenv('EDS_LOGIN_LOCKOUT_SECONDS', '900'))

ADMIN_USERNAME = os.getenv('EDS_ADMIN_USERNAME', 'admin')
# Hash of the default password "Admin@123". To change it, generate a new hash with
#   python -c "from werkzeug.security import generate_password_hash as g; print(g('NEW_PASSWORD'))"
# and set it in EDS_ADMIN_PASSWORD_HASH.
ADMIN_PASSWORD_HASH = os.getenv(
    'EDS_ADMIN_PASSWORD_HASH',
    'pbkdf2:sha256:600000$x5BmbeSCLPc83SKw$a63594b93d0ec61f89b9d777b7a0763d605c8be1bbc066a51298dc4249d16a21',
)

# Without a fixed key, a random one is generated per process, so users must
# log in again after every server restart.
SECRET_KEY = os.getenv('EDS_SECRET_KEY') or secrets.token_hex(32)
SESSION_LIFETIME = timedelta(hours=int(os.getenv('EDS_SESSION_HOURS', '8')))

# ----------------------------------------------------------------------------
# Execution
# ----------------------------------------------------------------------------

# Only files modified within this window are listed on the Downloads page.
DOWNLOAD_MAX_AGE_SECONDS = 3600

"""Issue-description summaries via the HBL AI Gateway (OpenAI-compatible API)."""

import logging
import unicodedata

import requests

import config

logger = logging.getLogger(__name__)

SUMMARY_PROMPT = """
For the following exception data (single record, not a table):
{record}

Prepare a descrption of ~50 to 70 words using the exception description and total count provided. Use below provided data:

Exception: {exception_name}
Exception Description: {issue_description}
Total Count: {instances}
Theme Risk Rating: {risk_rating}

Please do not write "here's the paragraph"; output ONLY the paragraph (no extra headers or preambles).
Total count of occurances of the exception must be included in final wording and embeded between the exception descrption properly and professionally.
Please make sure to write the exception in a very humanistic way. it should not use words like I, Me or We.\x20
The Exception description contains 1 or more than 1 ways of writing the exception details. use it please but it should make very realistic sense.


"""


def uses_tls():
    return config.LLM_GATEWAY_URL.lower().startswith('https://')


def _clean_reply(text):
    """Model output is untrusted: keep plain printable text of bounded length."""
    text = ''.join(ch for ch in str(text) if ch in '\n\t' or unicodedata.category(ch)[0] != 'C')
    return text.strip()[:config.LLM_MAX_SUMMARY_CHARS]


def generate_text(prompt, max_tokens=4096):
    """Send a single-turn chat completion request and return the reply text."""
    response = requests.post(
        f"{config.LLM_GATEWAY_URL}/v1/chat/completions",
        headers={
            'Content-Type': 'application/json',
            'Authorization': f"Bearer {config.LLM_GATEWAY_API_KEY}",
        },
        json={
            'model': config.LLM_MODEL,
            'messages': [{'role': 'user', 'content': prompt}],
            'max_tokens': max_tokens,
            'stream': False,
        },
        timeout=config.LLM_TIMEOUT_SECONDS,
        verify=config.LLM_CA_BUNDLE or True,
        allow_redirects=False,
    )
    response.raise_for_status()
    try:
        content = response.json()['choices'][0]['message']['content']
    except (ValueError, KeyError, IndexError, TypeError) as exc:
        raise RuntimeError(f"Unexpected gateway response (HTTP {response.status_code})") from exc
    return _clean_reply(content)


def summarize_exception(row, max_tokens=1000):
    """Write a short, human-readable issue description for one report row.

    ``row`` is a pandas Series with at least: exception_name, Issue Description,
    Instances and Issue Risk Rating.
    """
    prompt = SUMMARY_PROMPT.format(
        record=row.to_string(),
        exception_name=row.get('exception_name', ''),
        issue_description=row.get('Issue Description', ''),
        instances=row.get('Instances', ''),
        risk_rating=row.get('Issue Risk Rating', ''),
    )
    logger.debug("LLM prompt: %s", prompt)
    return generate_text(prompt, max_tokens)

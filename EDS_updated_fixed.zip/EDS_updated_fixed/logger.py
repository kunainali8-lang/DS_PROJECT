import logging
from datetime import datetime

################################################################################################################################################################################################################################
class Logger:
    def __init__(self):
        self.log_file = self.get_log_file_name()
        logging.basicConfig(filename=self.log_file, level=logging.INFO, format='%(asctime)s - %(message)s')

    def get_log_file_name(self):
        today_date = datetime.now().strftime("%Y-%m-%d")
        return f"./logs/log_{today_date}.txt"

    def log(self, message):
        current_log_file = self.get_log_file_name()
        if current_log_file != self.log_file:
            self.log_file = current_log_file
            logging.basicConfig(filename=self.log_file, level=logging.INFO, format='%(asctime)s - %(message)s')
        logging.info(message)


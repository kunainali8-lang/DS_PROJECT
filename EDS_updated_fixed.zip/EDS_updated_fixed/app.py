#!/usr/bin/env python3
"""Exception Detection System - Flask backend."""

import hmac
import logging
import os
import re
import threading
import time
from datetime import datetime

from flask import Flask, abort, jsonify, redirect, request, send_from_directory, session, url_for
from werkzeug.exceptions import HTTPException
from werkzeug.security import check_password_hash

import config
import execution_log
import llm_client
import security
from exceptions_handler import DYNAMIC_FIELDS, ExceptionsHandler, migrate_from_simple_csv
from logging_setup import SUCCESS, set_log_context, setup_logging
from metadata_store import MetadataStore
from steps_handler import STEP_FUNCTIONS, STEP_NAMES, ExecutionStopped, execute_step, parse_branches

for directory in (config.DATA_DIR, config.LOG_DIR, config.DOWNLOADS_DIR):
    os.makedirs(directory, exist_ok=True)

setup_logging(config.CONSOLE_LOG)
logger = logging.getLogger(__name__)

if os.path.exists(config.LEGACY_EXCEPTIONS_CSV) and not os.path.exists(config.EXCEPTIONS_CSV):
    migrate_from_simple_csv(config.LEGACY_EXCEPTIONS_CSV, config.EXCEPTIONS_CSV)

exceptions_store = ExceptionsHandler(config.EXCEPTIONS_CSV)
metadata_store = MetadataStore(config.META_XLSX, exceptions_store.read_exceptions)

app = Flask(__name__, static_folder=config.STATIC_DIR)
app.config.update(
    SECRET_KEY=config.SECRET_KEY,
    PERMANENT_SESSION_LIFETIME=config.SESSION_LIFETIME,
    SESSION_COOKIE_NAME='eds_session',
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE='Lax',
    SESSION_COOKIE_SECURE=config.HTTPS_ENABLED,
    MAX_CONTENT_LENGTH=1024 * 1024,  # Largest accepted request body
)

login_throttle = security.LoginThrottle(config.LOGIN_MAX_FAILURES, config.LOGIN_LOCKOUT_SECONDS)

# Longest accepted value per exception field (characters)
FIELD_MAX_LENGTH = {'issueDescription': 4000}
DEFAULT_MAX_LENGTH = 300


class ValidationError(ValueError):
    pass


def json_body():
    """Request JSON as a dict ({} if missing). Requires a JSON content type."""
    data = request.get_json(silent=True)
    return data if isinstance(data, dict) else {}


def text_field(data, key, max_length=DEFAULT_MAX_LENGTH):
    try:
        return security.clean_text(data.get(key), max_length)
    except ValueError:
        raise ValidationError(f"{key} is too long (max {max_length} characters)")


def error(message, status):
    return jsonify({'error': message}), status


@app.errorhandler(ValidationError)
def handle_validation_error(exc):
    return error(str(exc), 400)


@app.errorhandler(Exception)
def handle_unexpected_error(exc):
    """Log the details server-side; never send internals to the client."""
    if isinstance(exc, HTTPException):
        return error(exc.name, exc.code)
    logger.exception("Unhandled error on %s %s", request.method, request.path)
    return error('Internal server error', 500)


@app.after_request
def set_security_headers(response):
    return security.add_security_headers(response)


# ============================================================================
# Authentication & CSRF
# ============================================================================

PUBLIC_ENDPOINTS = {'login_page', 'login', 'csrf', 'health', 'static', 'favicon'}


@app.before_request
def enforce_access_control():
    if request.path.startswith('/api/') and not security.csrf_valid():
        return error('Invalid or missing CSRF token; reload the page', 403)
    if request.endpoint in PUBLIC_ENDPOINTS or session.get('user'):
        return None
    if request.path.startswith('/api/'):
        return error('authentication required', 401)
    return redirect(url_for('login_page'))


@app.route('/api/csrf')
def csrf():
    return jsonify({'token': security.csrf_token()})


@app.route('/login')
def login_page():
    if session.get('user'):
        return redirect(url_for('index'))
    return send_from_directory(config.BASE_DIR, 'login.html')


@app.route('/api/login', methods=['POST'])
def login():
    client = request.remote_addr
    retry_after = login_throttle.retry_after(client)
    if retry_after:
        security.audit('login_blocked')
        return error(f"Too many failed logins; try again in {retry_after // 60 + 1} minute(s)", 429)

    data = json_body()
    username = text_field(data, 'username', 100)
    password = str(data.get('password') or '')[:200]

    valid_user = hmac.compare_digest(username.encode(), config.ADMIN_USERNAME.encode())
    valid_password = check_password_hash(config.ADMIN_PASSWORD_HASH, password)
    if not (valid_user and valid_password):
        login_throttle.record_failure(client)
        logger.warning("Failed login attempt from %s", client)
        security.audit('login_failed', username=username)
        return error('Invalid username or password', 401)

    login_throttle.reset(client)
    session.clear()  # New session on login (prevents session fixation)
    session.permanent = True
    session['user'] = username
    logger.info("User '%s' logged in from %s", username, client)
    security.audit('login')
    return jsonify({'message': 'logged in'})


@app.route('/api/logout', methods=['POST'])
def logout():
    logger.info("User '%s' logged out", session.get('user'))
    security.audit('logout')
    session.clear()
    return jsonify({'message': 'logged out'})


@app.route('/api/session')
def current_session():
    return jsonify({'user': session['user']})


# ============================================================================
# Pages & health
# ============================================================================

@app.route('/')
def index():
    return send_from_directory(config.BASE_DIR, 'index.html')


@app.route('/api/health')
def health():
    return jsonify({'status': 'ok', 'time': datetime.now().isoformat()})


@app.route('/favicon.ico')
def favicon():
    return '', 204


# ============================================================================
# Metadata
# ============================================================================

@app.route('/api/meta')
def meta_get():
    return jsonify(metadata_store.read())


@app.route('/api/meta/theme', methods=['POST', 'PUT', 'DELETE'])
def meta_theme():
    data = json_body()

    if request.method == 'POST':
        name = text_field(data, 'name')
        if not name:
            return error('name required', 400)
        metadata_store.add('themes', {'theme': name})
        logger.info("Theme added: %s", name)
        security.audit('theme_add', name=name)
        return jsonify({'message': 'theme added'})

    if request.method == 'PUT':
        old_name, new_name = text_field(data, 'oldName'), text_field(data, 'newName')
        if not old_name or not new_name:
            return error('oldName and newName required', 400)
        in_meta = metadata_store.rename_theme(old_name, new_name)
        in_exceptions = exceptions_store.update_theme_name(old_name, new_name)
        if not in_meta and not in_exceptions:
            return error('theme not found', 404)
        logger.info("Theme renamed: %s -> %s", old_name, new_name)
        security.audit('theme_rename', old=old_name, new=new_name)
        return jsonify({'message': 'theme updated'})

    name = text_field(data, 'name')
    if not name:
        return error('name required', 400)
    metadata_store.delete_theme(name)
    logger.info("Theme deleted: %s", name)
    security.audit('theme_delete', name=name)
    return jsonify({'message': 'theme deleted'})


@app.route('/api/meta/subtheme', methods=['POST', 'PUT', 'DELETE'])
def meta_subtheme():
    data = json_body()

    if request.method == 'POST':
        name, parent = text_field(data, 'name'), text_field(data, 'parentTheme')
        if not name:
            return error('name required', 400)
        metadata_store.add('sub_themes', {'subTheme': name, 'parentTheme': parent})
        logger.info("Sub-theme added: %s (parent: %s)", name, parent or 'n/a')
        security.audit('subtheme_add', name=name, parent=parent)
        return jsonify({'message': 'sub-theme added'})

    if request.method == 'PUT':
        old_name, old_parent = text_field(data, 'oldName'), text_field(data, 'oldParent')
        new_name, new_parent = text_field(data, 'newName'), text_field(data, 'newParent')
        if not old_name or not new_name:
            return error('oldName and newName required', 400)
        in_meta = metadata_store.rename_subtheme(old_name, old_parent, new_name, new_parent)
        in_exceptions = exceptions_store.update_subtheme_name(old_parent, old_name, new_parent, new_name)
        if not in_meta and not in_exceptions:
            return error('sub-theme not found', 404)
        logger.info("Sub-theme renamed: %s -> %s", old_name, new_name)
        security.audit('subtheme_rename', old=f"{old_parent}/{old_name}", new=f"{new_parent}/{new_name}")
        return jsonify({'message': 'sub-theme updated'})

    name, parent = text_field(data, 'name'), text_field(data, 'parentTheme')
    if not name:
        return error('name required', 400)
    metadata_store.delete_subtheme(name, parent)
    logger.info("Sub-theme deleted: %s", name)
    security.audit('subtheme_delete', name=name, parent=parent)
    return jsonify({'message': 'sub-theme deleted'})


# ============================================================================
# Exceptions
# ============================================================================

def _exception_fields(data):
    """Validated editable exception fields present in ``data``."""
    fields = {}
    for field in DYNAMIC_FIELDS:
        if field == 'id' or data.get(field) is None:
            continue
        max_length = FIELD_MAX_LENGTH.get(field, DEFAULT_MAX_LENGTH)
        try:
            fields[field] = security.clean_text(data[field], max_length,
                                                multiline=field == 'issueDescription')
        except ValueError:
            raise ValidationError(f"{field} is too long (max {max_length} characters)")
    view_name = fields.get('viewName')
    if view_name and not security.valid_view_name(view_name):
        raise ValidationError('viewName must look like SCHEMA.VIEW_NAME '
                              '(letters, digits and underscores only)')
    return fields


def _register_themes(item):
    """Make sure an exception's theme / sub-theme exist in the metadata."""
    if item.get('theme'):
        metadata_store.add('themes', {'theme': item['theme']})
    if item.get('subTheme'):
        metadata_store.add('sub_themes', {'subTheme': item['subTheme'], 'parentTheme': item['theme']})


@app.route('/api/exceptions', methods=['GET'])
def exceptions_list():
    items = exceptions_store.read_exceptions()
    meta = metadata_store.read()

    themes_exceptions = sorted({x['theme'].strip() for x in items if x['theme'].strip()})
    themes_metadata = sorted({t['theme'] for t in meta['themes'] if t['theme']})

    return jsonify({
        'exceptions': items,
        'themes_exceptions': themes_exceptions,
        'themes_metadata': themes_metadata,
        'themes_union': sorted(set(themes_exceptions) | set(themes_metadata)),
        'subthemes_meta': meta['sub_themes'],
    })


@app.route('/api/exceptions', methods=['POST'])
def exceptions_create():
    added = exceptions_store.add_exception(_exception_fields(json_body()))
    _register_themes(added)
    logger.info("Added exception #%s: %s", added['id'], added['exceptionName'])
    security.audit('exception_add', id=added['id'], name=added['exceptionName'])
    return jsonify({'message': 'exception added', 'id': added['id']}), 201


@app.route('/api/exceptions/<int:ex_id>', methods=['PUT'])
def exceptions_update(ex_id):
    changes = _exception_fields(json_body())
    updated = exceptions_store.update_exception(ex_id, changes)
    if updated is None:
        return error('not found', 404)
    _register_themes(updated)
    logger.info("Updated exception #%s: %s", ex_id, updated['exceptionName'])
    security.audit('exception_update', id=ex_id, fields=sorted(changes))
    return jsonify({'message': 'updated', 'id': ex_id})


@app.route('/api/exceptions/<int:ex_id>', methods=['DELETE'])
def exceptions_delete(ex_id):
    removed = exceptions_store.delete_exception(ex_id)
    if removed is None:
        return error('not found', 404)
    logger.warning("Deleted exception #%s: %s", ex_id, removed['exceptionName'])
    security.audit('exception_delete', id=ex_id, name=removed['exceptionName'])
    return jsonify({'message': 'deleted'})


# ============================================================================
# Execution
# ============================================================================

# Execution state, keyed by execution id. Only the worker thread writes to its own
# entry; every read and write goes through executions_lock.
executions = {}
executions_lock = threading.Lock()

MAX_LISTED_ISSUES = 200


def _duration(started, finished):
    if started is None:
        return None
    return round((finished or time.time()) - started, 1)


def _snapshot(run):
    """JSON-ready view of an execution for the UI. Caller holds executions_lock."""
    return {
        'id': run['id'],
        'status': run['status'],
        'message': run['message'],
        'user': run['user'],
        'started_at': datetime.fromtimestamp(run['started']).isoformat(sep=' ', timespec='seconds'),
        'elapsed_seconds': _duration(run['started'], run['finished']),
        'current_step': run['current_step'],
        'task': run['task'],
        'progress': dict(run['progress']),
        'steps': [
            {'number': s['number'], 'name': s['name'], 'status': s['status'], 'error': s['error'],
             'duration_seconds': _duration(s['started'], s['finished'])}
            for s in run['steps']
        ],
        'issues': list(run['issues']),
        'issue_counts': dict(run['issue_counts']),
        'generated_files': run['generated_files'],
    }


class _ExecutionTracker:
    """Updates one execution's state on behalf of its worker thread."""

    def __init__(self, exec_id):
        self.run = executions[exec_id]

    def update(self, **fields):
        with executions_lock:
            self.run.update(fields)

    def update_step(self, number, **fields):
        with executions_lock:
            next(s for s in self.run['steps'] if s['number'] == number).update(fields)

    def should_stop(self):
        with executions_lock:
            return self.run['stop']

    def on_progress(self, task, done=None, total=None):
        with executions_lock:
            self.run['task'] = task
            self.run['progress'] = {'done': done, 'total': total}

    def on_issue(self, level, message):
        with executions_lock:
            counts = self.run['issue_counts']
            counts[level] = counts.get(level, 0) + 1
            if len(self.run['issues']) < MAX_LISTED_ISSUES:
                self.run['issues'].append({
                    'time': datetime.now().strftime('%H:%M:%S'),
                    'step': self.run['current_step'],
                    'level': level,
                    'message': message,
                })

    def finish(self, status, message, step=None, step_status=None, step_error=None):
        """Close the run; the current step gets ``step_status``, unstarted steps 'skipped'."""
        now = time.time()
        with executions_lock:
            for s in self.run['steps']:
                if s['number'] == step and step_status:
                    s.update(status=step_status, error=step_error, finished=now)
                elif s['status'] == 'pending':
                    s['status'] = 'skipped'
            self.run.update(status=status, message=message, finished=now)


_DATE_RE = re.compile(r'\d{4}-\d{2}-\d{2}')


def _execution_parameters(raw):
    """Only the known execution parameters, validated."""
    raw = raw if isinstance(raw, dict) else {}
    params = {}
    for key in ('startDate', 'endDate'):
        value = text_field(raw, key, 10)
        if value and not _DATE_RE.fullmatch(value):
            raise ValidationError(f"{key} must be a date in YYYY-MM-DD format")
        params[key] = value
    branches = text_field(raw, 'branches', 5000)
    if branches and not all(_valid_branch(b) for b in parse_branches(branches)):
        raise ValidationError('branches may only contain letters, digits, spaces, - and _')
    params['branches'] = branches
    if 'use_llm_summary' in raw:
        params['use_llm_summary'] = bool(raw['use_llm_summary'])
    return params


def _valid_branch(branch):
    return bool(re.fullmatch(r'[A-Za-z0-9 _-]{1,100}', branch))


@app.route('/api/execute', methods=['POST'])
def execute_start():
    payload = json_body()
    try:
        exception_ids = [int(i) for i in payload.get('exception_ids') or []]
        steps = [int(s) for s in payload.get('steps') or []]
    except (TypeError, ValueError):
        return error('exception_ids and steps must be lists of integers', 400)
    if not steps or len(set(steps)) != len(steps) or any(s not in STEP_FUNCTIONS for s in steps):
        return error(f"steps must be distinct values chosen from {sorted(STEP_FUNCTIONS)}", 400)
    params = _execution_parameters(payload.get('parameters'))

    with executions_lock:
        if any(e['status'] == 'in_progress' for e in executions.values()):
            return error('Another execution is already in progress', 409)
        exec_id = f"exec_{int(time.time() * 1000)}"
        executions[exec_id] = {
            'id': exec_id,
            'status': 'in_progress',
            'message': 'Execution started',
            'user': session.get('user'),
            'started': time.time(),
            'finished': None,
            'current_step': None,
            'task': '',
            'progress': {'done': None, 'total': None},
            'steps': [
                {'number': s, 'name': STEP_NAMES[s], 'status': 'pending', 'error': None,
                 'started': None, 'finished': None}
                for s in steps
            ],
            'issues': [],
            'issue_counts': {},
            'generated_files': [],
            'stop': False,
        }

    logger.info("Execution %s started by '%s': steps %s on %d exception(s), parameters %s",
                exec_id, session.get('user'), steps, len(exception_ids), params)
    security.audit('execute', id=exec_id, steps=steps, exceptions=len(exception_ids))
    threading.Thread(
        target=_run_execution, args=(exec_id, exception_ids, steps, params), daemon=True,
    ).start()
    return jsonify({'execution_id': exec_id})


def _run_execution(exec_id, exception_ids, steps, params):
    tracker = _ExecutionTracker(exec_id)
    context = {
        'exception_ids': exception_ids,
        'parameters': params,
        'downloads_dir': config.DOWNLOADS_DIR,
        'exceptions_csv': config.EXCEPTIONS_CSV,
        'should_stop': tracker.should_stop,
        'on_progress': tracker.on_progress,
        'on_issue': tracker.on_issue,
    }

    step = None  # The step currently running, if any
    try:
        for position, next_step in enumerate(steps, start=1):
            if tracker.should_stop():
                raise ExecutionStopped()
            step = next_step
            set_log_context(f"[Step {step}] ")
            logger.info("===== Step %d of %d started: %s =====", position, len(steps), STEP_NAMES[step])
            tracker.update(current_step=step, task='', progress={'done': None, 'total': None},
                           message=f"Step {step}: {STEP_NAMES[step]}")
            tracker.update_step(step, status='running', started=time.time())
            execute_step(step, context)
            tracker.update_step(step, status='completed', finished=time.time())
            logger.log(SUCCESS, "===== Step %d finished: %s =====", step, STEP_NAMES[step])
            step = None
    except ExecutionStopped:
        where = f"during step {step}" if step else "between steps"
        tracker.finish('stopped', f"Stopped by user {where}", step, 'stopped')
        logger.warning("Execution stopped by user")
        return
    except Exception as exc:
        logger.exception("Step %s failed: %s", step, exc)
        tracker.finish('failed', f"Step {step} ({STEP_NAMES[step]}) failed: {exc}", step, 'failed', str(exc))
        return
    finally:
        set_log_context('')

    files = list_generated_files()
    with executions_lock:
        warnings = sum(executions[exec_id]['issue_counts'].values())
    message = 'Execution completed successfully'
    if warnings:
        message += f" with {warnings} issue(s) - see the Issues list"
    tracker.update(generated_files=files, task='')
    tracker.finish('completed', message)
    logger.log(SUCCESS, "Execution %s completed: %d file(s) ready, %d issue(s)", exec_id, len(files), warnings)


@app.route('/api/execution/<exec_id>/status')
def execution_status(exec_id):
    with executions_lock:
        run = executions.get(exec_id)
        if run is None:
            return error('not found', 404)
        return jsonify(_snapshot(run))


@app.route('/api/execution/current')
def execution_current():
    """The most recent execution (running or finished), so the UI can reconnect after a reload."""
    with executions_lock:
        if not executions:
            return jsonify({'execution': None})
        latest = max(executions.values(), key=lambda r: r['started'])
        return jsonify({'execution': _snapshot(latest)})


@app.route('/api/execution/<exec_id>/stop', methods=['POST'])
def execution_stop(exec_id):
    with executions_lock:
        if exec_id not in executions:
            return error('not found', 404)
        executions[exec_id]['stop'] = True
    logger.warning("Stop requested for %s", exec_id)
    security.audit('execute_stop', id=exec_id)
    return jsonify({'message': 'stop requested'})


@app.route('/api/execution/log')
def execution_log_summary():
    return jsonify(execution_log.get_summary())


@app.route('/api/execution/log/clear', methods=['POST'])
def execution_log_clear():
    execution_log.clear()
    security.audit('execution_log_clear')
    return jsonify({'message': 'Execution log cleared successfully'})


# ============================================================================
# Downloads
# ============================================================================

def list_generated_files():
    """Top-level files in the downloads folder modified recently, newest first."""
    cutoff = time.time() - config.DOWNLOAD_MAX_AGE_SECONDS
    files = []
    for name in os.listdir(config.DOWNLOADS_DIR):
        path = os.path.join(config.DOWNLOADS_DIR, name)
        if os.path.isfile(path) and os.path.getmtime(path) >= cutoff:
            modified = datetime.fromtimestamp(os.path.getmtime(path))
            files.append({
                'name': name,
                'file': name,
                'date': modified.isoformat(sep=' ', timespec='seconds'),
            })
    return sorted(files, key=lambda f: f['date'], reverse=True)


@app.route('/api/downloads')
def downloads_list():
    return jsonify({'downloads': list_generated_files()})


@app.route('/api/download/<filename>')
def download_file(filename):
    # Only files the app generated and lists are downloadable; the name is taken
    # from that allow-list, never from the request path.
    allowed = {f['file'] for f in list_generated_files()}
    safe_name = next((name for name in allowed if name == os.path.basename(filename)), None)
    if safe_name is None:
        abort(404)
    security.audit('download', file=safe_name)
    return send_from_directory(config.DOWNLOADS_DIR, safe_name, as_attachment=True)


# ============================================================================
# Console
# ============================================================================

CONSOLE_INITIAL_BYTES = 256 * 1024
CONSOLE_MAX_CHUNK_BYTES = 1024 * 1024


@app.route('/api/console/tail')
def console_tail():
    """Console log lines for the UI.

    Without ``offset`` the last ``limit`` lines are returned. With ``offset``
    (the value returned by the previous call) only lines written since then are
    returned. Either way the response carries the offset for the next call.
    """
    offset = request.args.get('offset', type=int)
    limit = max(1, min(request.args.get('limit', 200, type=int), 2000))

    if not os.path.exists(config.CONSOLE_LOG):
        return jsonify({'lines': [], 'offset': 0})

    with open(config.CONSOLE_LOG, 'rb') as f:
        size = f.seek(0, os.SEEK_END)
        if offset is None or offset > size:  # First call, or the log was truncated
            f.seek(max(0, size - CONSOLE_INITIAL_BYTES))
            lines = f.read().decode('utf-8', errors='replace').splitlines()[-limit:]
            return jsonify({'lines': lines, 'offset': size})

        f.seek(offset)
        chunk = f.read(CONSOLE_MAX_CHUNK_BYTES)

    # Only hand out complete lines; a partial last line is picked up next time
    complete = chunk[:chunk.rfind(b'\n') + 1]
    lines = complete.decode('utf-8', errors='replace').splitlines()
    return jsonify({'lines': lines, 'offset': offset + len(complete)})


# ============================================================================
# Main
# ============================================================================

if __name__ == '__main__':
    metadata_store.ensure_workbook()
    logger.info("Exception Detection System starting")
    logger.info("Exceptions CSV: %s", config.EXCEPTIONS_CSV)
    logger.info("Downloads: %s", config.DOWNLOADS_DIR)
    logger.info("ODBC DSN: %s / schema %s", config.ODBC_DSN, config.DB_NAME)
    if not llm_client.uses_tls():
        logger.warning("AI gateway URL is not HTTPS (%s); traffic to it is unencrypted. "
                       "Set HBL_AI_GATEWAY_URL to an https:// address.", config.LLM_GATEWAY_URL)

    ssl_context = None
    if config.SSL_CERT_FILE and config.SSL_KEY_FILE:
        ssl_context = (config.SSL_CERT_FILE, config.SSL_KEY_FILE)
        logger.info("Serving over HTTPS")
    elif not config.HTTPS_ENABLED:
        logger.warning("Serving over plain HTTP; set EDS_SSL_CERT/EDS_SSL_KEY to enable HTTPS")
    app.run(host=config.HOST, port=config.PORT, debug=False, ssl_context=ssl_context)

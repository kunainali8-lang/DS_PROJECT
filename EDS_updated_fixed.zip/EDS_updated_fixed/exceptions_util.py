###LIBRARY IMPORT
##################################################################################################################################################################################################
from data_exporter_tool import direct_execute 
from data_exporter_tool import table_creator 
from data_exporter_tool import table_dropper 
from data_exporter_tool import extract_with_checkpoints
from data_exporter_tool import create_table
from logger import Logger
import pandas as pd
import numpy as np
from datetime import datetime
import os
from openpyxl import load_workbook
from cohere_r7b import prepare_input_and_generate_summary_for_exceptions
import excel_util
from data_exporter_tool import direct_execute_to_df
from data_exporter_tool import extract_with_threads
import json
#functions 
##################################################################################################################################################################################################

# Execution tracking file path
EXECUTION_LOG_FILE = './logs/view_execution_log.json'

def log_view_execution(view_name, parent_exception, status, error_message=None):
    """
    Log execution details for each view
    
    Parameters:
    - view_name: The view name being executed
    - parent_exception: The parent exception name
    - status: 'success' or 'failed'
    - error_message: Optional error message if failed
    """
    # Ensure logs directory exists
    os.makedirs('./logs', exist_ok=True)
    
    # Load existing log or create new
    if os.path.exists(EXECUTION_LOG_FILE):
        with open(EXECUTION_LOG_FILE, 'r') as f:
            try:
                execution_log = json.load(f)
            except:
                execution_log = {'executions': []}
    else:
        execution_log = {'executions': []}
    
    # Add new execution entry
    execution_entry = {
        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'view_name': view_name,
        'parent_exception': parent_exception,
        'status': status,
        'error_message': error_message
    }
    
    execution_log['executions'].append(execution_entry)
    
    # Write back to file
    with open(EXECUTION_LOG_FILE, 'w') as f:
        json.dump(execution_log, f, indent=2)

def get_execution_summary():
    """
    Get a summary of all executed views
    
    Returns:
    - Dictionary with execution summary
    """
    if not os.path.exists(EXECUTION_LOG_FILE):
        return {
            'total_executions': 0,
            'successful': 0,
            'failed': 0,
            'executions': []
        }
    
    with open(EXECUTION_LOG_FILE, 'r') as f:
        try:
            execution_log = json.load(f)
        except:
            return {
                'total_executions': 0,
                'successful': 0,
                'failed': 0,
                'executions': []
            }
    
    executions = execution_log.get('executions', [])
    successful = sum(1 for e in executions if e.get('status') == 'success')
    failed = sum(1 for e in executions if e.get('status') == 'failed')
    
    return {
        'total_executions': len(executions),
        'successful': successful,
        'failed': failed,
        'executions': executions
    }

def clear_execution_log():
    """Clear the execution log file"""
    if os.path.exists(EXECUTION_LOG_FILE):
        os.remove(EXECUTION_LOG_FILE)
    print("[INFO] Execution log cleared")

##to print logs
def print_log(text,logger):
    print('---',text,'---')
    logger.log(('---',text,'---'))

##to read branch file
def read_csv(file_path):
    try:
        df = pd.read_csv(file_path)
        return df
    except Exception as e:
        print(f"An error occurred: {e}")
        return None

#function to break exceptions data into branch wise folders
##------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
def break_exceptions_data_branch_wise(exceptionsv2, logger):
    """Backward-compatible no-op; no branch files are created."""
    del exceptionsv2
    print_log("Branch segregation skipped; data remains in database tables",logger)



##------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


def prepare_final_exceptions_report(exceptions_file_path, branch_info_path, cohere_api_key, logger):
    """Legacy aggregate report entry point; never reads detailed local files."""
    del branch_info_path
    meta=pd.read_csv(exceptions_file_path); output=[]
    for view,g in meta[meta['viewName'].notna()].groupby('viewName',sort=False):
        suffix=str(view).strip().split('.',1)[-1]
        if not suffix.replace('_','').isalnum(): raise ValueError(f"Unsafe identifier: {view}")
        table=f"FCCM_UAT.DS_{suffix}"
        try:
            c=direct_execute_to_df(f"SELECT error AS exception_name, COUNT(*) AS instances FROM {table} GROUP BY error"); c.columns=[str(x).lower() for x in c.columns]
        except Exception:
            c=direct_execute_to_df(f"SELECT COUNT(*) AS instances FROM {table}"); c.columns=[str(x).lower() for x in c.columns]; c['exception_name']=str(g.iloc[0].get('parentException',suffix))
        for _,x in c.iterrows():
            r=g.iloc[0]; n=pd.to_numeric(x.get('instances',0),errors='coerce'); n=0 if pd.isna(n) else int(n); name=str(x.get('exception_name','')).strip()
            row={'Theme':str(r.get('theme','')).strip(),'Sub-Theme':str(r.get('subTheme','')).strip(),'Issue Risk Rating':str(r.get('issueRiskRating','')).strip(),'Issue Description':str(r.get('issueDescription','')).strip(),'Instances':n,'exception_name':name or suffix,'source_table':table}
            try:
                text=prepare_input_and_generate_summary_for_exceptions(pd.Series(row),cohere_api_key,max_tokens=200)
                if text: row['Issue Description']=text
            except Exception as exc: print_log(f"[WARN] AI summary skipped: {exc}",logger)
            output.append(row)
    report=pd.DataFrame(output); os.makedirs('./exceptions',exist_ok=True); report.to_csv('./exceptions/exceptions_report.csv',index=False); return report





##pick exception_name, its details and sql query to load and export data in ./exceptions/ folder path
##------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------



import pandas as pd

def rule_based_exception_identification(exceptions_csv, logger=None, verbose=True):
    """
    Execute each distinct view_name only once.

    - Reads exceptions_v2.csv
    - Skips rows where view_name is empty / 'nan'
    - Deduplicates views
    - Executes: SELECT * FROM <view_name>
    - Passes a single parent_exception label to prepare_exceptions_data
    """
    # Load CSV
    try:
        df = pd.read_csv(exceptions_csv)
    except Exception as e:
        print_log(f"Failed to read exceptions CSV: {e}", logger)
        return

    # Normalize and filter valid view_names
    df['view_name'] = df.get('view_name', '').astype(str).str.strip()
    valid_df = df[
        df['view_name'].notna() &
        (df['view_name'] != '') &
        (df['view_name'].str.lower() != 'nan')
    ].copy()

    if valid_df.empty:
        print_log("No valid view_name rows to process in exceptions CSV.", logger)
        return

    # Deduplicate: one run per distinct view_name
    unique_views = valid_df['view_name'].drop_duplicates().tolist()

    i = 0
    for view in unique_views:
        # Pick a representative parent_exception for logging/table naming
        # (first non-empty; else fall back to view token)
        pe_series = valid_df.loc[valid_df['view_name'] == view, 'parent_exception'].astype(str).str.strip()
        parent_exception = next((pe for pe in pe_series if pe), '') or view.split('.')[-1]

        sql_text = f"SELECT * FROM {view}"

        if verbose:
            print_log(f"Execution NO : {i}\n\n#####\n####\n###\n##\nRunning single execution for view: {view} -> parent_exception: {parent_exception}", logger)

        # Execute and materialize DS_* once per view
        prepare_exceptions_data(sql_text, parent_exception, logger)
        print(f"##\n###\n####\n######\n")
        i = i + 1
    print_log("RULE BASED EXCEPTIONS PROCESS COMPLETE", logger)

def prepare_exceptions_data(sql_text, exception_name, logger):
    """Create DS_* table without extracting grain-level data."""
    table='DS_'+exception_name
    try:
        try: table_dropper('FCCM_UAT',table)
        except Exception as exc: print_log(f"[WARN] Drop skipped: {exc}",logger)
        table_creator(sql_text,'FCCM_UAT',table); log_view_execution(exception_name,exception_name,'success'); print_log(f"[SUCCESS] Created FCCM_UAT.{table}; no local file created",logger); return True
    except Exception as exc:
        log_view_execution(exception_name,exception_name,'failed',str(exc)); raise





                
##prepare annexure data for all queries available in the ./queries/ folder
##------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
def import_PP_data(exception_queries,exceptions,logger):

    for index, row in exception_queries.iterrows():
        exception_name = row['exception_name']
        file_path = f'./queries/{exception_name}.sql'
        
        try:
            with open(file_path, 'r') as file:
                sql_text = file.read()

                #preparing annexure data for exception
                exception_data = prepare_exceptions_data(sql_text,exceptions[exceptions['exception_name'] == exception_name],exception_name,logger)

        except FileNotFoundError:
            print_log(f"SQL file for {exception_name} not found at {file_path}.\n",logger)
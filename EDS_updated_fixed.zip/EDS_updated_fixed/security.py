"""HTTP security controls: response headers, CSRF protection, login throttling,
input validation and audit logging."""

import hmac
import logging
import re
import secrets
import threading
import time
import unicodedata
from collections import defaultdict, deque

from flask import request, session

audit_logger = logging.getLogger('audit')

# ----------------------------------------------------------------------------
# Security headers
# ----------------------------------------------------------------------------

CONTENT_SECURITY_POLICY = (
    "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
    "connect-src 'self'; font-src 'self'; object-src 'none'; base-uri 'self'; "
    "form-action 'self'; frame-ancestors 'none'"
)


def add_security_headers(response):
    headers = response.headers
    headers['Content-Security-Policy'] = CONTENT_SECURITY_POLICY
    headers['X-Frame-Options'] = 'DENY'
    headers['X-Content-Type-Options'] = 'nosniff'
    headers['Referrer-Policy'] = 'no-referrer'
    headers['Permissions-Policy'] = 'camera=(), microphone=(), geolocation=()'
    headers['Cross-Origin-Opener-Policy'] = 'same-origin'
    # Browsers only honour HSTS over HTTPS, so it is harmless on plain HTTP
    headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
    if request.path.startswith('/api/') or response.mimetype == 'text/html':
        headers['Cache-Control'] = 'no-store'
    return response


# ----------------------------------------------------------------------------
# CSRF protection (synchronizer token sent in a custom header)
# ----------------------------------------------------------------------------

CSRF_HEADER = 'X-CSRF-Token'
SAFE_METHODS = {'GET', 'HEAD', 'OPTIONS'}


def csrf_token():
    """The CSRF token of the current session, created on first use."""
    if '_csrf' not in session:
        session['_csrf'] = secrets.token_urlsafe(32)
    return session['_csrf']


def csrf_valid():
    if request.method in SAFE_METHODS:
        return True
    expected = session.get('_csrf', '')
    sent = request.headers.get(CSRF_HEADER, '')
    return bool(expected) and hmac.compare_digest(sent, expected)


# ----------------------------------------------------------------------------
# Login throttling
# ----------------------------------------------------------------------------

class LoginThrottle:
    """Blocks a client after too many failed logins within a time window."""

    def __init__(self, max_failures=5, window_seconds=900):
        self.max_failures = max_failures
        self.window = window_seconds
        self._failures = defaultdict(deque)
        self._lock = threading.Lock()

    def _prune(self, key, now):
        attempts = self._failures[key]
        while attempts and now - attempts[0] > self.window:
            attempts.popleft()
        return attempts

    def retry_after(self, key):
        """Seconds until ``key`` may try again (0 if not blocked)."""
        now = time.time()
        with self._lock:
            attempts = self._prune(key, now)
            if len(attempts) < self.max_failures:
                return 0
            return int(self.window - (now - attempts[0])) + 1

    def record_failure(self, key):
        with self._lock:
            self._failures[key].append(time.time())

    def reset(self, key):
        with self._lock:
            self._failures.pop(key, None)


# ----------------------------------------------------------------------------
# Input validation
# ----------------------------------------------------------------------------

_VIEW_NAME_RE = re.compile(r'([A-Za-z_][A-Za-z0-9_]*\.)?[A-Za-z_][A-Za-z0-9_]*')


def clean_text(value, max_length, multiline=False):
    """Trimmed string without control characters; ValueError if longer than ``max_length``."""
    text = unicodedata.normalize('NFC', str(value or ''))
    allowed = {'\n', '\t'} if multiline else set()
    text = ''.join(ch for ch in text
                   if ch in allowed or unicodedata.category(ch)[0] != 'C').strip()
    if len(text) > max_length:
        raise ValueError(f"value longer than {max_length} characters")
    return text


def valid_view_name(value):
    """A view reference like SCHEMA.VIEW_NAME made only of identifier characters."""
    return bool(_VIEW_NAME_RE.fullmatch(value))


# ----------------------------------------------------------------------------
# Audit trail
# ----------------------------------------------------------------------------

def audit(action, **details):
    """Record who did what from where (written to logs/audit.log)."""
    user = session.get('user', '-')
    extra = ' '.join(f"{key}={value!r}" for key, value in details.items())
    audit_logger.info("user=%s ip=%s action=%s %s", user, request.remote_addr, action, extra)

"""Dropdown metadata (themes, sub-themes, risk types, ...) kept in an Excel workbook."""

import logging
import os
import threading

import pandas as pd

logger = logging.getLogger(__name__)

# Sheet name -> column names
SHEETS = {
    'themes': ['theme'],
    'sub_themes': ['subTheme', 'parentTheme'],
    'risk_types': ['riskType'],
    'issue_types': ['issueType'],
    'issue_owners': ['issueOwner'],
}

# Single-column sheets that the API returns as plain string lists
VALUE_SHEETS = ('risk_types', 'issue_types', 'issue_owners')

DEFAULT_VALUES = {
    'risk_types': ['Strategic', 'Operational', 'Financial', 'Compliance'],
    'issue_types': ['Design', 'Operational Error'],
    'issue_owners': ['Branch Manager', 'Operations Team', 'Compliance Team', 'Risk Team'],
}


def _clean(value):
    return '' if pd.isna(value) else str(value).strip()


class MetadataStore:

    def __init__(self, xlsx_path, seed_exceptions):
        """``seed_exceptions`` is a callable returning exception dicts, used to
        populate themes/sub-themes when the workbook is first created."""
        self.xlsx_path = xlsx_path
        self._seed_exceptions = seed_exceptions
        self._lock = threading.RLock()

    # ------------------------------------------------------------------
    # Workbook I/O
    # ------------------------------------------------------------------

    def _load_sheets(self):
        """Return {sheet: DataFrame of strings}, creating the workbook if needed."""
        if not os.path.exists(self.xlsx_path):
            sheets = self._initial_sheets()
            self._save_sheets(sheets)
            logger.info("Created metadata workbook: %s", self.xlsx_path)
            return sheets

        raw = pd.read_excel(self.xlsx_path, sheet_name=None, engine='openpyxl', dtype=str)
        sheets = {}
        for name, columns in SHEETS.items():
            df = raw.get(name, pd.DataFrame(columns=columns))
            for col in columns:
                if col not in df.columns:
                    df[col] = ''
            df = df[columns].apply(lambda s: s.map(_clean))
            # Drop blank rows and repeated entries
            sheets[name] = df[df.ne('').any(axis=1)].drop_duplicates().reset_index(drop=True)
        return sheets

    def _save_sheets(self, sheets):
        with pd.ExcelWriter(self.xlsx_path, engine='openpyxl') as writer:
            for name, columns in SHEETS.items():
                sheets[name].reindex(columns=columns).to_excel(writer, sheet_name=name, index=False)

    def _initial_sheets(self):
        items = self._seed_exceptions()
        themes = sorted({x['theme'] for x in items if x.get('theme')})
        sub_themes = sorted({(x['subTheme'], x['theme']) for x in items if x.get('subTheme')})
        sheets = {
            'themes': pd.DataFrame({'theme': themes}, dtype=str),
            'sub_themes': pd.DataFrame(sub_themes, columns=SHEETS['sub_themes'], dtype=str),
        }
        for name in VALUE_SHEETS:
            sheets[name] = pd.DataFrame({SHEETS[name][0]: DEFAULT_VALUES[name]}, dtype=str)
        return sheets

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def ensure_workbook(self):
        with self._lock:
            self._save_sheets(self._load_sheets())

    def read(self):
        """Return all metadata in the shape the frontend expects."""
        with self._lock:
            sheets = self._load_sheets()
        meta = {
            'themes': sheets['themes'].to_dict('records'),
            'sub_themes': sheets['sub_themes'].to_dict('records'),
        }
        for name in VALUE_SHEETS:
            meta[name] = sheets[name][SHEETS[name][0]].tolist()
        return meta

    def add(self, sheet, row):
        """Add ``row`` (a dict keyed by the sheet's columns) unless already present."""
        if sheet not in SHEETS:
            raise ValueError(f"Unknown metadata sheet: {sheet!r}")
        columns = SHEETS[sheet]
        values = {col: _clean(row.get(col, '')) for col in columns}
        if not values[columns[0]]:
            return
        with self._lock:
            sheets = self._load_sheets()
            df = sheets[sheet]
            exists = (df[columns] == pd.Series(values)).all(axis=1).any()
            if not exists:
                sheets[sheet] = pd.concat([df, pd.DataFrame([values])], ignore_index=True)
                self._save_sheets(sheets)
                logger.info("Updated metadata: %s <- %s", sheet, values)

    def rename_theme(self, old_name, new_name):
        """Rename a theme (and the parent of its sub-themes). Returns False if not found."""
        with self._lock:
            sheets = self._load_sheets()
            themes = sheets['themes']
            if not themes['theme'].eq(old_name).any():
                return False
            themes.loc[themes['theme'] == old_name, 'theme'] = new_name
            subs = sheets['sub_themes']
            subs.loc[subs['parentTheme'] == old_name, 'parentTheme'] = new_name
            self._save_sheets(sheets)
            return True

    def delete_theme(self, name):
        """Delete a theme together with its sub-themes."""
        with self._lock:
            sheets = self._load_sheets()
            sheets['themes'] = sheets['themes'][sheets['themes']['theme'] != name]
            sheets['sub_themes'] = sheets['sub_themes'][sheets['sub_themes']['parentTheme'] != name]
            self._save_sheets(sheets)

    def rename_subtheme(self, old_name, old_parent, new_name, new_parent):
        """Rename/move a sub-theme. Returns False if not found."""
        with self._lock:
            sheets = self._load_sheets()
            subs = sheets['sub_themes']
            mask = (subs['subTheme'] == old_name) & (subs['parentTheme'] == old_parent)
            if not mask.any():
                return False
            subs.loc[mask, ['subTheme', 'parentTheme']] = [new_name, new_parent]
            sheets['sub_themes'] = subs.drop_duplicates()
            self._save_sheets(sheets)
            return True

    def delete_subtheme(self, name, parent):
        with self._lock:
            sheets = self._load_sheets()
            subs = sheets['sub_themes']
            sheets['sub_themes'] = subs[~((subs['subTheme'] == name) & (subs['parentTheme'] == parent))]
            self._save_sheets(sheets)

"""Logging configuration shared by the whole application.

Two log files are written to the log folder:

* ``console_output.log`` - one line per message, streamed to the UI console.
  The UI colours each line by its ``[LEVEL]`` tag (INFO / WARN / ERROR / SUCCESS),
  so those level names are part of the UI contract. Lines logged while an
  execution runs also carry a ``[Step N]`` tag.
* ``errors.log`` - errors only, with full tracebacks, for troubleshooting.
* ``audit.log`` - security audit trail: who logged in, changed data, ran or downloaded what.

All files rotate at 10 MB and keep 10 backups.
"""

import logging
import os
import threading
from logging.handlers import RotatingFileHandler

SUCCESS = 25  # Between INFO (20) and WARNING (30)

DATE_FORMAT = '%Y-%m-%dT%H:%M:%S'
CONSOLE_FORMAT = '[%(asctime)s] [%(levelname)s] %(context)s%(message)s'
ERRORS_FORMAT = '[%(asctime)s] [%(levelname)s] %(context)s%(name)s: %(message)s'

AUDIT_FORMAT = '[%(asctime)s] %(message)s'

LOG_MAX_BYTES = 10 * 1024 * 1024
LOG_BACKUP_COUNT = 10

_context = threading.local()


def _rotating_file(path):
    return RotatingFileHandler(path, maxBytes=LOG_MAX_BYTES, backupCount=LOG_BACKUP_COUNT,
                               encoding='utf-8', delay=False)


def set_log_context(text):
    """Prefix every message logged by the current thread, e.g. '[Step 3] '."""
    _context.text = text


class _ContextFilter(logging.Filter):
    def filter(self, record):
        record.context = getattr(_context, 'text', '')
        return True


class _SingleLineFormatter(logging.Formatter):
    """One physical line per record and no tracebacks (those go to errors.log)."""

    def format(self, record):
        saved = record.exc_info, record.exc_text, record.stack_info
        record.exc_info = record.exc_text = record.stack_info = None
        try:
            text = super().format(record)
        finally:
            record.exc_info, record.exc_text, record.stack_info = saved
        return ' | '.join(line.strip() for line in text.splitlines() if line.strip())


def setup_logging(console_log_file):
    """Send application logs to stdout, the UI console file and errors.log.

    Safe to call more than once.
    """
    logging.addLevelName(SUCCESS, 'SUCCESS')
    logging.addLevelName(logging.WARNING, 'WARN')

    root = logging.getLogger()
    if getattr(root, '_eds_configured', False):
        return

    log_dir = os.path.dirname(console_log_file)
    os.makedirs(log_dir, exist_ok=True)

    console_file = _rotating_file(console_log_file)
    console_file.setFormatter(_SingleLineFormatter(CONSOLE_FORMAT, DATE_FORMAT))

    errors_file = _rotating_file(os.path.join(log_dir, 'errors.log'))
    errors_file.setLevel(logging.ERROR)
    errors_file.setFormatter(logging.Formatter(ERRORS_FORMAT, DATE_FORMAT))

    terminal = logging.StreamHandler()
    terminal.setFormatter(logging.Formatter(CONSOLE_FORMAT, DATE_FORMAT))

    for handler in (console_file, errors_file, terminal):
        handler.addFilter(_ContextFilter())
        root.addHandler(handler)
    root.setLevel(logging.INFO)
    root._eds_configured = True

    # Security audit trail (logins, data changes, executions, downloads)
    audit_file = _rotating_file(os.path.join(log_dir, 'audit.log'))
    audit_file.setFormatter(logging.Formatter(AUDIT_FORMAT, DATE_FORMAT))
    audit = logging.getLogger('audit')
    audit.addHandler(audit_file)
    audit.propagate = False

    # The UI polls the API every few hundred milliseconds; per-request access
    # logs would drown out the execution output.
    logging.getLogger('werkzeug').setLevel(logging.WARNING)

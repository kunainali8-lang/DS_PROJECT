###LIBRARY IMPORT
##################################################################################################################################################################################################
from data_exporter_tool import direct_execute 
from data_exporter_tool import table_creator 
from data_exporter_tool import table_dropper 
from data_exporter_tool import extract_with_checkpoints
from data_exporter_tool import create_table
from logger import Logger
import pandas as pd
import numpy as np
from datetime import datetime
import os
from openpyxl import load_workbook
from cohere_r7b import prepare_input_and_generate_summary_for_exceptions
import excel_util
from data_exporter_tool import direct_execute_to_df
from cohere_r7b import generate_paragraph
from docx import Document
from docx.shared import Pt
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
import win32com.client as win32

###functions
##################################################################################################################################################################################################
# Function to change font to Arial if it is Times New Roman
##---------------------------------------------------------
def change_font_to_arial(range):
    if range.Font.Name == 'Times New Roman':
        #print(f"Changing font for text: {range.Text}")
        range.Font.Name = 'Arial'


##to read branch file
##----------------------
def read_csv(file_path):
    try:
        df = pd.read_csv(file_path)
        return df
    except Exception as e:
        print(f"An error occurred: {e}")
        return None
    
##-------------------------
def print_log(text,logger):
    print('---',text,'---')
    logger.log(('---',text,'---'))


#change font from times new roman to arial
##--------------------------------
def change_font_in_docx(doc_path):
    # Get the absolute path of the document
    abs_doc_path = os.path.abspath(doc_path)
    
    # Open the Word application
    word = win32.Dispatch('Word.Application')
    word.Visible = False

    # Open the document
    try:
        doc = word.Documents.Open(abs_doc_path)
    except Exception as e:
        print(f"Error opening document: {e}")
        word.Quit()
        return


    # Change font in paragraphs
    for paragraph in doc.Paragraphs:
        change_font_to_arial(paragraph.Range)
    
    # Change font in tables
    for table in doc.Tables:
        try:
            for row in table.Rows:
                for cell in row.Cells:
                    try:
                        for paragraph in cell.Range.Paragraphs:
                            change_font_to_arial(paragraph.Range)
                    except Exception as e:
                        if 'vertically merged cells' in str(e):
                            print(f"Skipping cell due to vertically merged cells: {e}")
                        else:
                            print(f"Error processing cell: {e}")
        except Exception as e:
            print(f"Error processing cell: {e} thus ignoring tables with merged cells issue")
    
    # Save the modified document
    doc.Save()
    doc.Close()
    word.Quit()
    print(f"Document saved to {abs_doc_path}")



##main function to pick word report in each branch folder and prepare its final word report.
##------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
def prepare_final_audit_word_report(cohere_api_key, logger):
    """
    Iterates through all branch directories, reads all exceptions_report,
    prepares the word document using it

    Parameters:
    exceptions_file_path (str): The path to the exceptions CSV file.

    Returns:
    None
    """

    #download the tranche file data:
    tranche_data = direct_execute_to_df('select * from fccm_uat.iad_a100_trunch;')

    #download the tranche file data:
    branch_info_data = direct_execute_to_df('select * from fccm_uat.IAD_CA00_BRANCH;')
    
    #to be filled by branch information document
    business_region = ''
    audit_region = ''

    branch_code = ''
    branch_name = ''

    last_cut_off_date = ''
    cur_cut_off_date = ''

    branch_name = ''
    branch_code = ''

    themes_summary = ''

    year = '2025'

    # main directory of branch_data
    main_directory = 'branch_data'
    if not os.path.exists(main_directory): 
        print_log('No branch_data directory found.',logger)
        return

    # Iterate through each branch directory
    for branch_code in os.listdir(main_directory):
        branch_directory = os.path.join(main_directory, branch_code)
        if not os.path.isdir(branch_directory):
            continue

        # Initialize an empty DataFrame for the exceptions report
        exceptions_report = read_csv(f'./{main_directory}/{branch_code}/exceptions_report.csv')

        min_exception_report = exceptions_report[['Issue Description']]

        detailed_input = f"""
                    For below table: 
                    {min_exception_report.to_string(index=False)}

                    by using "Issue Description" column from above data, i want you to prepare a point based summary for each row. lets say
                    if there are 2 rows, then 2 points should be made. 
                        
                    make sure of following:
                    the output should not include starting and ending paragraphs like here is the requested summary etc because the answer with directly be pasted into a word document.
                    Each row based summary should not contain a heading in the start. 
                    Points should not be numbered as well.
                    Points should not contain any information related to risk ratings.
                    """

        themes_summary = generate_paragraph(detailed_input,cohere_api_key,'command-r-plus-04-2024',1000)
        branch_data = branch_info_data[branch_info_data['branch_code'] == branch_code]
        branch_name = branch_data['branch_name'].to_string(index=False)    
        business_region = branch_data['region'].to_string(index=False)

        audit_region = branch_data['hub'].to_string(index=False)
        branch_data_from_tranche = tranche_data[tranche_data['branch_code'] == branch_code]
        last_cut_off_date = '2022-01-01' #branch_data_from_tranche['last_cut_off_date'].to_string(index=False)
        cur_cut_off_date = '2025-01-30'  #branch_data_from_tranche['cur_cut_off_date'].to_string(index=False)


        replacements = {
            "{themes_summary}": themes_summary,
            "{branch_name}": branch_name,
            "{business_region}": business_region,
            "{audit_region}": audit_region,
            "{last_cut_off_date}": last_cut_off_date,
            "{cur_cut_off_date}": cur_cut_off_date,
            "{branch_code}": branch_code,
            "{year}": year
        }

        # File paths
        main_directory = "./docx_data"
        template_path = os.path.join(main_directory, "audit_report_demonstration.docx")
        output_directory = os.path.join(main_directory, branch_code)
        output_path = os.path.join(f'./branch_data/{branch_code}/', f"{branch_code}_audit_report.docx")

        doc = Document(template_path)

        print('generated summary:  ',replacements)

        # Replace variables in the document
        for paragraph in doc.paragraphs:
            for key, value in replacements.items():
                if key in paragraph.text:
                    paragraph.text = paragraph.text.replace(key, value)

            # Replace variables in tables
        for table in doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    for paragraph in cell.paragraphs:
                        for key, value in replacements.items():
                            if key in paragraph.text:
                                paragraph.text = paragraph.text.replace(key, value)
        
        # Replace variables in headers
        for section in doc.sections:
            header = section.header
            for paragraph in header.paragraphs:
                for key, value in replacements.items():
                    if key in paragraph.text:
                        paragraph.text = paragraph.text.replace(key, value)

        # Save the modified document
        doc.save(output_path)
        change_font_in_docx(output_path)
  

     


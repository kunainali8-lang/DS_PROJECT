# -*- coding: utf-8 -*-
"""
combined_report_generator.py
Generates a combined multi-sheet analytics Excel report.

Sheet order:
  00 – User Guide          (what every sheet contains, how to read it)
  01 – Combined Exceptions (raw aggregated table)
  02 – Branch User Count
  03 – Region Analytics
  04 – KRI Analytics
  05 – Branch Analytics    (includes normalised / per-user metrics)
  06 – High Risk KRI
  07 – Theme Analytics
  08 – Executive Dashboard (KPI tiles + insight tables)
  09 – Visual Dashboard    (all charts, bird's-eye view)
  10 – Exception Execution Log (status per exception: success / zero rows / error)
"""

import os
import math
import pandas as pd
import numpy as np
from datetime import datetime
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side, GradientFill
from openpyxl.chart import BarChart, PieChart, LineChart, Reference
from openpyxl.chart.series import DataPoint
from openpyxl.utils import get_column_letter
from openpyxl.utils.dataframe import dataframe_to_rows

# ─────────────────────────────────────────────────────────────────────────────
# COLOUR PALETTE
# ─────────────────────────────────────────────────────────────────────────────
C_NAVY        = "1F3864"
C_BLUE        = "2E75B6"
C_LIGHT_BLUE  = "D6E4F7"
C_TEAL        = "1F6B75"
C_RED         = "C00000"
C_AMBER       = "FF8C00"
C_GREEN       = "375623"
C_LIGHT_GREEN = "E2EFDA"
C_GOLD        = "C9A227"
C_PURPLE      = "7030A0"
C_ROW_ALT     = "EEF4FB"
C_WHITE       = "FFFFFF"
C_DARK_GREY   = "404040"
C_GUIDE_BG    = "FFF8E7"
C_GUIDE_HEAD  = "8B4513"

RISK_HEX = {"high": C_RED, "medium": C_AMBER, "low": C_GREEN}


# ─────────────────────────────────────────────────────────────────────────────
# STYLE HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _fill(c):   return PatternFill("solid", fgColor=c)
def _font(bold=False, color=C_WHITE, size=11, italic=False):
    return Font(bold=bold, color=color, size=size, name="Calibri", italic=italic)
def _align(h="center", v="center", wrap=False):
    return Alignment(horizontal=h, vertical=v, wrap_text=wrap)
def _border(s="thin"):
    x = Side(style=s)
    return Border(left=x, right=x, top=x, bottom=x)
def _risk_color(r):
    return RISK_HEX.get(str(r).strip().lower(), "808080")

def _title_block(ws, title, subtitle="", row=1):
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=16)
    c = ws.cell(row=row, column=1, value=title)
    c.font = Font(bold=True, color=C_WHITE, size=16, name="Calibri")
    c.fill = _fill(C_NAVY)
    c.alignment = _align()
    ws.row_dimensions[row].height = 36
    if subtitle:
        ws.merge_cells(start_row=row+1, start_column=1, end_row=row+1, end_column=16)
        c2 = ws.cell(row=row+1, column=1, value=subtitle)
        c2.font = Font(italic=True, color=C_DARK_GREY, size=10, name="Calibri")
        c2.fill = _fill(C_LIGHT_BLUE)
        c2.alignment = _align()
        return row + 2
    return row + 1

def _header_row(ws, r, headers, bg=C_BLUE, fc=C_WHITE, size=10):
    for ci, h in enumerate(headers, 1):
        c = ws.cell(row=r, column=ci, value=h)
        c.font = Font(bold=True, color=fc, size=size, name="Calibri")
        c.fill = _fill(bg)
        c.alignment = _align(h="center", wrap=True)
        c.border = _border()
    ws.row_dimensions[r].height = 28

def _data_row(ws, r, vals, alt=False, risk_ci=None):
    bg = C_ROW_ALT if alt else C_WHITE
    for ci, v in enumerate(vals, 1):
        c = ws.cell(row=r, column=ci, value=v)
        c.fill = _fill(bg)
        c.border = _border()
        c.alignment = _align(h="left", v="center", wrap=True)
        c.font = _font(color=C_DARK_GREY, size=9)
    if risk_ci and risk_ci <= len(vals):
        rc = _risk_color(vals[risk_ci - 1])
        ws.cell(row=r, column=risk_ci).font = Font(bold=True, color=rc, size=9, name="Calibri")

def _col_widths(ws, widths):
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w

def _section_label(ws, r, text, col_span=8, color=C_TEAL):
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=col_span)
    c = ws.cell(row=r, column=1, value=f"  ■  {text}")
    c.font = Font(bold=True, size=11, color=C_WHITE, name="Calibri")
    c.fill = _fill(color)
    c.alignment = _align(h="left")
    ws.row_dimensions[r].height = 22
    return r + 1


# ─────────────────────────────────────────────────────────────────────────────
# CHART HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _bar(ws, title, cats_ref, data_ref, anchor, w=22, h=13,
         x_title="", y_title="", style=10, horiz=False):
    ch = BarChart()
    ch.type = "bar" if horiz else "col"
    ch.title = title
    ch.style = style
    ch.y_axis.title = y_title
    ch.x_axis.title = x_title
    ch.grouping = "clustered"
    ch.width = w; ch.height = h
    ch.add_data(data_ref, titles_from_data=True)
    ch.set_categories(cats_ref)
    ws.add_chart(ch, anchor)
    return ch

def _stacked_bar(ws, title, cats_ref, data_refs, anchor, w=22, h=13, style=10):
    ch = BarChart()
    ch.type = "col"
    ch.grouping = "stacked"
    ch.overlap = 100
    ch.title = title
    ch.style = style
    ch.width = w; ch.height = h
    for dr in data_refs:
        ch.add_data(dr, titles_from_data=True)
    ch.set_categories(cats_ref)
    ws.add_chart(ch, anchor)
    return ch

def _pie(ws, title, cats_ref, data_ref, anchor, w=18, h=12, style=10):
    ch = PieChart()
    ch.title = title
    ch.style = style
    ch.width = w; ch.height = h
    ch.add_data(data_ref, titles_from_data=True)
    ch.set_categories(cats_ref)
    ws.add_chart(ch, anchor)
    return ch

def _line(ws, title, cats_ref, data_ref, anchor, w=22, h=12, style=10):
    ch = LineChart()
    ch.title = title
    ch.style = style
    ch.width = w; ch.height = h
    ch.add_data(data_ref, titles_from_data=True)
    ch.set_categories(cats_ref)
    ws.add_chart(ch, anchor)
    return ch

def _write_chart_data(ws, start_row, start_col, label_col_header,
                      value_col_header, rows_data):
    """Write a small label/value table for a chart and return (cats_ref, data_ref)."""
    r = start_row
    ws.cell(row=r, column=start_col, value=label_col_header)
    ws.cell(row=r, column=start_col+1, value=value_col_header)
    for i, (lbl, val) in enumerate(rows_data, 1):
        ws.cell(row=r+i, column=start_col, value=lbl)
        ws.cell(row=r+i, column=start_col+1, value=val)
    cats = Reference(ws, min_col=start_col,
                     min_row=r+1, max_row=r+len(rows_data))
    data = Reference(ws, min_col=start_col+1,
                     min_row=r, max_row=r+len(rows_data))
    return cats, data


# ─────────────────────────────────────────────────────────────────────────────
# DATA LOADING
# ─────────────────────────────────────────────────────────────────────────────

def load_combined_exceptions(downloads_dir):
    branch_data_dir = os.path.join(downloads_dir, "branch_data")
    records = []
    if not os.path.exists(branch_data_dir):
        return pd.DataFrame()
    for bf in os.listdir(branch_data_dir):
        bp = os.path.join(branch_data_dir, bf)
        if not os.path.isdir(bp):
            continue
        cp = os.path.join(bp, "exceptions_report.csv")
        if not os.path.exists(cp) or os.path.getsize(cp) == 0:
            continue
        try:
            df = pd.read_csv(cp)
            if not df.empty:
                records.append(df)
        except Exception:
            continue
    if not records:
        return pd.DataFrame()
    combined = pd.concat(records, ignore_index=True)
    col_map = {
        "exception_name":           "KRI Exception Name",
        "Sub - Theme Risk Rating":  "Theme Risk Rating",
        "Instances":                "Occurrences",
    }
    for o, n in col_map.items():
        if o in combined.columns and o != n:
            combined.rename(columns={o: n}, inplace=True)
    for col in ["KRI Exception Name","Branch Code","Branch Name","Audit Region",
                "Business Region","Issue Risk Rating","Theme Risk Rating",
                "Occurrences","Theme","Sub-Theme"]:
        if col not in combined.columns:
            combined[col] = ""
    combined["Occurrences"] = pd.to_numeric(combined["Occurrences"],
                                             errors="coerce").fillna(0).astype(int)
    for col in ["Issue Risk Rating","Theme Risk Rating"]:
        combined[col] = combined[col].astype(str).str.strip().str.title()
    return combined


def count_impacted_customers(downloads_dir):
    """
    Count unique impacted customers for each exception by reading grain data.
    
    Looks for customer identifier columns:
    - customer_no
    - customer_number
    - cust_no
    - ext_acct_num
    - external_account_number
    
    Returns: Dictionary mapping exception_name -> impacted_customer_count
    """
    customer_columns = [
        'customer_no', 'customer_number', 'cust_no', 
        'ext_acct_num', 'external_account_number'
    ]
    
    exception_customer_counts = {}
    
    # Check rules_based_exceptions folder for grain data
    rules_dir = os.path.join(downloads_dir, "rules_based_exceptions")
    
    if not os.path.exists(rules_dir):
        print("[WARN] rules_based_exceptions folder not found for customer counting")
        return exception_customer_counts
    
    for fname in os.listdir(rules_dir):
        if not fname.endswith(".csv"):
            continue
        
        # Extract exception name from filename (remove date suffix)
        exception_name = fname.split("_2025")[0].split("_2026")[0].strip()
        
        fpath = os.path.join(rules_dir, fname)
        
        try:
            # Check file size first
            if os.path.getsize(fpath) == 0:
                exception_customer_counts[exception_name] = 0
                continue
            
            # Read the CSV
            df = pd.read_csv(fpath)
            
            if df.empty:
                exception_customer_counts[exception_name] = 0
                continue
            
            # Normalize column names to lowercase for matching
            df.columns = df.columns.str.lower().str.strip()
            
            # Find which customer column exists in this dataset
            customer_col = None
            for col in customer_columns:
                if col in df.columns:
                    customer_col = col
                    break
            
            if customer_col:
                # Count unique customers (excluding nulls)
                unique_customers = df[customer_col].dropna().nunique()
                exception_customer_counts[exception_name] = unique_customers
                print(f"[INFO] {exception_name}: {unique_customers} unique customers found using '{customer_col}'")
            else:
                # No customer column found - use row count as fallback
                exception_customer_counts[exception_name] = len(df)
                print(f"[WARN] {exception_name}: No customer column found, using row count ({len(df)})")
                
        except Exception as e:
            print(f"[ERROR] Failed to count customers for {exception_name}: {str(e)}")
            exception_customer_counts[exception_name] = 0
    
    return exception_customer_counts


def add_impacted_customers_to_combined(combined_df, downloads_dir):
    """
    Add 'Impacted Customers' column to the combined exceptions dataframe.
    """
    if combined_df.empty:
        return combined_df
    
    # Get customer counts
    customer_counts = count_impacted_customers(downloads_dir)
    
    # Create a mapping function
    def get_customer_count(kri_name):
        kri_lower = str(kri_name).lower().strip()
        # Try exact match first
        if kri_lower in customer_counts:
            return customer_counts[kri_lower]
        # Try partial match
        for key, count in customer_counts.items():
            if kri_lower in key.lower() or key.lower() in kri_lower:
                return count
        return 0
    
    # Add the column
    combined_df['Impacted Customers'] = combined_df['KRI Exception Name'].apply(get_customer_count)
    
    return combined_df


def load_exception_execution_log(downloads_dir):
    """
    Load execution log from the JSON file created during exception execution.
    Falls back to file scanning if JSON log is not available.

    Returns DataFrame with columns:
      Exception Name, View Name, Output File, Status,
      Row Count, Error Detail, Notes
    """
    import csv as _csv
    import json

    # First, try to load from JSON execution log
    json_log_path = os.path.join(os.path.dirname(downloads_dir), "logs", "view_execution_log.json")
    # Also try relative paths
    for candidate in [json_log_path,
                      os.path.join("logs", "view_execution_log.json"),
                      "./logs/view_execution_log.json"]:
        if os.path.exists(candidate):
            json_log_path = candidate
            break
    
    execution_data = {}
    if os.path.exists(json_log_path):
        try:
            with open(json_log_path, 'r') as f:
                log_data = json.load(f)
                executions = log_data.get('executions', [])
                # Create a dict keyed by view_name for quick lookup
                for exec_entry in executions:
                    view_name = exec_entry.get('view_name', '').lower().strip()
                    parent = exec_entry.get('parent_exception', '').lower().strip()
                    # Use the most recent execution for each view
                    key = parent if parent else view_name
                    if key:
                        execution_data[key] = exec_entry
                print(f"[INFO] Loaded {len(executions)} execution entries from JSON log")
        except Exception as e:
            print(f"[WARN] Could not load JSON execution log: {e}")

    exc_csv = os.path.join(os.path.dirname(downloads_dir), "data", "exceptions_v2.csv")
    # also try relative paths
    for candidate in [exc_csv,
                       os.path.join("data","exceptions_v2.csv"),
                       "data/exceptions_v2.csv"]:
        if os.path.exists(candidate):
            exc_csv = candidate
            break

    all_exceptions = []
    if os.path.exists(exc_csv):
        try:
            df_exc = pd.read_csv(exc_csv)
            for _, row in df_exc.iterrows():
                all_exceptions.append({
                    "id": row.get("id",""),
                    "Exception Name": row.get("exceptionName", row.get("exception_name","")),
                    "Parent Exception": row.get("parentException", row.get("parent_exception","")),
                    "View Name": row.get("viewName", row.get("view_name","")),
                    "Theme": row.get("theme",""),
                    "Issue Risk Rating": row.get("issueRiskRating", row.get("Issue Risk Rating","")),
                })
        except Exception:
            pass

    # Scan rules_based_exceptions for CSVs (for row count verification)
    rules_dir = os.path.join(downloads_dir, "rules_based_exceptions")
    found_files = {}
    if os.path.exists(rules_dir):
        for fname in os.listdir(rules_dir):
            if fname.endswith(".csv"):
                fpath = os.path.join(rules_dir, fname)
                # Extract key from filename (remove date suffix)
                key = fname.split("_2025")[0].split("_2026")[0].lower().strip()
                try:
                    size = os.path.getsize(fpath)
                    if size == 0:
                        found_files[key] = (0, "File exists but 0 bytes")
                    else:
                        df_tmp = pd.read_csv(fpath)
                        found_files[key] = (len(df_tmp), "")
                except Exception as e:
                    found_files[key] = (0, str(e)[:120])

    # Scan branch_data for per-branch exception CSVs
    branch_data_dir = os.path.join(downloads_dir, "branch_data")
    branch_exc_counts = {}  # exception_name -> total rows across all branches
    if os.path.exists(branch_data_dir):
        for bf in os.listdir(branch_data_dir):
            bp = os.path.join(branch_data_dir, bf)
            if not os.path.isdir(bp):
                continue
            cp = os.path.join(bp, "exceptions_report.csv")
            if not os.path.exists(cp):
                continue
            try:
                df_br = pd.read_csv(cp)
                if "exception_name" in df_br.columns:
                    for exc_n, grp in df_br.groupby("exception_name"):
                        key = str(exc_n).lower().strip()
                        branch_exc_counts[key] = (branch_exc_counts.get(key,0)
                                                  + int(grp["Instances"].sum()
                                                         if "Instances" in grp.columns
                                                         else len(grp)))
            except Exception:
                pass

    # Build log rows
    rows = []
    for exc in all_exceptions:
        pname = str(exc.get("Parent Exception","")).strip()
        ename = str(exc.get("Exception Name","")).strip()
        vname = str(exc.get("View Name","")).strip()
        key_p = pname.lower()
        key_e = ename.lower()

        status = "Not Executed"
        row_count = 0
        error_detail = ""
        notes = ""
        timestamp = ""

        # First check JSON execution log for this exception
        exec_entry = None
        for key in [key_p, key_e]:
            if key in execution_data:
                exec_entry = execution_data[key]
                break
        
        if exec_entry:
            # We have execution data from JSON log
            timestamp = exec_entry.get('timestamp', '')
            exec_status = exec_entry.get('status', '').lower()
            error_msg = exec_entry.get('error_message', '')
            
            if exec_status == 'success':
                status = "Success"
                # Get actual row count from file
                for key in [key_p, key_e]:
                    if key in found_files:
                        row_count, err = found_files[key]
                        if err:
                            error_detail = err
                        break
                if row_count == 0:
                    status = "Zero Rows"
                    notes = "Query executed successfully but returned no matching records"
            elif exec_status == 'failed':
                status = "Failed"
                error_detail = error_msg if error_msg else "Execution failed"
        else:
            # No JSON log entry - check if file exists (legacy detection)
            for key in [key_p, key_e]:
                if key in found_files:
                    row_count, err = found_files[key]
                    if err:
                        status = "Read Error"
                        error_detail = err
                    elif row_count > 0:
                        status = "Success (file found)"
                        notes = "Detected from file system (no execution log)"
                    else:
                        status = "Zero Rows"
                        notes = "File exists but empty"
                    break

        # Check branch_data aggregated rows
        br_rows = 0
        for key in [key_p, key_e]:
            if key in branch_exc_counts:
                br_rows = branch_exc_counts[key]
                break

        if status == "Not Executed" and br_rows > 0:
            status = "Success (branch data found)"
            row_count = br_rows
            notes = "Found in branch data folders"

        rows.append({
            "ID": exc.get("id",""),
            "Exception Name": ename or pname,
            "Parent Exception": pname,
            "View Name": vname,
            "Theme": exc.get("Theme",""),
            "Risk Rating": str(exc.get("Issue Risk Rating","")).strip(),
            "Status": status,
            "Execution Time": timestamp,
            "Output Rows": row_count if row_count else (br_rows if br_rows else 0),
            "Branch Rows Total": br_rows,
            "Error Detail": error_detail,
            "Notes": notes,
        })

    return pd.DataFrame(rows)


def _build_exception_log(wb, exc_log_df):
    """Sheet 10 – Exception Execution Log."""
    ws = wb.create_sheet("Exception Execution Log")
    ws.sheet_view.showGridLines = False
    ws.freeze_panes = "A4"
    ts = datetime.now().strftime("%d %B %Y  %H:%M")

    total = len(exc_log_df)
    if not exc_log_df.empty:
        success  = (exc_log_df["Status"].str.contains("Success", case=False, na=False)).sum()
        zero_row = (exc_log_df["Status"].str.contains("Zero", case=False, na=False)).sum()
        missing  = (exc_log_df["Status"].str.contains("Missing|Not Executed", case=False, na=False)).sum()
        errors   = (exc_log_df["Status"].str.contains("Error", case=False, na=False)).sum()
    else:
        success = zero_row = missing = errors = 0

    nr = _title_block(ws,
        "Exception Execution Log",
        (f"Generated: {ts}  |  Total Exceptions: {total}  |  "
         f"Successful: {success}  |  Zero Rows: {zero_row}  |  "
         f"Missing/Not Run: {missing}  |  Errors: {errors}"))

    # KPI tiles
    kpis = [
        ("Total Exceptions", total,   C_BLUE),
        ("Successful",       success, C_GREEN),
        ("Zero Rows",        zero_row, C_AMBER),
        ("File Missing",     missing,  C_NAVY),
        ("Errors",           errors,   C_RED),
    ]
    for ci,(lbl,val,col) in enumerate(kpis, 1):
        lc = ws.cell(row=nr, column=ci, value=lbl)
        lc.font = Font(bold=True, size=9, color=C_WHITE, name="Calibri")
        lc.fill = _fill(col); lc.alignment = _align(wrap=True); lc.border = _border()
        ws.row_dimensions[nr].height = 24
        vc = ws.cell(row=nr+1, column=ci, value=val)
        vc.font = Font(bold=True, size=18, color=col, name="Calibri")
        vc.fill = _fill(C_WHITE); vc.alignment = _align(); vc.border = _border()
        ws.row_dimensions[nr+1].height = 36
    nr += 3

    if exc_log_df.empty:
        ws.cell(row=nr, column=1,
                value="No exception log data available. Run Step 1 first to generate exception output files.")
        return

    # Status colour map
    STATUS_BG = {
        "success":     "E2EFDA",
        "zero":        "FFF3CD",
        "error":       "FCE4D6",
        "missing":     "EDEDED",
        "not executed":"EDEDED",
    }

    def _status_bg(s):
        sl = str(s).lower()
        for k,v in STATUS_BG.items():
            if k in sl:
                return v
        return C_WHITE

    hdrs = ["ID","Exception Name","Parent Exception","View Name","Theme",
            "Risk Rating","Status","Execution Time","Output Rows","Branch Rows Total",
            "Error Detail","Notes"]
    _header_row(ws, nr, hdrs, bg=C_NAVY)
    nr += 1
    _col_widths(ws, [6,40,36,36,32,14,24,20,14,16,50,36])

    for i,(_, row) in enumerate(exc_log_df.iterrows()):
        bg = _status_bg(row["Status"])
        for ci,col_name in enumerate(hdrs, 1):
            val = row.get(col_name,"")
            cell = ws.cell(row=nr+i, column=ci, value=val)
            cell.fill = _fill(bg)
            cell.border = _border()
            cell.alignment = _align(h="left", v="center", wrap=True)
            cell.font = _font(color=C_DARK_GREY, size=9)
        # Bold risk rating (column 6)
        risk_cell = ws.cell(row=nr+i, column=6)
        rc = _risk_color(row.get("Risk Rating",""))
        risk_cell.font = Font(bold=True, color=rc, size=9, name="Calibri")
        # Bold status (column 7)
        st_cell = ws.cell(row=nr+i, column=7)
        st_lc = str(row["Status"]).lower()
        if "success" in st_lc:
            st_col = C_GREEN
        elif "zero" in st_lc:
            st_col = C_AMBER
        elif "error" in st_lc:
            st_col = C_RED
        else:
            st_col = C_DARK_GREY
        st_cell.font = Font(bold=True, color=st_col, size=9, name="Calibri")

    de = nr + len(exc_log_df) - 1
    ws.auto_filter.ref = f"A3:{get_column_letter(len(hdrs))}{de}"

    # Colour legend
    leg_r = de + 3
    ws.merge_cells(start_row=leg_r, start_column=1, end_row=leg_r, end_column=6)
    lc = ws.cell(row=leg_r, column=1, value="  LEGEND:")
    lc.font = Font(bold=True, size=10, color=C_WHITE, name="Calibri")
    lc.fill = _fill(C_NAVY); lc.alignment = _align(h="left"); lc.border = _border()
    legend_items = [
        ("Success",              "E2EFDA", C_GREEN,  "Exception ran and produced data rows"),
        ("Zero Rows",            "FFF3CD", C_AMBER,  "Exception ran but query returned 0 records"),
        ("File Missing/Not Run", "EDEDED", C_DARK_GREY, "CSV output not found — exception may not have run"),
        ("Read Error",           "FCE4D6", C_RED,    "File found but could not be read — check Error Detail column"),
    ]
    for j,(label,bg,fc,desc) in enumerate(legend_items):
        r = leg_r + 1 + j
        c1 = ws.cell(row=r, column=1, value=label)
        c1.font = Font(bold=True, size=9, color=fc, name="Calibri")
        c1.fill = _fill(bg); c1.border = _border()
        ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=6)
        c2 = ws.cell(row=r, column=2, value=desc)
        c2.font = _font(color=C_DARK_GREY, size=9)
        c2.fill = _fill(C_WHITE); c2.border = _border()
        c2.alignment = _align(h="left")


def load_branch_user_count(downloads_dir, data_exporter_tool=None):
    QUERY = """
    select source_branch, count(distinct external_account_number) as user_count
    from FCCM_UAT.iad_pp_04_1034_cust_master_panpak
    where source_branch in (select branch_code from FCCM_UAT.iad_a100_trunch)
    group by 1 order by 2 desc
    """
    cache = os.path.join(downloads_dir, "_branch_user_count_cache.csv")
    if data_exporter_tool is not None:
        try:
            # Only attempt live fetch if credentials file exists
            import os as _os
            creds_ok = _os.path.exists('./creds/data_lake_credentials.txt')
            if creds_ok:
                df = data_exporter_tool.direct_execute_to_df(QUERY)
                if df is not None and not df.empty:
                    df.columns = ["Branch Code","User Count"]
                    df.to_csv(cache, index=False)
                    return df
        except Exception:
            pass
    if os.path.exists(cache):
        try:
            df = pd.read_csv(cache)
            df.columns = ["Branch Code","User Count"]
            return df
        except Exception:
            pass
    return pd.DataFrame(columns=["Branch Code","User Count"])


def _enrich_with_users(exc_df, user_df):
    """
    Merge user counts into exc_df and compute normalised metrics.
    Returns enriched DataFrame with extra columns:
      User Count, Occurrences_per_1000_Users, Risk_Score
    Risk_Score: High=3, Medium=2, Low=1  (for weighted aggregations)
    """
    df = exc_df.copy()
    df["Branch Code"] = df["Branch Code"].astype(str).str.strip()

    if not user_df.empty:
        uf = user_df.copy()
        uf["Branch Code"] = uf["Branch Code"].astype(str).str.strip()
        uf["User Count"] = pd.to_numeric(uf["User Count"], errors="coerce")
        df = df.merge(uf, on="Branch Code", how="left")
    else:
        df["User Count"] = np.nan

    # Occurrences per 1,000 users  (size-normalised comparison metric)
    df["Occ_per_1k_Users"] = np.where(
        df["User Count"].notna() & (df["User Count"] > 0),
        (df["Occurrences"] / df["User Count"] * 1000).round(2),
        np.nan
    )

    # Risk score for weighted analysis
    risk_map = {"High": 3, "Medium": 2, "Low": 1}
    df["Risk_Score"] = df["Issue Risk Rating"].map(risk_map).fillna(1)
    # Weighted severity = occurrences × risk_score
    df["Weighted_Severity"] = df["Occurrences"] * df["Risk_Score"]

    # ── Severity as percentage (0-100%) ──────────────────────────────────────
    # Exception Rate % = (occurrences / user_count) × 100, capped at 100 %
    # This is the most intuitive metric: "what % of customers triggered this KRI"
    df["Exception_Rate_Pct"] = np.where(
        df["User Count"].notna() & (df["User Count"] > 0),
        ((df["Occurrences"] / df["User Count"]) * 100).clip(upper=100).round(2),
        np.nan
    )
    # Weighted Severity % = weighted_severity / (user_count × 3) × 100, capped at 100 %
    # Denominator = user_count × 3 (max possible score if every user has a High-risk exception)
    df["Weighted_Severity_Pct"] = np.where(
        df["User Count"].notna() & (df["User Count"] > 0),
        ((df["Weighted_Severity"] / (df["User Count"] * 3)) * 100).clip(upper=100).round(2),
        np.nan
    )

    return df


# ─────────────────────────────────────────────────────────────────────────────
# SHEET 00 – USER GUIDE
# ─────────────────────────────────────────────────────────────────────────────

def _build_guide(wb, exc_df, user_df):
    ws = wb.active
    ws.title = "User Guide"
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 28
    ws.column_dimensions["B"].width = 90

    ts = datetime.now().strftime("%d %B %Y  %H:%M")
    _title_block(ws, "Combined KRI Analytics Report — User Guide",
                 f"Report Generated: {ts}   |   Total Exception Records: {len(exc_df)}   |   Branches: {exc_df['Branch Code'].nunique() if not exc_df.empty else 0}")

    def _guide_section(r, title, items):
        # Section header
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=2)
        c = ws.cell(row=r, column=1, value=title)
        c.font = Font(bold=True, size=12, color=C_WHITE, name="Calibri")
        c.fill = _fill(C_GUIDE_HEAD)
        c.alignment = _align(h="left")
        ws.row_dimensions[r].height = 24
        r += 1
        for lbl, desc in items:
            c1 = ws.cell(row=r, column=1, value=lbl)
            c1.font = Font(bold=True, size=10, color=C_NAVY, name="Calibri")
            c1.fill = _fill(C_GUIDE_BG)
            c1.alignment = _align(h="left", v="top", wrap=True)
            c1.border = _border()
            c2 = ws.cell(row=r, column=2, value=desc)
            c2.font = Font(size=10, color=C_DARK_GREY, name="Calibri")
            c2.fill = _fill(C_WHITE)
            c2.alignment = _align(h="left", v="top", wrap=True)
            c2.border = _border()
            ws.row_dimensions[r].height = max(30, min(120, len(str(desc))//2))
            r += 1
        r += 1
        return r

    r = 3

    # ── About this report ─────────────────────────────────────────────────────
    r = _guide_section(r, "📋  ABOUT THIS REPORT", [
        ("Purpose",
         "This report consolidates all branch-wise KRI (Key Risk Indicator) exception data "
         "produced by the Exception Detection System (EDS). It aggregates per-branch "
         "exceptions_report.csv files into a single workbook and then layers multiple "
         "analytics views on top — regional, KRI-wise, branch-wise, thematic, and "
         "normalised comparisons — so that audit teams can identify patterns and take "
         "targeted action."),
        ("How to use",
         "Start with the Visual Dashboard sheet for a bird's-eye view of all key charts. "
         "Use the Executive Dashboard for headline KPIs and top-5 summaries. "
         "Drill into individual sheets (Region, KRI, Branch, Theme) for deep-dive tables. "
         "Always refer to size-normalised metrics when comparing branches of different sizes."),
        ("Data source",
         "Branch-wise exceptions_report.csv files generated by EDS Steps 1–3.  "
         "Branch user counts come from the query: "
         "SELECT source_branch, COUNT(DISTINCT external_account_number) "
         "FROM FCCM_UAT.iad_pp_04_1034_cust_master_panpak ... (cached in "
         "_branch_user_count_cache.csv)."),
    ])

    # ── Sheet directory ───────────────────────────────────────────────────────
    r = _guide_section(r, "📑  SHEET DIRECTORY", [
        ("01 · Combined Exceptions",
         "The master data table. Every row is one KRI exception occurrence at one branch. "
         "Columns: KRI Exception Name, Branch Code, Branch Name, Audit Region, "
         "Business Region, Issue Risk Rating, Theme Risk Rating, Occurrences, Theme, Sub-Theme. "
         "Auto-filter is enabled. Use this sheet as the source of truth."),
        ("02 · Branch User Count",
         "Lists every branch alongside its total distinct user (customer) count fetched from "
         "the core banking system. This is the branch 'size' denominator used throughout the "
         "normalised analytics. If the DB was not reachable, user count shows N/A."),
        ("03 · Region Analytics",
         "Aggregates exceptions by Audit Region and Business Region. Shows total exceptions, "
         "total occurrences, unique KRIs triggered, unique branches affected, and "
         "average occurrences per branch. Includes bar charts for quick visual comparison."),
        ("04 · KRI Analytics",
         "One row per unique KRI. Ranked by total occurrences descending. Shows how many "
         "branches each KRI affected, the average occurrences per branch, risk ratings, "
         "and a top-10 bar chart. Use this sheet to identify which KRIs are systemic vs isolated."),
        ("05 · Branch Analytics",
         "One row per branch. Columns include raw occurrence counts AND size-normalised metrics: "
         "'Occ per 1,000 Users' and 'Weighted Severity Score' (occurrences × risk weight). "
         "IMPORTANT: Always use normalised columns when comparing branches of different sizes — "
         "a large-city branch naturally has more absolute occurrences than a village branch. "
         "The normalised rate makes fair apples-to-apples comparison possible."),
        ("06 · High Risk KRI Analysis",
         "Filters only 'High' issue risk rating exceptions. Shows KRIs sorted by total "
         "occurrences and lists which branches they appeared in. Intended for escalation "
         "and remediation planning."),
        ("07 · Theme Analytics",
         "Groups exceptions by audit Theme and Sub-Theme. Useful for understanding whether "
         "issues are concentrated in a particular compliance area (e.g. KYC, AML, etc)."),
        ("08 · Executive Dashboard",
         "A single-screen summary for senior management. Contains 7 KPI tiles (total records, "
         "occurrences, unique KRIs, branches affected, high/medium risk counts, total users), "
         "top-5 tables, risk distribution, and key auto-generated insight bullets."),
        ("09 · Visual Dashboard",
         "ALL meaningful charts on a single sheet for a complete bird's-eye view. "
         "10 charts in a clean 2-column, 5-row grid covering: risk profile, top KRIs, "
         "region comparisons (raw and normalised %), branch comparisons (normalised %), "
         "weighted severity %, theme breakdown, stacked risk by region, and high-risk KRI ranking. "
         "Charts marked (✓) use percentage metrics (0-100%) for fair cross-branch comparison."),
        ("10 · Exception Execution Log",
         "A full log of every exception in the system showing its execution status. "
         "Columns: ID, Exception Name, View Name, Theme, Risk Rating, Status, Output Rows, Error Detail, Notes. "
         "Status values: Success (green) = ran and produced data; "
         "Zero Rows (amber) = ran but found no matching records — review the SQL view logic; "
         "File Missing (grey) = CSV not found, exception may not have been selected or Step 1 not run; "
         "Read Error (red) = file exists but could not be parsed. "
         "Use this sheet to quickly identify which of the 46 KRIs are not generating data and why."),
    ])

    # ── Key metrics explained ─────────────────────────────────────────────────
    r = _guide_section(r, "📐  KEY METRICS & FORMULAS", [
        ("Occurrences",
         "Raw count of records flagged by that KRI at that branch during the audit period. "
         "This is an ABSOLUTE number — do NOT compare across branches of very different sizes."),
        ("Exception Rate %",
         "= (Occurrences / Branch User Count) × 100, capped at 100%.  "
         "Answers: What % of this branch's customers triggered exceptions?  "
         "This SIZE-NORMALISED rate allows fair comparison between a Karachi Main Branch "
         "with 10,000 customers and a village branch with 200 customers. "
         "Example: 50 occurrences at a 200-user branch = 25% rate.  "
         "Same 50 occurrences at a 10,000-user branch = only 0.5% rate."),
        ("Weighted Severity Score",
         "= Occurrences x Risk Weight, where High=3, Medium=2, Low=1.  "
         "This combines frequency AND severity into a single raw score so that a few High-risk "
         "occurrences correctly outweigh many Low-risk occurrences."),
        ("Weighted Severity %",
         "= (Weighted Severity Score / (User Count x 3)) x 100, capped at 100%.  "
         "Denominator = User Count x 3 (the maximum possible score if every customer had a High-risk exception).  "
         "Scales to 0-100% so all branches are directly comparable regardless of size.  "
         "100% = catastrophic (all users flagged High-risk).  Below 5% = well-controlled."),
        ("Issue Risk Rating",
         "Set at the KRI level (High / Medium / Low). Reflects the potential regulatory, "
         "financial, or reputational impact if the exception is not remediated."),
        ("Theme Risk Rating",
         "Risk rating at the Sub-Theme (audit category) level, set by the audit team. "
         "May differ from Issue Risk Rating if individual KRIs within a theme vary."),
    ])

    # ── How to compare branches fairly ────────────────────────────────────────
    r = _guide_section(r, "⚖️  HOW TO COMPARE BRANCHES FAIRLY", [
        ("The size problem",
         "A branch in central Karachi may serve 15,000 customers while a branch in a rural "
         "district serves 300. If we compare raw occurrences, Karachi will always appear worse "
         "— not because it is less compliant, but simply because it processes far more "
         "transactions. This makes raw counts misleading for management decisions."),
        ("Recommended approach",
         "1. Use 'Exception Rate %' (column L in Branch Analytics) for frequency comparisons — "
         "it shows what % of the branch customer base triggered exceptions. "
         "2. Use 'Weighted Severity %' (column M) for combined frequency+risk comparisons — "
         "this is the single best metric to rank branches fairly. "
         "3. In the Visual Dashboard, charts marked (✓) already use these percentage metrics. "
         "4. Never rank branches solely on 'Total Occurrences' (column G) — large branches will "
         "always score higher simply because they have more customers."),
        ("Interpreting outliers",
         "A branch with a very HIGH normalised rate needs urgent attention — it has more "
         "exceptions relative to its customer base than peers. A branch with a HIGH raw count "
         "but LOW normalised rate may simply be large; review absolute numbers but do not "
         "penalise it vs smaller branches on the same KPI target."),
        ("Minimum user count threshold",
         "Branches with fewer than 50 users are flagged in the Branch Analytics sheet. "
         "Normalised rates for very small branches can be volatile (a single exception = "
         "a very high rate) and should be interpreted with caution."),
    ])

    # ── Risk rating legend ────────────────────────────────────────────────────
    r = _guide_section(r, "🚦  RISK RATING LEGEND", [
        ("HIGH  (Red)",   "Serious regulatory or financial exposure. Immediate escalation and remediation required. Monitored at senior management level."),
        ("MEDIUM  (Amber)", "Moderate risk. Remediation plan required within agreed timeline. Reviewed at branch manager level."),
        ("LOW  (Green)",  "Minor deviation. Note for record; rectify in next review cycle."),
    ])
    # Colour the risk rows
    risk_colour_rows = [(r-4, C_RED), (r-3, C_AMBER), (r-2, C_GREEN)]
    for rrow, rcol in risk_colour_rows:
        c = ws.cell(row=rrow, column=1)
        c.font = Font(bold=True, size=10, color=C_WHITE, name="Calibri")
        c.fill = _fill(rcol)


# ─────────────────────────────────────────────────────────────────────────────
# SHEET 01 – COMBINED EXCEPTIONS
# ─────────────────────────────────────────────────────────────────────────────

def _build_sheet1(wb, exc_df):
    ws = wb.create_sheet("Combined Exceptions")
    ws.sheet_view.showGridLines = False
    ws.freeze_panes = "A4"
    nr = _title_block(ws,
        "Combined KRI Exceptions — Master Data Table",
        f"All branches aggregated  |  {len(exc_df)} total records  |  "
        f"Filter any column using the dropdown arrows")
    headers = ["KRI Exception Name","Branch Code","Branch Name",
               "Audit Region","Business Region",
               "Issue Risk Rating","Theme Risk Rating","Occurrences",
               "Impacted Customers","Theme","Sub-Theme"]
    _header_row(ws, nr, headers, bg=C_BLUE)
    nr += 1
    _col_widths(ws, [44,13,28,20,20,18,18,13,18,32,32])
    for i,(_, row) in enumerate(exc_df.iterrows()):
        _data_row(ws, nr+i, [
            row.get("KRI Exception Name",""), row.get("Branch Code",""),
            row.get("Branch Name",""),        row.get("Audit Region",""),
            row.get("Business Region",""),    row.get("Issue Risk Rating",""),
            row.get("Theme Risk Rating",""),  row.get("Occurrences",0),
            row.get("Impacted Customers",0),
            row.get("Theme",""),              row.get("Sub-Theme",""),
        ], alt=(i%2==1), risk_ci=6)
    ws.auto_filter.ref = f"A3:{get_column_letter(len(headers))}{nr+len(exc_df)-1}"


# ─────────────────────────────────────────────────────────────────────────────
# SHEET 02 – BRANCH USER COUNT
# ─────────────────────────────────────────────────────────────────────────────

def _build_sheet2(wb, user_df, exc_df):
    ws = wb.create_sheet("Branch User Count")
    ws.sheet_view.showGridLines = False
    ws.freeze_panes = "A4"
    nr = _title_block(ws, "Branch-wise Total User Count",
                      "Source: SELECT source_branch, COUNT(DISTINCT external_account_number) "
                      "FROM FCCM_UAT.iad_pp_04_1034_cust_master_panpak ... "
                      "| Used as denominator for size-normalised metrics throughout this report")
    bm = pd.DataFrame()
    if not exc_df.empty:
        bm = exc_df[["Branch Code","Branch Name","Audit Region","Business Region"]]\
               .drop_duplicates("Branch Code").copy()
        bm["Branch Code"] = bm["Branch Code"].astype(str).str.strip()
    if not user_df.empty:
        uf = user_df.copy()
        uf["Branch Code"] = uf["Branch Code"].astype(str).str.strip()
        merged = uf.merge(bm, on="Branch Code", how="left") if not bm.empty else uf.copy()
    else:
        merged = bm.copy() if not bm.empty else pd.DataFrame()
        if not merged.empty:
            merged["User Count"] = "N/A"
    for col in ["Branch Code","Branch Name","Audit Region","Business Region","User Count"]:
        if col not in merged.columns:
            merged[col] = "N/A"
    headers = ["Branch Code","Branch Name","Audit Region","Business Region",
               "Total Users","Size Category"]
    _header_row(ws, nr, headers, bg=C_BLUE)
    nr += 1
    _col_widths(ws, [13,30,20,22,14,16])
    for i,(_, row) in enumerate(merged.iterrows()):
        uc = row.get("User Count","N/A")
        try: uc = int(float(uc))
        except: uc = "N/A"
        if isinstance(uc, int):
            size_cat = "Large (>5k)" if uc > 5000 else ("Medium (1k-5k)" if uc >= 1000 else "Small (<1k)")
        else:
            size_cat = "N/A"
        _data_row(ws, nr+i, [
            row.get("Branch Code",""), row.get("Branch Name",""),
            row.get("Audit Region",""), row.get("Business Region",""), uc, size_cat
        ], alt=(i%2==1))
    ws.auto_filter.ref = f"A3:{get_column_letter(len(headers))}{nr+len(merged)-1}"


# ─────────────────────────────────────────────────────────────────────────────
# SHEET 03 – REGION ANALYTICS
# ─────────────────────────────────────────────────────────────────────────────

def _build_sheet3(wb, edf):
    ws = wb.create_sheet("Region Analytics")
    ws.sheet_view.showGridLines = False
    nr = _title_block(ws, "Region-wise Analytics",
                      "Audit Region and Business Region breakdown of exceptions and occurrences")
    if edf.empty:
        ws.cell(row=nr, column=1, value="No data available"); return
    _col_widths(ws, [28,18,20,16,18,22,20,20])

    # Pre-build region -> total_users map for percentage calculation
    has_uc = "User Count" in edf.columns and edf["User Count"].notna().any()
    if has_uc:
        br_uc_map = (edf[["Branch Code","User Count"]]
                     .drop_duplicates("Branch Code")
                     .set_index("Branch Code")["User Count"]
                     .apply(lambda x: pd.to_numeric(x, errors="coerce")))

    def _region_block(df, group_col, title, color, start_r):
        by = (df.groupby(group_col)
                .agg(Exc_Count=("KRI Exception Name","count"),
                     Total_Occ=("Occurrences","sum"),
                     Unique_KRIs=("KRI Exception Name","nunique"),
                     Unique_Br=("Branch Code","nunique"),
                     High_Risk=("Issue Risk Rating", lambda x:(x.str.lower()=="high").sum()),
                     Weighted_Sev=("Weighted_Severity","sum"))
                .reset_index()
                .sort_values("Total_Occ", ascending=False))
        # Compute Severity % at region level using actual user totals
        if has_uc:
            def _reg_users(region_val):
                br_in_region = df[df[group_col]==region_val]["Branch Code"].unique()
                return br_uc_map.reindex(br_in_region).sum()
            by["Region_Users"] = by[group_col].apply(_reg_users)
            by["Severity_Pct"] = np.where(
                by["Region_Users"] > 0,
                ((by["Weighted_Sev"] / (by["Region_Users"] * 3)) * 100).clip(upper=100).round(2),
                np.nan)
        else:
            by["Severity_Pct"] = np.nan

        start_r = _section_label(ws, start_r, title, col_span=8, color=color)
        hdrs = [group_col,"Exception Count","Total Occurrences","Unique KRIs",
                "Unique Branches","High-Risk Count","Exception Rate %","Weighted Severity %"]
        _header_row(ws, start_r, hdrs, bg=color)
        start_r += 1
        ds = start_r
        for i,(_, r) in enumerate(by.iterrows()):
            sp = r["Severity_Pct"]
            # Exception Rate % = Total_Occ / Region_Users * 100
            if has_uc:
                ru = r.get("Region_Users", 0)
                er = round((r["Total_Occ"] / ru * 100), 2) if ru > 0 else "N/A"
                sp = "N/A" if pd.isna(sp) else f"{sp}%"
            else:
                er = "N/A"; sp = "N/A"
            _data_row(ws, start_r+i, [
                r[group_col], r["Exc_Count"], r["Total_Occ"],
                r["Unique_KRIs"], r["Unique_Br"], r["High_Risk"],
                f"{er}%" if isinstance(er, float) else er, sp
            ], alt=(i%2==1))
        de = start_r + len(by) - 1
        start_r = de + 2
        # chart
        cats = Reference(ws, min_col=1, min_row=ds, max_row=de)
        d1 = Reference(ws, min_col=3, min_row=ds-1, max_row=de)
        _bar(ws, f"Occurrences by {group_col}", cats, d1,
             f"J{ds-1}", w=22, h=12)
        return start_r, by, ds, de

    nr, by_audit, ds_a, de_a = _region_block(edf, "Audit Region",
        "By Audit Region", C_TEAL, nr)
    nr, by_biz, ds_b, de_b = _region_block(edf, "Business Region",
        "By Business Region", C_NAVY, nr)

    # High-risk by region
    hr = edf[edf["Issue Risk Rating"].str.lower()=="high"]
    if not hr.empty:
        hrg = (hr.groupby("Audit Region")
                 .agg(HR_Count=("KRI Exception Name","count"),
                      HR_Occ=("Occurrences","sum"))
                 .reset_index().sort_values("HR_Occ", ascending=False))
        nr = _section_label(ws, nr, "High-Risk Exceptions by Audit Region",
                            col_span=4, color=C_RED)
        _header_row(ws, nr,
                    ["Audit Region","High-Risk Exception Count","High-Risk Occurrences"],
                    bg=C_RED)
        nr += 1
        for i,(_, r) in enumerate(hrg.iterrows()):
            _data_row(ws, nr+i,
                      [r["Audit Region"], int(r["HR_Count"]), int(r["HR_Occ"])],
                      alt=(i%2==1))


# ─────────────────────────────────────────────────────────────────────────────
# SHEET 04 – KRI ANALYTICS
# ─────────────────────────────────────────────────────────────────────────────

def _build_sheet4(wb, edf):
    ws = wb.create_sheet("KRI Analytics")
    ws.sheet_view.showGridLines = False
    ws.freeze_panes = "A4"
    nr = _title_block(ws, "KRI-wise Analytics",
                      "All KRIs ranked by total occurrences. "
                      "Severity % and Highest-Impacted Branch use normalised metrics for fair comparison.")
    if edf.empty:
        ws.cell(row=nr, column=1, value="No data"); return

    has_uc = "User Count" in edf.columns and edf["User Count"].notna().any()
    has_ic = "Impacted Customers" in edf.columns

    by_kri = (edf.groupby(["KRI Exception Name","Issue Risk Rating",
                            "Theme Risk Rating","Theme","Sub-Theme"])
               .agg(Total_Occ=("Occurrences","sum"),
                    Affected_Br=("Branch Code","nunique"),
                    Avg_Occ=("Occurrences","mean"),
                    Weighted_Sev=("Weighted_Severity","sum"),
                    Impacted_Cust=("Impacted Customers","sum") if has_ic else ("Occurrences", lambda x: 0))
               .reset_index()
               .sort_values("Total_Occ", ascending=False))
    by_kri["Avg_Occ"] = by_kri["Avg_Occ"].round(1)
    if has_ic:
        by_kri["Impacted_Cust"] = by_kri["Impacted_Cust"].fillna(0).astype(int)

    # ── Severity % per KRI: (weighted_score / sum_of_max_possible) × 100 ────
    # max_possible for each branch-KRI row = user_count × risk_weight (already in Weighted_Severity)
    # max_possible denominator = user_count × 3 (worst case all users flagged High)
    if has_uc:
        br_uc = (edf[["Branch Code","User Count"]]
                 .drop_duplicates("Branch Code")
                 .assign(**{"User Count": lambda d: pd.to_numeric(d["User Count"], errors="coerce")}))
        # total users per KRI (sum of unique branch users that have this KRI)
        def _kri_severity_pct(kri_name):
            rows = edf[edf["KRI Exception Name"] == kri_name]
            br_list = rows["Branch Code"].unique()
            total_users = (br_uc[br_uc["Branch Code"].isin(br_list)]["User Count"]
                           .fillna(0).sum())
            ws_sum = rows["Weighted_Severity"].sum()
            if total_users > 0:
                return round((ws_sum / (total_users * 3)) * 100, 2)
            return np.nan

        by_kri["Severity_Pct"] = by_kri["KRI Exception Name"].apply(_kri_severity_pct)

        # ── Highest-Impacted Branch % per KRI ────────────────────────────────
        # For each KRI, find the branch with highest Exception Rate %
        # = (KRI occurrences at branch / branch_user_count) × 100
        def _highest_impacted_branch(kri_name):
            rows = edf[edf["KRI Exception Name"] == kri_name].copy()
            rows = rows.merge(br_uc[["Branch Code","User Count"]], on="Branch Code", how="left",
                              suffixes=("","_uc"))
            uc_col = "User Count_uc" if "User Count_uc" in rows.columns else "User Count"
            rows["uc"] = pd.to_numeric(rows[uc_col], errors="coerce")
            rows["exc_rate"] = np.where(
                rows["uc"] > 0, (rows["Occurrences"] / rows["uc"] * 100).clip(upper=100), np.nan)
            rows = rows.dropna(subset=["exc_rate"])
            if rows.empty:
                return "N/A", "N/A"
            best = rows.loc[rows["exc_rate"].idxmax()]
            return str(best.get("Branch Name", best["Branch Code"])), f"{round(best['exc_rate'],2)}%"

        himp = by_kri["KRI Exception Name"].apply(
            lambda k: pd.Series(_highest_impacted_branch(k),
                                 index=["Highest Impact Branch","Impact Rate %"]))
        by_kri = pd.concat([by_kri, himp], axis=1)
    else:
        by_kri["Severity_Pct"] = np.nan
        by_kri["Highest Impact Branch"] = "N/A (no user data)"
        by_kri["Impact Rate %"] = "N/A"

    hdrs = ["KRI Exception Name","Theme","Sub-Theme","Issue Risk Rating",
            "Theme Risk Rating","Total Occurrences","Impacted Customers","Affected Branches",
            "Avg Occ/Branch","Severity %","Highest Impact Branch","Impact Rate %"]
    _header_row(ws, nr, hdrs, bg=C_BLUE)
    nr += 1
    ds = nr
    _col_widths(ws, [44,30,32,18,18,16,18,16,14,12,30,14])
    for i,(_, r) in enumerate(by_kri.iterrows()):
        sp = r.get("Severity_Pct", np.nan)
        sp_str = "N/A" if pd.isna(sp) else f"{sp}%"
        _data_row(ws, nr+i, [
            r["KRI Exception Name"], r["Theme"], r["Sub-Theme"],
            r["Issue Risk Rating"], r["Theme Risk Rating"],
            int(r["Total_Occ"]), int(r.get("Impacted_Cust", 0)), int(r["Affected_Br"]),
            r["Avg_Occ"], sp_str,
            r.get("Highest Impact Branch","N/A"), r.get("Impact Rate %","N/A")
        ], alt=(i%2==1), risk_ci=4)
    de = nr + len(by_kri) - 1
    ws.auto_filter.ref = f"A3:{get_column_letter(len(hdrs))}{de}"

    # top-10 chart (by Severity % if available, else raw occurrences)
    if has_uc and by_kri["Severity_Pct"].notna().any():
        t10 = by_kri.dropna(subset=["Severity_Pct"]).nlargest(10,"Severity_Pct")
        chart_col_hdr = "Severity %"
        chart_title = "Top 10 KRIs by Severity % (normalised)"
        chart_y = "Severity %"
        chart_data_vals = [(str(r["KRI Exception Name"])[:42], round(float(r["Severity_Pct"]),2))
                           for _,r in t10.iterrows()]
    else:
        t10 = by_kri.head(10)
        chart_title = "Top 10 KRIs by Total Occurrences"
        chart_y = "Occurrences"
        chart_data_vals = [(str(r["KRI Exception Name"])[:42], int(r["Total_Occ"]))
                           for _,r in t10.iterrows()]
    cr = de + 3
    ws.cell(row=cr-1, column=1, value="KRI"); ws.cell(row=cr-1, column=2, value=chart_y)
    for i,(lbl,val) in enumerate(chart_data_vals):
        ws.cell(row=cr+i, column=1, value=lbl)
        ws.cell(row=cr+i, column=2, value=val)
    cats = Reference(ws, min_col=1, min_row=cr, max_row=cr+len(chart_data_vals)-1)
    data = Reference(ws, min_col=2, min_row=cr-1, max_row=cr+len(chart_data_vals)-1)
    _bar(ws, chart_title, cats, data,
         f"L{ds}", w=26, h=15, y_title=chart_y, x_title="KRI")


# ─────────────────────────────────────────────────────────────────────────────
# SHEET 05 – BRANCH ANALYTICS  (normalised metrics)
# ─────────────────────────────────────────────────────────────────────────────

def _build_sheet5(wb, edf, user_df):
    ws = wb.create_sheet("Branch Analytics")
    ws.sheet_view.showGridLines = False
    ws.freeze_panes = "A4"
    subtitle = ("Includes SIZE-NORMALISED metrics (per 1,000 users) for fair branch comparison. "
                "Sort by 'Occ per 1k Users' or 'Norm Weighted Severity' to rank branches fairly "
                "regardless of their customer base size.")
    nr = _title_block(ws, "Branch-wise Analytics (Raw + Normalised)", subtitle)
    if edf.empty:
        ws.cell(row=nr, column=1, value="No data"); return

    by_br = (edf.groupby(["Branch Code","Branch Name","Audit Region","Business Region"])
               .agg(Exc_Count=("KRI Exception Name","count"),
                    Total_Occ=("Occurrences","sum"),
                    Unique_KRIs=("KRI Exception Name","nunique"),
                    High_Risk=("Issue Risk Rating", lambda x:(x.str.lower()=="high").sum()),
                    Med_Risk=("Issue Risk Rating",  lambda x:(x.str.lower()=="medium").sum()),
                    Weighted_Sev=("Weighted_Severity","sum"),
                    Impacted_Cust=("Impacted Customers","sum") if "Impacted Customers" in edf.columns else ("Occurrences", lambda x: 0))
               .reset_index()
               .sort_values("Total_Occ", ascending=False))
    
    if "Impacted Customers" in edf.columns:
        by_br["Impacted_Cust"] = by_br["Impacted_Cust"].fillna(0).astype(int)

    # merge user count
    if not user_df.empty:
        uf = user_df.copy()
        uf["Branch Code"] = uf["Branch Code"].astype(str).str.strip()
        by_br["Branch Code"] = by_br["Branch Code"].astype(str).str.strip()
        by_br = by_br.merge(uf, on="Branch Code", how="left")
        by_br["User Count"] = pd.to_numeric(by_br["User Count"], errors="coerce")
    else:
        by_br["User Count"] = np.nan

    by_br["Exc_Rate_Pct"] = np.where(
        by_br["User Count"].notna() & (by_br["User Count"] > 0),
        ((by_br["Total_Occ"] / by_br["User Count"]) * 100).clip(upper=100).round(2), np.nan)
    by_br["WS_Pct"] = np.where(
        by_br["User Count"].notna() & (by_br["User Count"] > 0),
        ((by_br["Weighted_Sev"] / (by_br["User Count"] * 3)) * 100).clip(upper=100).round(2), np.nan)
    by_br["Size_Cat"] = by_br["User Count"].apply(
        lambda u: "Large (>5k)" if (pd.notna(u) and u > 5000)
        else ("Medium (1k-5k)" if (pd.notna(u) and u >= 1000) else
              ("Small (<1k)" if pd.notna(u) else "N/A")))
    by_br["Flag"] = by_br["User Count"].apply(
        lambda u: "⚠ Very Small Branch" if (pd.notna(u) and u < 50) else "")

    hdrs = ["Branch Code","Branch Name","Audit Region","Business Region",
            "Size Category","Exception Count","Total Occurrences","Impacted Customers",
            "Unique KRIs","High Risk","Medium Risk",
            "User Count","Exception Rate %","Weighted Severity %","Flag"]
    _header_row(ws, nr, hdrs, bg=C_BLUE)
    nr += 1
    ds = nr
    _col_widths(ws, [13,28,20,20,16,15,17,18,13,11,13,12,17,20,20])
    for i,(_, r) in enumerate(by_br.iterrows()):
        uc    = r["User Count"]
        er    = r["Exc_Rate_Pct"]
        ws_p  = r["WS_Pct"]
        uc    = "N/A" if pd.isna(uc)  else int(uc)
        er    = "N/A" if pd.isna(er)  else f"{round(float(er),2)}%"
        ws_p  = "N/A" if pd.isna(ws_p) else f"{round(float(ws_p),2)}%"
        _data_row(ws, nr+i, [
            r["Branch Code"], r["Branch Name"], r["Audit Region"], r["Business Region"],
            r["Size_Cat"], int(r["Exc_Count"]), int(r["Total_Occ"]), int(r.get("Impacted_Cust", 0)),
            int(r["Unique_KRIs"]), int(r["High_Risk"]), int(r["Med_Risk"]),
            uc, er, ws_p, r["Flag"]
        ], alt=(i%2==1))
    de = nr + len(by_br) - 1
    ws.auto_filter.ref = f"A3:{get_column_letter(len(hdrs))}{de}"

    # Note box
    note_r = de + 2
    ws.merge_cells(start_row=note_r, start_column=1, end_row=note_r+4, end_column=10)
    note_text = (
        "IMPORTANT NOTE ON BRANCH COMPARISONS:\n\n"
        "Exception Rate % = (Occurrences / User Count) x 100. "
        "Shows what % of the branch customers triggered exceptions. "
        "Use this for fair size-adjusted comparisons across branches.\n"
        "Weighted Severity % = (Weighted Score / Max Possible Score) x 100, capped at 100%. "
        "Risk weights: High=3, Medium=2, Low=1. Max possible = all users flagged as High risk. "
        "Best single metric to rank branch compliance risk fairly.\n"
        "Flag: Branches with fewer than 50 users - rates may be volatile due to small sample."
    )
    nc = ws.cell(row=note_r, column=1, value=note_text)
    nc.font = Font(size=9, color=C_NAVY, name="Calibri", italic=True)
    nc.fill = _fill("FFF3CD")
    nc.alignment = _align(h="left", v="top", wrap=True)
    nc.border = _border()


# ─────────────────────────────────────────────────────────────────────────────
# SHEET 06 – HIGH RISK KRI
# ─────────────────────────────────────────────────────────────────────────────

def _build_sheet6(wb, edf):
    ws = wb.create_sheet("High Risk KRI Analysis")
    ws.sheet_view.showGridLines = False
    nr = _title_block(ws, "High-Risk KRI Deep-Dive",
                      "All exceptions with Issue Risk Rating = HIGH — for escalation and remediation planning")
    if edf.empty:
        ws.cell(row=nr, column=1, value="No data"); return
    high = edf[edf["Issue Risk Rating"].str.strip().str.lower()=="high"].copy()
    if high.empty:
        ws.cell(row=nr, column=1, value="No High-Risk exceptions found"); return
    _col_widths(ws, [44,18,18,38,38,18,18])

    # KRI summary
    summary = (high.groupby("KRI Exception Name")
                   .agg(Total_Occ=("Occurrences","sum"),
                        Affected_Br=("Branch Code","nunique"),
                        Regions=("Audit Region", lambda x:", ".join(sorted(x.unique()))),
                        Biz_Regions=("Business Region", lambda x:", ".join(sorted(x.unique()))),
                        Avg_Occ_per_Br=("Occurrences","mean"),
                        Norm_W_Sev=("Weighted_Severity","sum"))
                   .reset_index()
                   .sort_values("Total_Occ", ascending=False))
    summary["Avg_Occ_per_Br"] = summary["Avg_Occ_per_Br"].round(1)

    nr = _section_label(ws, nr, "High-Risk KRI Summary", col_span=7, color=C_RED)
    _header_row(ws, nr,
                ["KRI Exception Name","Total Occurrences","Affected Branches",
                 "Audit Regions","Business Regions","Avg Occ/Branch","Weighted Severity"],
                bg=C_RED)
    nr += 1
    ds = nr
    for i,(_, r) in enumerate(summary.iterrows()):
        _data_row(ws, nr+i, [
            r["KRI Exception Name"], int(r["Total_Occ"]), int(r["Affected_Br"]),
            r["Regions"], r["Biz_Regions"], r["Avg_Occ_per_Br"], int(r["Norm_W_Sev"])
        ], alt=(i%2==1))
    de = nr + len(summary) - 1
    nr = de + 3

    # chart
    cr = de + 3
    ws.cell(row=cr-1, column=1, value="KRI"); ws.cell(row=cr-1, column=2, value="Occurrences")
    for i,(_, r) in enumerate(summary.head(12).iterrows()):
        ws.cell(row=cr+i, column=1, value=str(r["KRI Exception Name"])[:42])
        ws.cell(row=cr+i, column=2, value=int(r["Total_Occ"]))
    cats = Reference(ws, min_col=1, min_row=cr, max_row=cr+min(len(summary),12)-1)
    data = Reference(ws, min_col=2, min_row=cr-1, max_row=cr+min(len(summary),12)-1)
    _bar(ws, "High-Risk KRIs by Total Occurrences", cats, data,
         f"I{ds}", w=26, h=14)

    # Per-KRI branch detail
    nr = _section_label(ws, cr+len(summary)+3, "High-Risk KRI — Branch Breakdown",
                        col_span=6, color=C_RED)
    _header_row(ws, nr,
                ["KRI Exception Name","Branch Code","Branch Name",
                 "Audit Region","Business Region","Occurrences"], bg=C_RED)
    nr += 1
    det = high.sort_values(["KRI Exception Name","Occurrences"], ascending=[True,False])
    for i,(_, r) in enumerate(det.iterrows()):
        _data_row(ws, nr+i, [
            r["KRI Exception Name"], r["Branch Code"], r["Branch Name"],
            r["Audit Region"], r["Business Region"], r["Occurrences"]
        ], alt=(i%2==1))


# ─────────────────────────────────────────────────────────────────────────────
# SHEET 07 – THEME ANALYTICS
# ─────────────────────────────────────────────────────────────────────────────

def _build_sheet7(wb, edf):
    ws = wb.create_sheet("Theme Analytics")
    ws.sheet_view.showGridLines = False
    nr = _title_block(ws, "Theme & Sub-Theme Analytics",
                      "Exception distribution across audit themes — identifies compliance area hotspots")
    if edf.empty:
        ws.cell(row=nr, column=1, value="No data"); return
    _col_widths(ws, [32,34,18,18,18,18,18])

    by_theme = (edf.groupby("Theme")
                   .agg(Exc_Count=("KRI Exception Name","count"),
                        Total_Occ=("Occurrences","sum"),
                        Unique_KRIs=("KRI Exception Name","nunique"),
                        Unique_Br=("Branch Code","nunique"),
                        High_Risk=("Issue Risk Rating", lambda x:(x.str.lower()=="high").sum()),
                        W_Sev=("Weighted_Severity","sum"))
                   .reset_index().sort_values("Total_Occ", ascending=False))
    nr = _section_label(ws, nr, "Theme-level Summary", col_span=7, color=C_NAVY)
    _header_row(ws, nr,
                ["Theme","Exception Count","Total Occurrences","Unique KRIs",
                 "Unique Branches","High-Risk Count","Weighted Severity"], bg=C_NAVY)
    nr += 1; ds = nr
    for i,(_, r) in enumerate(by_theme.iterrows()):
        _data_row(ws, nr+i, [
            r["Theme"], int(r["Exc_Count"]), int(r["Total_Occ"]),
            int(r["Unique_KRIs"]), int(r["Unique_Br"]),
            int(r["High_Risk"]), int(r["W_Sev"])
        ], alt=(i%2==1))
    de = nr + len(by_theme) - 1; nr = de + 3
    # pie chart
    cr = nr
    ws.cell(row=cr-1, column=1, value="Theme"); ws.cell(row=cr-1, column=2, value="Occurrences")
    for i,(_, r) in enumerate(by_theme.iterrows()):
        ws.cell(row=cr+i, column=1, value=str(r["Theme"])[:35])
        ws.cell(row=cr+i, column=2, value=int(r["Total_Occ"]))
    cats = Reference(ws, min_col=1, min_row=cr, max_row=cr+len(by_theme)-1)
    data = Reference(ws, min_col=2, min_row=cr-1, max_row=cr+len(by_theme)-1)
    _pie(ws, "Exception Occurrences by Theme", cats, data, f"I{ds}", w=20, h=13)
    nr = cr + len(by_theme) + 3

    by_sub = (edf.groupby(["Theme","Sub-Theme"])
                 .agg(Exc_Count=("KRI Exception Name","count"),
                      Total_Occ=("Occurrences","sum"),
                      Unique_KRIs=("KRI Exception Name","nunique"),
                      High_Risk=("Issue Risk Rating", lambda x:(x.str.lower()=="high").sum()),
                      W_Sev=("Weighted_Severity","sum"))
                 .reset_index().sort_values("Total_Occ", ascending=False))
    nr = _section_label(ws, nr, "Sub-Theme-level Summary", col_span=7, color=C_TEAL)
    _header_row(ws, nr,
                ["Theme","Sub-Theme","Exception Count","Total Occurrences",
                 "Unique KRIs","High-Risk Count","Weighted Severity"], bg=C_TEAL)
    nr += 1
    for i,(_, r) in enumerate(by_sub.iterrows()):
        _data_row(ws, nr+i, [
            r["Theme"], r["Sub-Theme"], int(r["Exc_Count"]),
            int(r["Total_Occ"]), int(r["Unique_KRIs"]),
            int(r["High_Risk"]), int(r["W_Sev"])
        ], alt=(i%2==1))


# ─────────────────────────────────────────────────────────────────────────────
# SHEET 08 – EXECUTIVE DASHBOARD
# ─────────────────────────────────────────────────────────────────────────────

def _build_sheet8(wb, edf, user_df):
    ws = wb.create_sheet("Executive Dashboard")
    ws.sheet_view.showGridLines = False
    ts = datetime.now().strftime("%d %B %Y  %H:%M")
    nr = _title_block(ws, "Executive Dashboard — Exception Analytics Summary",
                      f"Report Date: {ts}")
    if edf.empty:
        ws.cell(row=nr, column=1, value="No data"); return
    _col_widths(ws, [20,20,20,20,20,20,20,20])

    total_exc   = len(edf)
    total_occ   = int(edf["Occurrences"].sum())
    unique_kris = edf["KRI Exception Name"].nunique()
    unique_br   = edf["Branch Code"].nunique()
    high_cnt    = int((edf["Issue Risk Rating"].str.lower()=="high").sum())
    med_cnt     = int((edf["Issue Risk Rating"].str.lower()=="medium").sum())
    total_users = int(user_df["User Count"].sum()) if not user_df.empty else "N/A"
    top_kri     = edf.groupby("KRI Exception Name")["Occurrences"].sum().idxmax()
    top_region  = edf.groupby("Audit Region")["Occurrences"].sum().idxmax()

    kpis = [
        ("Total Exception Records", total_exc,   C_BLUE),
        ("Total Occurrences",        total_occ,  C_TEAL),
        ("Unique KRIs Triggered",    unique_kris, C_NAVY),
        ("Branches Affected",        unique_br,  C_TEAL),
        ("High-Risk Exceptions",     high_cnt,   C_RED),
        ("Medium-Risk Exceptions",   med_cnt,    C_AMBER),
        ("Total Branch Users",       total_users, C_GREEN),
    ]
    sect = ws.cell(row=nr, column=1, value="  ■  Key Performance Indicators")
    sect.font = Font(bold=True, size=13, color=C_WHITE, name="Calibri")
    sect.fill = _fill(C_NAVY)
    ws.merge_cells(start_row=nr, start_column=1, end_row=nr, end_column=8)
    ws.row_dimensions[nr].height = 24
    nr += 1
    for ci,(lbl,val,col) in enumerate(kpis, 1):
        lc = ws.cell(row=nr, column=ci, value=lbl)
        lc.font = Font(bold=True, size=9, color=C_WHITE, name="Calibri")
        lc.fill = _fill(col); lc.alignment = _align(wrap=True); lc.border = _border()
        ws.row_dimensions[nr].height = 28
        vc = ws.cell(row=nr+1, column=ci, value=val)
        vc.font = Font(bold=True, size=18, color=col, name="Calibri")
        vc.fill = _fill(C_WHITE); vc.alignment = _align(); vc.border = _border()
        ws.row_dimensions[nr+1].height = 38
    nr += 3

    def _mini(start_r, start_c, title, hdrs, rows, tc=C_BLUE):
        c = ws.cell(row=start_r, column=start_c, value=title)
        c.font = Font(bold=True, size=10, color=C_WHITE, name="Calibri")
        c.fill = _fill(tc)
        ws.merge_cells(start_row=start_r, start_column=start_c,
                       end_row=start_r, end_column=start_c+len(hdrs)-1)
        for ci2,h in enumerate(hdrs, start_c):
            hc = ws.cell(row=start_r+1, column=ci2, value=h)
            hc.font = Font(bold=True, color=C_WHITE, size=9, name="Calibri")
            hc.fill = _fill(tc); hc.border = _border(); hc.alignment = _align(wrap=True)
        for ri,rv in enumerate(rows):
            for ci2,v in enumerate(rv, start_c):
                dc = ws.cell(row=start_r+2+ri, column=ci2, value=v)
                dc.fill = _fill(C_ROW_ALT if ri%2==1 else C_WHITE)
                dc.border = _border()
                dc.font = _font(color=C_DARK_GREY, size=9)
                dc.alignment = _align(h="left")

    t5k = edf.groupby("KRI Exception Name")["Occurrences"].sum().nlargest(5).reset_index()
    _mini(nr, 1, "Top 5 KRIs by Occurrences",
          ["KRI Name","Occurrences"],
          [[str(r["KRI Exception Name"])[:40], int(r["Occurrences"])] for _,r in t5k.iterrows()])
    t5b = edf.groupby(["Branch Code","Branch Name"])["Occurrences"].sum().nlargest(5).reset_index()
    _mini(nr, 4, "Top 5 Branches by Raw Occurrences",
          ["Branch","Name","Occurrences"],
          [[str(r["Branch Code"]), str(r["Branch Name"])[:18], int(r["Occurrences"])]
           for _,r in t5b.iterrows()])
    nr += 10

    rd = edf.groupby("Issue Risk Rating")["Occurrences"].sum().reset_index()
    _mini(nr, 1, "Risk Distribution",
          ["Risk Rating","Total Occurrences"],
          [[str(r["Issue Risk Rating"]), int(r["Occurrences"])] for _,r in rd.iterrows()],
          tc=C_RED)
    trg = edf.groupby("Audit Region")["Occurrences"].sum().nlargest(5).reset_index()
    _mini(nr, 4, "Top 5 Audit Regions",
          ["Region","Occurrences"],
          [[str(r["Audit Region"]), int(r["Occurrences"])] for _,r in trg.iterrows()],
          tc=C_TEAL)
    nr += 10

    insights = [
        f"▶  Most flagged KRI:  {top_kri}",
        f"▶  Most flagged Audit Region:  {top_region}",
        f"▶  High-Risk exceptions:  {high_cnt} ({round(high_cnt/max(total_exc,1)*100,1)}% of all records)",
        f"▶  Average occurrences per branch (raw):  {round(total_occ/max(unique_br,1),1)}",
        f"▶  Total weighted severity score:  {int(edf['Weighted_Severity'].sum())}  "
        f"(High×3 + Medium×2 + Low×1)",
    ]
    ic = ws.cell(row=nr, column=1, value="  ■  Auto-Generated Key Insights")
    ic.font = Font(bold=True, size=12, color=C_WHITE, name="Calibri")
    ic.fill = _fill(C_GOLD)
    ws.merge_cells(start_row=nr, start_column=1, end_row=nr, end_column=8)
    nr += 1
    for ins in insights:
        c = ws.cell(row=nr, column=1, value=ins)
        c.font = Font(size=10, name="Calibri", color=C_DARK_GREY)
        c.alignment = _align(h="left")
        c.fill = _fill("FFFEF0")
        ws.merge_cells(start_row=nr, start_column=1, end_row=nr, end_column=8)
        ws.row_dimensions[nr].height = 18
        nr += 1


# ─────────────────────────────────────────────────────────────────────────────
# SHEET 09 – VISUAL DASHBOARD  (all meaningful charts on one sheet)
# ─────────────────────────────────────────────────────────────────────────────

def _build_visual_dashboard(wb, edf, user_df):
    """
    All charts on one sheet, non-overlapping 2-column grid layout.
    Chart size: w=18, h=11.  Row spacing = 18 rows between chart bands.
    Left column anchor = B, Right column anchor = L.
    Band rows: 3, 21, 39, 57, 75  (5 bands x 2 = 10 charts total)
    Staging data starts at column T (col 20).
    """
    ws = wb.create_sheet("Visual Dashboard")
    ws.sheet_view.showGridLines = False
    ts = datetime.now().strftime("%d %B %Y  %H:%M")
    _title_block(ws, "Visual Dashboard — Bird's-Eye View of All Key Analytics",
                 f"Generated: {ts}  |  Charts marked (✓) use percentage metrics (0-100%) for fair branch/region comparison")
    # Set chart column widths so both columns fit cleanly
    _col_widths(ws, [1]+[8.5]*10+[1]+[8.5]*10+[2]*2+[20,15]*10)
    CW, CH = 18, 11        # chart width / height in cm
    LEFT  = "B"            # left chart column
    RIGHT = "L"            # right chart column
    ROWS  = [3,21,39,57,75]  # band starting rows (18-row gap = ~11cm each)

    if edf.empty:
        ws.cell(row=3, column=1, value="No data available to chart")
        return

    # ── Staging area helpers (data written at col 20+, invisible to reader) ──
    SC = 20  # staging start column
    _stg_rows = {}  # tracks next free row per staging column

    def stage(rows_data, header1, header2, offset_col=0):
        col = SC + offset_col
        used = _stg_rows.get(col, 3)
        ws.cell(row=used, column=col, value=header1)
        ws.cell(row=used, column=col+1, value=header2)
        for i,(lbl,val) in enumerate(rows_data, 1):
            ws.cell(row=used+i, column=col, value=lbl)
            ws.cell(row=used+i, column=col+1, value=val)
        cats = Reference(ws, min_col=col, min_row=used+1, max_row=used+len(rows_data))
        data = Reference(ws, min_col=col+1, min_row=used, max_row=used+len(rows_data))
        _stg_rows[col] = used + len(rows_data) + 2
        _stg_rows[col+1] = _stg_rows[col]
        return cats, data

    def stage_multi(rows_data, headers, offset_col=0):
        col = SC + offset_col
        used = _stg_rows.get(col, 3)
        for ci, h in enumerate(headers):
            ws.cell(row=used, column=col+ci, value=h)
        for ri, row_vals in enumerate(rows_data, 1):
            for ci, v in enumerate(row_vals):
                ws.cell(row=used+ri, column=col+ci, value=v)
        cats = Reference(ws, min_col=col, min_row=used+1, max_row=used+len(rows_data))
        data_refs = [
            Reference(ws, min_col=col+ci, min_row=used, max_row=used+len(rows_data))
            for ci in range(1, len(headers))
        ]
        next_r = used + len(rows_data) + 2
        for ci in range(len(headers)):
            _stg_rows[col+ci] = next_r
        return cats, data_refs

    # ── Merge user counts for normalised metrics ──────────────────────────────
    has_users = not user_df.empty
    if has_users:
        uf = user_df.copy()
        uf["Branch Code"] = uf["Branch Code"].astype(str).str.strip()
        uf["User Count"] = pd.to_numeric(uf["User Count"], errors="coerce")
        br_users = uf.set_index("Branch Code")["User Count"].to_dict()
    else:
        br_users = {}

    # Region user totals
    if has_users:
        reg_uf = edf[["Branch Code","Audit Region"]].drop_duplicates("Branch Code").copy()
        reg_uf["Branch Code"] = reg_uf["Branch Code"].astype(str).str.strip()
        reg_uf["User Count"] = reg_uf["Branch Code"].map(br_users)
        reg_users = reg_uf.groupby("Audit Region")["User Count"].sum()
    else:
        reg_users = pd.Series(dtype=float)

    bnames = edf[["Branch Code","Branch Name"]].drop_duplicates("Branch Code").copy()
    bnames["Branch Code"] = bnames["Branch Code"].astype(str).str.strip()

    # ── CHART 1 (row ROWS[0], LEFT): Risk Distribution Pie ───────────────────
    rd = edf.groupby("Issue Risk Rating")["Occurrences"].sum().reset_index()
    cats1, data1 = stage(
        [(str(r["Issue Risk Rating"]), int(r["Occurrences"])) for _,r in rd.iterrows()],
        "Risk Rating", "Occurrences", offset_col=0)
    _pie(ws, "1: Risk Profile — share by Risk Rating", cats1, data1,
         f"{LEFT}{ROWS[0]}", w=CW, h=CH)

    # ── CHART 2 (row ROWS[0], RIGHT): Top 10 KRIs – Raw Occurrences ──────────
    t10k = edf.groupby("KRI Exception Name")["Occurrences"].sum().nlargest(10).reset_index()
    cats2, data2 = stage(
        [(str(r["KRI Exception Name"])[:35], int(r["Occurrences"])) for _,r in t10k.iterrows()],
        "KRI", "Occurrences", offset_col=4)
    _bar(ws, "2: Top 10 KRIs — Total Occurrences",
         cats2, data2, f"{RIGHT}{ROWS[0]}", w=CW, h=CH, y_title="Occurrences")

    # ── CHART 3 (row ROWS[1], LEFT): Occurrences by Audit Region – RAW ───────
    by_reg = edf.groupby("Audit Region")["Occurrences"].sum().reset_index()
    cats3, data3 = stage(
        [(str(r["Audit Region"]), int(r["Occurrences"])) for _,r in by_reg.iterrows()],
        "Region", "Occurrences", offset_col=8)
    _bar(ws, "3: Occurrences by Audit Region  (⚠ Raw — not size-adjusted)",
         cats3, data3, f"{LEFT}{ROWS[1]}", w=CW, h=CH, y_title="Occurrences")

    # ── CHART 4 (row ROWS[1], RIGHT): Exception Rate % by Region ─────────────
    if has_users and not reg_users.empty:
        norm_reg = by_reg.copy()
        norm_reg["Region_Users"] = norm_reg["Audit Region"].map(reg_users)
        norm_reg["Exc_Rate_Pct"] = np.where(
            norm_reg["Region_Users"] > 0,
            ((norm_reg["Occurrences"] / norm_reg["Region_Users"]) * 100).clip(upper=100).round(2),
            np.nan)
        norm_reg = norm_reg.dropna(subset=["Exc_Rate_Pct"]).sort_values("Exc_Rate_Pct", ascending=False)
        cats4, data4 = stage(
            [(str(r["Audit Region"]), float(r["Exc_Rate_Pct"])) for _,r in norm_reg.iterrows()],
            "Region", "Exception Rate %", offset_col=12)
        _bar(ws, "4: Exception Rate % by Region  (✓ Size-Normalised, max 100%)",
             cats4, data4, f"{RIGHT}{ROWS[1]}", w=CW, h=CH,
             y_title="Exception Rate %")
    else:
        ws.cell(row=ROWS[1], column=12,
                value="Chart 4: Region normalised — No user count data available")

    # ── CHART 5 (row ROWS[2], LEFT): Top 15 Branches – RAW occurrences ───────
    t15b = (edf.groupby(["Branch Code","Branch Name"])["Occurrences"]
              .sum().nlargest(15).reset_index())
    t15b["Label"] = t15b["Branch Code"].astype(str) + " " + t15b["Branch Name"].str[:10]
    cats5, data5 = stage(
        [(str(r["Label"]), int(r["Occurrences"])) for _,r in t15b.iterrows()],
        "Branch", "Occurrences", offset_col=0)
    _bar(ws, "5: Top 15 Branches — Raw Occurrences  (⚠ Not size-adjusted)",
         cats5, data5, f"{LEFT}{ROWS[2]}", w=CW, h=CH, y_title="Occurrences")

    # ── CHART 6 (row ROWS[2], RIGHT): Top 15 Branches – Exception Rate % ─────
    br_occ = edf.groupby("Branch Code")["Occurrences"].sum().reset_index()
    br_occ["Branch Code"] = br_occ["Branch Code"].astype(str).str.strip()
    if has_users:
        br_occ["User Count"] = br_occ["Branch Code"].map(br_users)
        br_occ["Exc_Rate_Pct"] = np.where(
            br_occ["User Count"].notna() & (br_occ["User Count"] > 0),
            ((br_occ["Occurrences"] / br_occ["User Count"]) * 100).clip(upper=100).round(2),
            np.nan)
        br_occ = (br_occ.dropna(subset=["Exc_Rate_Pct"])
                  .sort_values("Exc_Rate_Pct", ascending=False).head(15))
        br_occ = br_occ.merge(bnames, on="Branch Code", how="left")
        br_occ["Label"] = br_occ["Branch Code"] + " " + br_occ["Branch Name"].str[:10].fillna("")
        cats6, data6 = stage(
            [(str(r["Label"]), float(r["Exc_Rate_Pct"])) for _,r in br_occ.iterrows()],
            "Branch", "Exception Rate %", offset_col=4)
        _bar(ws, "6: Top 15 Branches — Exception Rate %  (✓ Size-Normalised, max 100%)",
             cats6, data6, f"{RIGHT}{ROWS[2]}", w=CW, h=CH,
             y_title="Exception Rate %")
    else:
        ws.cell(row=ROWS[2], column=12,
                value="Chart 6: Branch normalised — No user count data available")

    # ── CHART 7 (row ROWS[3], LEFT): Weighted Severity % by Branch ───────────
    br_wsev = edf.groupby("Branch Code")["Weighted_Severity"].sum().reset_index()
    br_wsev["Branch Code"] = br_wsev["Branch Code"].astype(str).str.strip()
    if has_users:
        br_wsev["User Count"] = br_wsev["Branch Code"].map(br_users)
        br_wsev["WS_Pct"] = np.where(
            br_wsev["User Count"].notna() & (br_wsev["User Count"] > 0),
            ((br_wsev["Weighted_Severity"] / (br_wsev["User Count"] * 3)) * 100)
            .clip(upper=100).round(2), np.nan)
        br_wsev = (br_wsev.dropna(subset=["WS_Pct"])
                   .sort_values("WS_Pct", ascending=False).head(15))
        br_wsev = br_wsev.merge(bnames, on="Branch Code", how="left")
        br_wsev["Label"] = br_wsev["Branch Code"] + " " + br_wsev["Branch Name"].str[:10].fillna("")
        cats7, data7 = stage(
            [(str(r["Label"]), float(r["WS_Pct"])) for _,r in br_wsev.iterrows()],
            "Branch", "Weighted Severity %", offset_col=8)
        _bar(ws, "7: Top 15 Branches — Weighted Severity %  (✓ Best Risk Rank, max 100%)",
             cats7, data7, f"{LEFT}{ROWS[3]}", w=CW, h=CH,
             y_title="Weighted Severity %")
    else:
        br_wsev_raw = br_wsev.sort_values("Weighted_Severity", ascending=False).head(15)
        cats7b, data7b = stage(
            [(str(r["Branch Code"]), int(r["Weighted_Severity"])) for _,r in br_wsev_raw.iterrows()],
            "Branch", "Weighted Severity", offset_col=8)
        _bar(ws, "7: Top 15 Branches — Weighted Severity (Raw, no user data)",
             cats7b, data7b, f"{LEFT}{ROWS[3]}", w=CW, h=CH,
             y_title="Weighted Severity Score")

    # ── CHART 8 (row ROWS[3], RIGHT): Theme Breakdown Pie ────────────────────
    th = edf.groupby("Theme")["Occurrences"].sum().reset_index()
    cats8, data8 = stage(
        [(str(r["Theme"])[:28], int(r["Occurrences"])) for _,r in th.iterrows()],
        "Theme", "Occurrences", offset_col=12)
    _pie(ws, "8: Occurrences by Audit Theme",
         cats8, data8, f"{RIGHT}{ROWS[3]}", w=CW, h=CH)

    # ── CHART 9 (row ROWS[4], LEFT): Stacked Risk Profile by Audit Region ────
    stk = (edf.groupby(["Audit Region","Issue Risk Rating"])["Occurrences"]
             .sum().unstack(fill_value=0).reset_index())
    for rc in ["High","Medium","Low"]:
        if rc not in stk.columns:
            stk[rc] = 0
    stk = stk.sort_values("High", ascending=False)
    stk_rows = [(str(r["Audit Region"]), int(r.get("High",0)),
                 int(r.get("Medium",0)), int(r.get("Low",0))) for _,r in stk.iterrows()]
    cats9, data_refs9 = stage_multi(stk_rows, ["Region","High","Medium","Low"], offset_col=0)
    ch9 = BarChart()
    ch9.type = "col"; ch9.grouping = "stacked"; ch9.overlap = 100
    ch9.title = "9: Stacked Risk Profile by Audit Region"
    ch9.style = 10; ch9.width = CW; ch9.height = CH
    ch9.y_axis.title = "Occurrences"
    for dr in data_refs9:
        ch9.add_data(dr, titles_from_data=True)
    ch9.set_categories(cats9)
    ws.add_chart(ch9, f"{LEFT}{ROWS[4]}")

    # ── CHART 10 (row ROWS[4], RIGHT): Top 10 High-Risk KRIs ─────────────────
    high_only = edf[edf["Issue Risk Rating"].str.lower()=="high"]
    if not high_only.empty:
        t10hr = (high_only.groupby("KRI Exception Name")["Occurrences"]
                 .sum().nlargest(10).reset_index())
        cats10, data10 = stage_multi(
            [(str(r["KRI Exception Name"])[:33], int(r["Occurrences"]), int(r["Occurrences"])*3)
             for _,r in t10hr.iterrows()],
            ["KRI","Occurrences","Weighted (x3)"], offset_col=4)
        ch10 = BarChart()
        ch10.type = "col"; ch10.grouping = "clustered"
        ch10.title = "10: High-Risk KRIs — Occurrences vs Weighted Score"
        ch10.style = 10; ch10.width = CW; ch10.height = CH
        ch10.y_axis.title = "Count / Score"
        for dr in data10:
            ch10.add_data(dr, titles_from_data=True)
        ch10.set_categories(cats10)
        ws.add_chart(ch10, f"{RIGHT}{ROWS[4]}")

    # ── Reading guide strip ───────────────────────────────────────────────────
    guide_row = ROWS[4] + CH + 3
    ws.merge_cells(start_row=guide_row, start_column=1,
                   end_row=guide_row, end_column=22)
    gc = ws.cell(row=guide_row, column=1, value=(
        "  CHART READING GUIDE:  "
        "(⚠) = RAW counts — large branches always score higher, do NOT compare across branches directly.  "
        "(✓) = PERCENTAGE (0-100%) — safe to compare any branch or region.  "
        "Exception Rate % = occurrences / user count x 100.  "
        "Weighted Severity % = weighted score / (user count x 3) x 100  (High=3x, Medium=2x, Low=1x).  "
        "100% = worst possible (all customers flagged as High-risk)."
    ))
    gc.font = Font(size=9, italic=True, color=C_WHITE, name="Calibri")
    gc.fill = _fill(C_NAVY)
    gc.alignment = _align(h="left")
    gc.border = _border()
    ws.row_dimensions[guide_row].height = 20


# ─────────────────────────────────────────────────────────────────────────────
# MAIN ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────

def generate_combined_analytics_report(downloads_dir, data_exporter_tool=None):
    print("[INFO] Starting combined analytics report generation...")

    exc_df  = load_combined_exceptions(downloads_dir)
    user_df = load_branch_user_count(downloads_dir, data_exporter_tool)

    print(f"[INFO] Loaded {len(exc_df)} exception records from branch folders")
    print(f"[INFO] Loaded {len(user_df)} branch user-count records")

    # Enrich with normalised metrics (adds Occ_per_1k_Users, Weighted_Severity, etc.)
    if not exc_df.empty:
        exc_df = _enrich_with_users(exc_df, user_df)
    
    # Add impacted customers count
    if not exc_df.empty:
        print("[INFO] Calculating impacted customers from grain data...")
        exc_df = add_impacted_customers_to_combined(exc_df, downloads_dir)
        print(f"[INFO] Added impacted customer counts to {len(exc_df)} records")

    wb = Workbook()

    exc_log_df = load_exception_execution_log(downloads_dir)
    print(f"[INFO] Exception execution log: {len(exc_log_df)} entries")

    _build_guide(wb, exc_df, user_df)              # Sheet 00 – User Guide
    _build_sheet1(wb, exc_df)                      # Sheet 01 – Combined Exceptions
    _build_sheet2(wb, user_df, exc_df)             # Sheet 02 – Branch User Count
    _build_sheet3(wb, exc_df)                      # Sheet 03 – Region Analytics
    _build_sheet4(wb, exc_df)                      # Sheet 04 – KRI Analytics
    _build_sheet5(wb, exc_df, user_df)             # Sheet 05 – Branch Analytics
    _build_sheet6(wb, exc_df)                      # Sheet 06 – High Risk KRI
    _build_sheet7(wb, exc_df)                      # Sheet 07 – Theme Analytics
    _build_sheet8(wb, exc_df, user_df)             # Sheet 08 – Executive Dashboard
    _build_visual_dashboard(wb, exc_df, user_df)   # Sheet 09 – Visual Dashboard
    _build_exception_log(wb, exc_log_df)           # Sheet 10 – Exception Execution Log

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    out = os.path.join(downloads_dir, f"Combined_Analytics_Report_{ts}.xlsx")
    wb.save(out)
    print(f"[SUCCESS] Combined analytics report saved: {out}  ({os.path.getsize(out)//1024} KB)")
    return out


if __name__ == "__main__":
    import sys
    generate_combined_analytics_report(sys.argv[1] if len(sys.argv) > 1 else "downloads")
